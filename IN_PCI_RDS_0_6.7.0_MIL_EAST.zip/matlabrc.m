% Main MatLab StartUp - Launch by MatLab.Exe
%===============================================================================================
% Creation date :                                                                   Author
% 06.01.1998                                                                 The MathWorks, Inc
% ----------------------------------------------------------------------------------------------
% Changed date  :                                                                   Author
% 11.01.2000                                                                      G. Caron
% French traduction - Default graphical windows position
% matlabrc launch startup.m in current MatLab directory or  first startup.m file found in "path"
% 23.01.2004                                                                      G. Caron
% Path for AGS
% 16.04.2004                                                                      G. Caron
% Change access to 66161
% 25.05.2004                                                                      G. Caron
% Changes for TargetLink 2.0
% 27.01.2006                                                                      G. Caron
% adaptation Path AGS
% 31.03.2006                                                                      G. Caron
% Prise en compte MatLab 7.1.0 (R14 SP3)
% 22.09.2006                                                                      G. Caron
% Checking MatLab 7.2.0 (R2006a)
% 04.10.2006                                                                      G. Caron
% Supp. Averoes access became "\\F-khepri\shared\DIM-DCMAP-CGMP\66161\Shared_MatLab\MatLab_66161"
% 05.01.2007                                                                      G. Caron
% Adaptation R2006b
% 10.12.2007                                                                      G. Caron
% Change local path
% 16.01.2008                                                                      G. Caron
% Activate all "Warning"
% 16.04.2008                                                                      G. Caron
% Version 2.1 : Launch startup.m from current directory
% DirChange Policy set to "never"
% 11.09.2008                                                                      G. Caron
% Version 2.2 : Avoid M-Lint warning
% 20.01.2009                                                                      G. Caron
% Version 2.3 : Adapt RNTBCI - Server param.
% 23.03.2009                                                                      G. Caron
% Version 2.5 : If RTI default config & not in dSpace config. reset to generic real-time target 
% 07.04.2009                                                                      G. Caron
% Version 2.6 : Close open systems for SimuLink Clean Up
% 25.04.2009                                                                      G. Caron
% Version 2.7 : Change character encoding from US-ASCII (Default) to Windows-1252 (R2008b comp.)
% 25.02.2011                                                                      G. Caron
% Version 2.8 : Inhibit warning for pcode encoding with previous MatLab version
% 18.06.2012                                                                      G. Caron
% Version 2.9 : Allow Generic Scripts in C:\App_Reno\Shared_MatLab\MatLab_66161
% 10.10.2012                                                                     B. Oumoudi
% Version 2.9 : Correction LUP n 542
% 28.02.2013                                                                      G. Caron
% Version 3.0 : ModelCompare compatibilty
% 15.01.2013                                                                       G. Caron
% Modified AGS removal from path
% 02.06.2014                                                                       G. Caron
% Change F-Typhon path (I:\Embedded Software\Tools and Scripts\MIL_SIL\Shared_MatLab)
% 10.04.2017                                                                       B.Oumoudi
% Matlab R2016b compatibility
%===============================================================================================
%% Start MatLabRC
function    matlabrc                                      %
StartTime=clock; Version=version; VersMat=sscanf(Version,'%d.%d');
if exist('pathdef','file')                               % Define "Path" from pathdef script
  ptime0=[];
  if exist([matlabroot '/toolbox/local/toolbox_cache.mat'], 'file') && ...
     strcmpi(system_dependent('getpref','GeneralUseToolboxCache'),'BTrue')
    disp('  MatLab Toolbox Path being initialized using Toolbox Path Cache.')
    if strcmpi(system_dependent('getpref','GeneralUseToolboxCacheDiag'),'BTrue')
      ptime0=clock;
    end
  end  
  if ~exist('RESTOREDEFAULTPATH_EXECUTED','var'), matlabpath(pathdef); end
  if ~isempty(ptime0)
    fprintf(' Path MatLab initialise en %.2f secondes.',etime(clock,ptime0));
  end
end
if (exist('ispc','file')==2)
  isPCWin=ispc;
else
  isPCWin=1;
end

try
  if (isPCWin==1)                                         % Avoid running directly out of the bin\win32 directory
    pathToBin=[matlabroot,filesep,'Bin',filesep,'Win32']; % as this is not supported
    if isequal(lower(pwd),lower(pathToBin))
      if exist([matlabroot filesep 'Work'],'dir')
        cd([matlabroot filesep 'Work']);
      else
        cd(matlabroot);
      end
    end
  end
catch Exception
  if isfield(Exception,'message')
    fprintf(1,'(E) Error executing %s : %s !\n',...
      'Avoid working in Win32 directory',Exception.message);
  else
    fprintf(1,'(E) Error executing %s !\n',...
      'Avoid working in Win32 directory');
  end
end

if strncmpi(get(0,'language'),'Fr',2)                     % StartUp advices
  if ((VersMat(1) >= 7) || ((VersMat(1) == 6) && (VersMat(2) >= 5))) && usejava('Desktop')
    fprintf(1,' Pour demarrer selectionner <a href="matlab: doc">MatLab Help</a> ou <a href="matlab: demo matlab">Demos</a> depuis le menu\n');
    % WEBLink=['<a href="matlab:web(''http://www.mathworks.com'',''-browser'')">','The MathWorks','</a>'];
  else
    fprintf(1,' Pour demarrer tapez l''une des commandes : helpwin, helpdesk, ou demo.\n');
  end
%   WEBLink='www.mathworks.com';
%   if (exist('tour','file')==0)
%     fprintf(1,' Pour connaitre les produits MathWorks visitez le site %s\n\n',WEBLink)
%   else
%     fprintf(1,' Pour connaitre les produits MathWorks tapez "tour" ou visitez le site %s\n\n',WEBLink)
%   end
elseif strncmpi(get(0,'language'),'ja',2) && (isPCWin==1)
  set(0,'defaultuicontrolfontname',get(0,'factoryuicontrolfontname'));
  set(0,'defaultuicontrolfontsize',get(0,'factoryuicontrolfontsize'));
  set(0,'defaultaxesfontname',get(0,'factoryuicontrolfontname'));
  set(0,'defaultaxesfontsize',get(0,'factoryuicontrolfontsize'));
  set(0,'defaulttextfontname',get(0,'factoryuicontrolfontname'));
  set(0,'defaulttextfontsize',get(0,'factoryuicontrolfontsize'));
  % You can control the fixed-width font with the following command
  % set(0,'fixedwidthfontname','MS Gothic'); 
else
  if usejava('Desktop')
    fprintf(1,' To get started, select <a href="matlab: doc">MATLAB Help</a> or <a href="matlab: demo matlab">Demos</a> from the Help menu.\n\n');
  else
    fprintf(1,' To get started, type one of these: helpwin, helpdesk, or demo.\n');
  end
  if (exist('tour','file')==0)
    fprintf(1,' For product information, visit www.mathworks.com.\n');
  else
    fprintf(1,' For product information, type tour or visit www.mathworks.com.\n');
  end
end

warning backtrace                                         % Define warning default level
if (VersMat(1) == 5) || ((VersMat(1) == 6) && (VersMat(2) == 1))
  feature('MEXFileCompat',1);                             % Enable MEX-file backwards compatibility mode
end

try
  if strncmp(computer,'GLNX',4)                           % The RecursionLimit forces MATLAB to throw an error
    set(0,'RecursionLimit',100);                          % when the specified  function call depth is hit.
  elseif strncmp(computer,'ALPHA',5)                      % This protects you from blowing your stack frame
    set(0,'RecursionLimit',200);                          % (which can cause MATLAB and/or your computer to crash).
  elseif strncmp(computer,'MAC',3)                        % Set the value to inf if you don't want this protection.
    set(0,'RecursionLimit',200);                          %
  else
    set(0,'RecursionLimit',500);                          %
  end                                                     %
catch Exception
  if isfield(Exception,'message')
    fprintf(1,'(E) Error executing %s : %s !\n',...
      'RecursionLimit',Exception.message);
  else
    fprintf(1,'(E) Error executing %s !\n',...
      'RecursionLimit');
  end
end

Screen=get(0, 'ScreenSize');                              % Screen size in pixels
if ~(all(Screen(3:4)==1))                                 % No change if (Width,Heigth)==[1 1]
  if (isPCWin==1)                                         % Windows
    OrigineX=5; OrigineY=35;
    [ParentDir,CurrentDir,Ext]=fileparts(pwd); CurrentDir=[CurrentDir Ext];
    if isempty(ParentDir)
    end
    fprintf(1,' Current directory : %s !\n',CurrentDir);
    set(0,'DefaultFigurePosition',[OrigineX OrigineY Screen(3)/2 Screen(4)/2.50],...
      'DefaultFigureName',CurrentDir);
    if (VersMat(1) >= 6) || ((VersMat(1) == 5) && (VersMat(2) == 3))
      % Policy=system_dependent('RemoteCWDPolicy','Reload');
      system_dependent('DirChangeHandleWarn','Never');
    end
  elseif strcmpi(computer,'SOL2') || strcmpi(computer,'SUN4')
    OrigineX=5; OrigineY=100;
    [ParentDir,CurrentDir]=fileparts(pwd);
    if isempty(ParentDir)
    end
    fprintf(1,' Current directory : %s !\n',CurrentDir);
    set(0,'DefaultFigurePosition',[OrigineX OrigineY Screen(3)/2 Screen(4)/2.50],...
      'DefaultFigureName',CurrentDir);
  else                                                    %
    if Screen(4) > 768
      MWWidth=560; MWHeight=420;
      Left   =(Screen(3)-MWWidth)/2;
      Bottom =Screen(4)-MWHeight-60;
    else                                                  % For screens that aren't so high
      MWWidth=512; MWHeight=384;
      Left    =(Screen(3)-MWWidth)/2;
      Bottom  =Screen(4)-MWHeight-50;
    end
    set(0,'DefaultFigurePosition',[Left Bottom MWWidth MWHeight]);
  end
end
fprintf(1,'========================================================================================\n');
colordef(0,'white')                                       % White as default color

% If neither of the above lines are uncommented then guess
% which papertype and paperunits to use based on ISO 3166 country code.
if (VersMat(1) >= 6)
  if usejava('jvm') && ~exist('DefaultPaper','var')
    if any(strncmpi(char(java.util.Locale.getDefault.getCountry), ...
  		  {'gb','uk','fr','de','es','ch','nl','it','ru','jp','kr','tw','cn'},2))
      DefaultPaper='a4'; DefaultUnits='centimeters';
    else
      DefaultPaper='usletter'; DefaultUnits='inches';
    end
  else
    DefaultPaper='usletter'; DefaultUnits='inches';
  end
  % Text-based preferences
  NumericFormat=system_dependent('getpref','GeneralNumFormat');
  if ~isempty(NumericFormat)
    eval(['format ' NumericFormat(2:end)]);
  end
  NumericDisplay=system_dependent('getpref','GeneralNumDisplay');
  if ~isempty(NumericDisplay)
    format(NumericDisplay(2:end));
  end
  MaxTab=system_dependent('getpref','CommandWindowMaxCompletions');
  if ~isempty(MaxTab) && MaxTab(1) == 'I'
    EnableTab=system_dependent('getpref','CommandWindowTabCompletion');
    TabSetting=strcmpi(EnableTab,'BTrue') * str2double(MaxTab(2:end));
    system_dependent('TabCompletion', TabSetting);
  end
  if (strcmpi(system_dependent('getpref','GeneralEightyColumns'),'BTrue'))
    feature('EightyColumns',1);
  end
  if usejava('Desktop')                                   % MatLab 6.* with -nojvm inhibit SimuLink prefs
    if usejava('mwt'), initprefs;                         % Restaured using "prefspanel"
    else
      prefspanel;
    end                                                   %
  end
else
  DefaultPaper='a4'; DefaultUnits='centimeters';
end

set(0,'DefaultFigureNumberTitle',...                      % Default figure format
  'on','DefaultFigurePaperType',DefaultPaper,...          %
  'DefaultFigurePaperUnits',DefaultUnits,...              %
  'DefaultFigurePaperOrientation','landscape',...         % Print in landscape
  'DefaultFigurePaperPosition',[0.63452 0.63452 28.408 19.715])
set(get(get(0,'CurrentFigure'),'CurrentAxes'),'FontSize',8,'FontName','Helvetica','box','on',...
  'Position',[0.075 0.100 0.900 0.800],'FontWeight','Bold');

%set(0,'DefaultFigureToolBar','none');                    % No toolbar in figure
%set(0,'DefaultFigureToolBar','figure');                  % Toolbar in figures

try
  [Status,DOSMsg]=dos('IPConfig /all');                   %
  if ~(Status==0)
    fprintf(1,'(E) Executing "IPConfig /all" FAILED !\n\tError message %s\n',DOSMsg);
    isServerConnected=0;
  else
    Txt_IPConfig=textscan(DOSMsg,'%s','delimiter',';\n'); % strread replaced by textscan (R2010b)
    Txt_IPConfig=Txt_IPConfig{:};                         % 
    for n=1:length(Txt_IPConfig)                          %
      CurrentLine=Txt_IPConfig{n};                        %
      if ~isempty(CurrentLine)                            %
        Find_DDNS=strfind(lower(CurrentLine),lower('DDNS'));
        if ~isempty(Find_DDNS)                            %
          Txt_DDNS=CurrentLine(Find_DDNS:end);            %
          cellTxt=textscan(Txt_DDNS,'%s','delimiter','.');%
          if iscell(cellTxt), cellTxt=cellTxt{:}; end
          if (length(cellTxt) >= 3)                       %
            Site=cellTxt{2}; Factory=cellTxt{3};          %
            break                                         %
          end                                             %
        end                                               %
      end                                                 %
    end                                                   %
    switch lower(Factory)                                 %
      case 'renault'                                      % F-Khepri - Renault
        ServerName='F-Khepri';                            %
        ServerMatLabSharedPath='\\F-Khepri\Shared\DIM-DCMAP-CGMP\66161\Shared_MatLab\MatLab_66161';
        switch lower(Site)                                %
          case 'ctl'                                      % France  - Centre Technique de Lardy
          case 'ctr'                                      % France  - Centre Technique de Rueil
          case 'cta'                                      % France  - Centre Technique d'Aubevoye
          case 'vll'                                      % Espagne - Valladolid
          case 'vsf'                                      % France  - IDVU Villiers Saint-Frederic
          case 'sjp'                                      % Brazil  - Curitiba
          otherwise                                       % Undefined Site
        end                                               % End switch "Site"
      case 'rsm'                                          % Renault Samsung Motor : F-Khepri - Renault
        ServerName='F-Khepri';
        ServerMatLabSharedPath='\\F-Khepri\Shared\DIM-DCMAP-CGMP\66161\Shared_MatLab\MatLab_66161';
      case 'dacia'                                        % Dacia : F-Khepri - Renault
        ServerName='F-Khepri';
        ServerMatLabSharedPath='\\F-Khepri\Shared\DIM-DCMAP-CGMP\66161\Shared_MatLab\MatLab_66161';
      case 'nissan-renault'                               % F-Typhon - RNTBCI
        ServerName='F-Typhon';
%         ServerMatLabSharedPath='\\F-Typhon\Shared\DCMAP\TOOLS\MIL_SIL\Shared_MatLab\MatLab_66161';
        ServerMatLabSharedPath='\\F-Typhon\Shared\Embedded Software\Tools and Scripts\MIL_SIL\Shared_MatLab';
      otherwise                                           % Default :  F-Khepri - Renault
        ServerName='F-Khepri';
        ServerMatLabSharedPath='\\F-Khepri\Shared\DIM-DCMAP-CGMP\66161\Shared_MatLab\MatLab_66161';
    end                                                   % End switch "Factory"
    isServerConnected=(exist(['\\' ServerName '\Shared'],'dir')==7);
  end
catch Exception
  if isfield(Exception,'message')
  end
  isServerConnected=0;
end

if (isServerConnected==1)
  lstGeneric=struct('Dir',{...                            % Generic script "Path" - if NetWork
    ['C:\Users\' getenv('UserName') '\Langage\MatLab\Librairie\MatLab_Shared'],...
    'C:\App_Reno\Shared_MatLab\MatLab_66161',...
    ServerMatLabSharedPath,...
    },...
    'Comment',{...
    'Local generic scripts - Dev.',...
    'Local generic scripts',...
    sprintf('NetWork generic scripts (%s)',ServerName),...
    });
else
  lstGeneric=struct('Dir',{...                            % Generic script "Path" - if NetWork
    ['C:\Users\' getenv('UserName') '\Langage\MatLab\Librairie\MatLab_Shared'],...
    'C:\App_Reno\Shared_MatLab\MatLab_66161',...
    },...
    'Comment',{...
    'Local generic scripts - Dev.',...
    'Local generic scripts',...
    });
end
if (VersMat(1) >= 7) || ((VersMat(1) >= 6) && (VersMat(2) >= 5))
  structWarn=warning('off','all');
  for n=1:length(structWarn)
    warning('off',structWarn(n).identifier);
  end
end
for n=1:size(lstGeneric,2)
  if (exist(lstGeneric(n).Dir,'dir')==7)
    addpath(lstGeneric(n).Dir,'-begin');                  % Path to Generic scripts
    fprintf(1,' %s\n',lstGeneric(n).Comment); break;
  end
end

lstAGSPath=struct(...
  'Dir',{...                                              % AGS sources directories
    'C:\App_Reno\AGS';...                                 %
    'C:\App_Reno\AGS\AGS';...                             %
    'C:\App_Reno\Valeo\AGS';...                           %
    'C:\App_Reno\JCAE\AGS';...                            %
    'C:\Program Files\AGS';...                            %
    'C:\Program Files (x86)\AGS';...                      %
    'C:\Program Files\Valeo\AGS';...                      %
    'C:\Program Files (x86)\Valeo\AGS';...                %
  },...                                                   %
  'Comment',{...
    'Local AGS available';...
    'Local AGS available';...
    'Local AGS available';...
    'Local AGS available';...
    'Local AGS available';...
    'Local AGS available';...
    'Local AGS available';...
    'Local AGS available';...
  });

for n=1:size(lstAGSPath,1)
  if (exist(lstAGSPath(n).Dir,'dir')==7)
    if (exist([lstAGSPath(n).Dir filesep 'Bin'],'dir')==7) && ...
        (exist([lstAGSPath(n).Dir filesep 'Sources'],'dir')==7)
      addpath(lstAGSPath(n).Dir);
      addpath([lstAGSPath(n).Dir filesep 'Bin']);
      addpath([lstAGSPath(n).Dir filesep 'Sources']);
      if (exist([lstAGSPath(n).Dir filesep 'Customization'],'dir')==7)
        addpath([lstAGSPath(n).Dir filesep 'Customization']);
      end
      fprintf(1,' %s in %s\n',lstAGSPath(n).Comment,lstAGSPath(n).Dir);
      break
    end
  end
end

if (VersMat(1) >= 6) || ((VersMat(1) == 5) && (VersMat(2) == 3))
  if (exist('dSpaceRC.m','file')==2)
    [ParentDir,FileName]=fileparts(which('dSpaceRC'));    % MatLab 5.3, 6.* or 7.* - Run "dSpaceRC" if exist
    if isempty(ParentDir)
    end
    try
      evalin('base',FileName);
    catch Exception
      if isfield(Exception,'message')
      end
%       lasterror('reset')
    end
  elseif (VersMat(1) >= 7)
    hSLPrefs=getActiveConfigSet(0);
    CurrentTMF=get_param(hSLPrefs,'TemplateMakefile');
    if (strncmpi(CurrentTMF(1:min(length(CurrentTMF),3)),'RTI',3)==1)
      switchTarget(hSLPrefs,'grt.tlc',[]);
      set_param(hSLPrefs,'TemplateMakefile','grt_default_tmf');
      set_param(hSLPrefs,'MakeCommand','make_rtw');
    end
  end
end

if (VersMat(1) >= 7) || ((VersMat(1) == 6) && (VersMat(2) == 5))
  CurrentWarningStatus=warning;                           % Current status state
  FoundWarn=(find(strcmpi('all',{CurrentWarningStatus.identifier}),1) > 0);
  if ~isempty(FoundWarn)                                  %
    if strcmpi(CurrentWarningStatus(FoundWarn).state,'On')
      warning('off','all')                                % Inactive warnings
    end
  end
  OpenSys=find_system('Type','block_diagram'); lstOpenSys={}; Count=0;
  while ~isempty(OpenSys) && (Count < 3)
    for n=1:length(OpenSys)
      try
        close_system(OpenSys{n})
      catch Exception
        if isfield(Exception,'message')
        end
        lstOpenSys=[lstOpenSys;OpenSys(n)];               %#ok<AGROW>
        open_system(OpenSys{n})
      end
    end
    OpenSys=find_system('Type','block_diagram');
    OpenSys=setdiff(OpenSys,lstOpenSys);
    Count=Count+1;
  end
  if ~isempty(FoundWarn)                                  % Restore previous settings
    if strcmpi(CurrentWarningStatus(FoundWarn).state,'On')
      for k=1:length(CurrentWarningStatus)
        warning(CurrentWarningStatus(k).state,CurrentWarningStatus(k).identifier)
      end
    end
  end
end

if (VersMat(1) >= 7) || ((VersMat(1) >= 6) && (VersMat(2) >= 5))
  structWarn=warning('on','all');
  for n=1:length(structWarn)
    warning('on',structWarn(n).identifier);
  end
end

warning('off','MATLAB:oldPfileVersion');                  % pCode are compiled for R2006b version
ElapsedTime=etime(clock,StartTime);
fprintf(1,'Time elapsed executing "%s" : %d sec.\n',mfilename,round(ElapsedTime));

if (VersMat(1) < 7) || ((VersMat(1) == 7) && (VersMat(2) <= 3))
  flops(0);                                               % Reset op. count - Not compatible in R2008b
elseif ((VersMat(1) == 7) && (VersMat(2) >= 7))
  if ~strcmpi(slCharacterEncoding,'Windows-1252')
    slCharacterEncoding('Windows-1252')
  end
end
try
  if (exist([pwd filesep 'startup.m'],'file')==2)         % Run startup.m
    FileName=dir('startup.m');
    if ~isempty(FileName)
      [ParentDir,FileName]=fileparts(FileName(1).name);   % Get name with right case
      if isempty(ParentDir)
      end
      evalin('base',FileName);
    end
  else
    if strncmpi(get(0,'language'),'Fr',2)
      fprintf(1,' Vous pouvez creer un fichier de commandes de demarrage\n pour MatLab dans "startup.m"\n');
    else
      fprintf(1,' You could create a startup command file\n for MatLab in "startup.m"\n');
    end
  end                                                     %
catch Exception
  if isfield(Exception,'message')
    fprintf(1,'(E) Error executing %s : %s !\n','StartUp',Exception.message);
  else
    fprintf(1,'(E) Error executing %s !\n','StartUp');
  end
end

return                                                    % End of file "matlabrc.m"

%% =================================================================================
%------------------------------------- Interns Functions ---------------------------------------
%===============================================================================================

%% ---------------------------------------------------------------------------------