% Set MatLab startup (Path, ...)
%===============================================================================================
% Creation Date :                                                                   Author
% 20.07.2011                                                                       G. Caron
%-----------------------------------------------------------------------------------------------
% Modification :                                                                    Author
% 03.08.2011                                                                       G. Caron
% Update for eAST - MatLab R2011a
% 20.10.2011                                                                       G. Caron
% Addpath to Dico_Tool, Librairies_DCMAP
% 09.12.2011                                                                       G. Caron
% Remove simulink custumization from Dico Tool - Add path for COVM 2012
% 31.05.2012                                                                       G. Caron
% Local version could be in "C:\App_Reno\Shared_MatLab" - eAST V1.3.1
% 08.03.2013                                                                       G. Caron
% MXAM folder - eAST V1.3.7
% 07.05.2013                                                                       G. Caron
% F-Felket for RTA - eAST V1.3.8
% 09.07.2013                                                                       G. Caron
% Local tools folder could be D:\Public\App_Reno - eAST V1.3.9
% 20.11.2013                                                                       G. Caron
% Adaptation for R2012b  (SimuLink DataClass & Libraries) & ACE1 local tools dev. folder
% 10.12.2013                                                                       G. Caron
% MatLab R2011a required
% 10.03.2014                                                                       G. Caron
% Modified AGS removal from path
% 15.04.2014                                                                       G. Caron
% Change beta versions
% 02.06.2014                                                                       G. Caron
% Change F-Typhon path (I:\Embedded Software\Tools and Scripts\MIL_SIL\Shared_MatLab)
% 02.06.2014                                                                       B.Oumoudi
% Modification according to LUP n�713.
% 05.05.2015                                                                       B.Oumoudi
% Librairies compatible with R2012b (LUP n�811).
% 12.05.2016                                                                       B.Oumoudi
% Correction to manage F-Tyhoon path
% 26.08.2016                                                                       B.Oumoudi
% Manage Dacia server (F-Onouris)
% 21.10.2016                                                                       B.Oumoudi
% Choice between Local scripts version and Network scripts version (LUP n� 877)
% 05.12.2016                                                                       B.Oumoudi
% Display Current LM in user popup
% 10.04.2017                                                                       B.Oumoudi
% Matlab R2016b compatibility
% 25.10.2017                                                                       V.Sarret
% Include right library path for different Matlab's versions (LUP n� 1950)
% 01.02.2018                                                                       C.Simeoni
% LUP 2034 : Update LocalToolsDir for ACE2 compatibility
% 15.05.2018                                                                       V.Sarret
% LUP 2112 : Modification d�marrage de eAST
%==============================================================================================
% File startup.m
% Script  startup
% Set MatLab startup (Path, ...)
%===============================================================================================
function    startup                                       % Function "startup"
if strcmp(get(0,'Diary'),'on'), diary('off'); end

%===============================================================================================
%------------------------------------------ Settings -------------------------------------------
lstReportDir={'Reports';'_Reports';'_Reports_'};
lstConfigDir={'Cfg';'_Cfg';'_Cfg_'};
ClassPath='RSA_Data_Class_Package';
MBDInitFile='MBD_Tools_Versions.Ini';
DeployedTools='DEPLOYED_VERSIONS';
BetaTools='BETA_VERSIONS';
ProtoTools='Proto_VERSIONS';
LogFileToolsVersion='Tools_Versions';

% CurrentDelivery=' eAST current delivery';
% OldDelivery='eAST re-delivery (old cycle)' ;
% BetaDelivery='Beta testing';
CurrentDelivery='Delivery on current cycle';
OldDelivery='Mockup or Delivery on previous cycles' ;
ProtoVersion='Rapid Prototyping';
BetaDelivery='Beta version';
%===============================================================================================

%===============================================================================================
%-------------------------------------------- Init. --------------------------------------------
Version=ver('matlab');                                    %
VersionMatLab=sscanf(Version.Version,'%d.%d');            %
if strcmpi(getenv('MatLab_Mem_MGR'),'Debug')              %
  fprintf(1,'(W) MatLab in debug memory mode\n');         %
end                                                       %

RepLog='.';
for n=1:length(lstReportDir)                              % Log files directories
  ReportDir=lstReportDir{n};
  if (exist([cd filesep ReportDir],'dir')==7)
    RepLog=['.' filesep ReportDir]; break
  end
end

if strcmpi(getenv('MatLab_Mem_MGR'),'Debug')
  fprintf(1,'(W) MatLab in debug memory mode\n');
end

hFig=findobj(allchild(0),'-regexp','Tag','\w*','Type','Figure');
while ~isempty(hFig)                                      % Delete all tagged figure
  delete(hFig(1));                                        % Rem. : Delete do not execute CloseRequestFcn
  hFig=findobj(allchild(0),'-regexp','Tag','\w*','Type','Figure');
end                                                       %
%===============================================================================================

%% Reporting file
if strcmpi(get(0,'Diary'),'Off')
  FichDiary=[RepLog filesep mfilename '.Log'];
  if exist(FichDiary,'file')==2
    diary off; delete(FichDiary);
  end
  eval(['diary(''' FichDiary ''')']);                     % Log file
end

%% Check version
switch VersionMatLab(1)                                   %
  case {4,5,6}                                            %
    fprintf(1,'Wrong MatLab Version - At least MatLab R2011a !\n');
    return                                                %
  case {7}                                                %
    if (VersionMatLab(2) < 12)                            %
      fprintf(1,'Wrong MatLab Version - At least MatLab R2011a !\n');
      return                                              %
    end
    fprintf(1,'MatLab Version Ok !\n');                   %
    %     if (VersionMatLab(2) >= 10)                           % Since MatLab R2010a warning if pcode
    %       warning('off','MATLAB:oldPfileVersion');            % compiled before R2007a
    %     end                                                   %
  case {8,9}                                                %
    fprintf(1,'MatLab Version Ok !\n');                   %
    ClassPath='RSA_DataClass_R2012b';                     % DataClass updated for R2012b - 8.0
  otherwise                                               %
    VersionMatLab=sscanf(Version.Version,'%d.%d');        %
    if ((VersionMatLab(1) > 6) || ((VersionMatLab(1) == 6) && (VersionMatLab(2) >= 5)))
      fprintf(1,'(W) Unchecked MatLab version (%s) !\n',Version.Version);
    end                                                   %
end

%% Is there a local installation

LocalToolsDir=[getenv('SystemDrive') filesep 'App_Reno' filesep 'Shared_MatLab']; % Local Install for Nissan
if ~(exist(LocalToolsDir,'dir')==7)
  if ~isempty(getenv('Public'))
    LocalToolsDir=[getenv('Public') filesep 'App_Reno' filesep 'Shared_MatLab'];  % Local Install for Renault PC ACE 1 or ACE 2
    if ~(exist(LocalToolsDir,'dir')==7)
      LocalToolsDir = 'D:\Public\App_Reno\Shared_Matlab'; % Local Install for externs
    end
  else
    LocalToolsDir = 'D:\Public\App_Reno\Shared_Matlab'; % Local Install for externs
  end
end

%% Server
[Success,Factory,Site]=Ident_Site;
if (Success >= 1)
  switch lower(Factory)                                   %
    case 'renault'                                        % F-Khepri - Renault
      ServerName='F-Khepri';
      ServerMatLabSharedPath='\\F-Khepri\Shared\DIM-DCMAP-CGMP\66161\Shared_MatLab';
      switch lower(Site)                                  %
        case 'ctl'                                        % France  - Centre Technique de Lardy
        case 'ctr'                                        % France  - Centre Technique de Rueil
        case 'cta'                                        % France  - Centre Technique d'Aubevoye
        case 'vll'                                        % Espagne - Valladolid
        case 'vsf'                                        % France  - IDVU Villiers Saint-Frederic
        case 'sjp'                                        % Brazil  - Curitiba
          ServerName='F-Felket';
          ServerMatLabSharedPath='\\F-Felket\shared\DEMA_DCMAP\Tools_DCMAP\EMS_Tools\Shared_MatLab';
        otherwise                                         % Undefined Site
      end                                                 % End switch "Site"
    case 'rsm'                                            % Renault Samsung Motor : F-Khepri - Renault
      ServerName='F-Khepri';
      ServerMatLabSharedPath='\\F-Khepri\Shared\DIM-DCMAP-CGMP\66161\Shared_MatLab';
    case 'dacia'                                          % Dacia : F-Khepri - Renault
      ServerName='F-Onouris';
      ServerMatLabSharedPath='\\F-Onouris\Shared\DIM-DCMAP-CGMP\66161\Shared_MatLab_';
    case 'nissan-renault'                                 % F-Typhon - RNTBCI
      ServerName='F-Typhon';
      %       ServerMatLabSharedPath='\\F-Typhon\Shared\DCMAP\TOOLS\MIL_SIL\Shared_MatLab';
      ServerMatLabSharedPath='\\F-Typhon\Shared\Embedded Software\Tools and Scripts\MIL_SIL\Shared_MatLab';
    otherwise                                             % Default :  F-Khepri - Renault
      ServerName='F-Khepri';
      ServerMatLabSharedPath='\\F-Khepri\Shared\DIM-DCMAP-CGMP\66161\Shared_MatLab';
  end                                                     % End switch "Factory"
else
  ServerName='F-Khepri';
  ServerMatLabSharedPath='\\F-Khepri\Shared\DIM-DCMAP-CGMP\66161\Shared_MatLab';
end

%% Defined path to Tools_EMS201x
isLocalTools=exist([LocalToolsDir '\Tools_EMS2010'],'dir')==7;
isNetWorkTools=exist([ServerMatLabSharedPath filesep 'Tools_EMS2010'],'dir')==7;
if (isLocalTools && isNetWorkTools)             % Local and Network Tools availables --> Choice
  ToolsChoice = questdlg('Local tools found on your PC', ...
    'Tools to use?',...
    'Use Local Tools', 'Use Network Tools' , 'Cancel', 'Use Network Tools');
  switch ToolsChoice
    case 'Use Local Tools'                      % Local Tools
      TxtPath='Use local scripts version';
      ToolsDir=[LocalToolsDir '\Tools_EMS2010'];
    case 'Use Network Tools'                    % Network Tools
      TxtPath=sprintf('Use NetWork scripts version on "%s"',ServerName);
      ToolsDir=[ServerMatLabSharedPath filesep 'Tools_EMS2010'];
    otherwise
      TxtMsg='Process stopped !';
      fprintf(1,'(W) %s \n',TxtMsg);
      hTxtMsg=msgbox(TxtMsg,'Warning','warn');
      set(hTxtMsg,'Tag','Warning');
      return,
  end
elseif isLocalTools
  TxtPath='Use local scripts version';
  ToolsDir=[LocalToolsDir '\Tools_EMS2010'];
elseif isNetWorkTools
  TxtPath=sprintf('Use NetWork scripts version on "%s"',ServerName);
  ToolsDir=[ServerMatLabSharedPath filesep 'Tools_EMS2010'];
else
  fprintf(1,'(E) Path to MatLab scripts not found !\n');  %
  clearvars; return
end
%% Select Tools versions
MBDInitPath=[ToolsDir filesep 'Help' filesep MBDInitFile];
%MBDInitPath=['D:\Public\_Support_eAST_COVM_\N. DELBOS\VF_EST_MNG _LM46' filesep MBDInitFile]
if ~(exist(MBDInitPath,'file')==2)
  fprintf(1,'(E) File ''%s'' not found!\n',MBDInitFile);
  TxtMsg='Process stopped !';
  fprintf(1,'(W) %s \n',TxtMsg);
  hTxtMsg=msgbox(TxtMsg,'Warning','warn');
  set(hTxtMsg,'Tag','Warning');
  return,
end

[isOk,ListCurrentTools,CurrentVersion]=MBD_Read_IniFile(DeployedTools,MBDInitPath);
if~(isOk)
  fprintf(1,'(E) Error while reading file ''%s'' !\n',MBDInitFile);
  return
else
  if iscell(CurrentVersion),CurrentVersion=CurrentVersion{1};end
  FoundLM=strfind(CurrentVersion,'LM');
  if ~isempty(FoundLM)
    CurrentDelivery=sprintf('%s (%s)',CurrentDelivery,CurrentVersion(FoundLM:end));
  end
end


% NeedChoice = questdlg('Please select your need ?', ...
%     'Start MBD Tools', ...
%     CurrentDelivery, OldDelivery,BetaDelivery,CurrentDelivery);
NeedChoice = choosedialog();
switch NeedChoice
  case CurrentDelivery
    ListLMTools=ListCurrentTools;                % Deployed tools (eAST tools & COVM 2012)
    LM='Current_Delivery';
  case OldDelivery                                                                  % Old versions of tools according to delivery choosen
    [isOk,VerStruct]=MBD_Read_IniFile('',MBDInitPath);
    if (isOk)
      %             listLM=setdiff(fieldnames(VerStruct),{CurrentVersion; BetaTools});
      listLM=setdiff(fieldnames(VerStruct),{CurrentVersion; BetaTools;ProtoTools});
      [selection,ok] = listdlg('PromptString','Select the Metier cycle:',...
        'SelectionMode','single','ListSize',[200 240],...
        'ListString',listLM);
    else
      fprintf(1,'(E) Error while reading file ''%s'' !\n',MBDInitFile);
      return
    end
    if(ok)
      fprintf('Metier cycle selected is: %s \n',listLM{selection})
      ListLMTools=eval(['VerStruct.' listLM{selection}]);
      LM=listLM{selection};
    else
      TxtMsg='Process stopped !';
      fprintf(1,'(W) %s \n',TxtMsg);
      hTxtMsg=msgbox(TxtMsg,'Warning','warn');
      set(hTxtMsg,'Tag','Warning');
      return,
    end
  case BetaDelivery                                                                  % Beta versions of tools
    [isOk,ListLMTools]=MBD_Read_IniFile(BetaTools,MBDInitPath);
    if(~isOk)
      fprintf(1,'(E) Error while reading file ''%s'' !\n',MBDInitFile);
      return
    else
      LM='Beta_Test';
    end  
  case ProtoVersion                                                                  % Beta versions of tools
    [isOk,ListLMTools]=MBD_Read_IniFile(ProtoTools,MBDInitPath);
    if(~isOk)
      fprintf(1,'(E) Error while reading file ''%s'' !\n',MBDInitFile);
      return
    else
      LM='Rapid_prototyping';
    end
      
  otherwise
    TxtMsg='Process stopped !';
    fprintf(1,'(W) %s \n',TxtMsg);
    hTxtMsg=msgbox(TxtMsg,'Warning','warn');
    set(hTxtMsg,'Tag','Warning');
    return,
end

%% Paths to selected tools
fprintf('MBD Tools versions:\n');
Fields=fieldnames(ListLMTools);
for i=1:length(fieldnames(ListLMTools))
  fprintf('\t%s\n',eval(['ListLMTools.' Fields{i}]));
end

if verLessThan('simulink','8.8')
  LibrariesVerPath=[fileparts(ToolsDir) filesep 'Tools_DCMAP' filesep 'Librairies_DCMAP_R2011a_R2013b'];
  if strcmp(NeedChoice,ProtoVersion)
    warndlg({'Librairies_DCMAP_Proto not compatible with Matlab R2013b !','Librairies_DCMAP_R2011a_R2013b is used instead !'});
  end
else
  LibrariesVerPath=[fileparts(ToolsDir) filesep 'Tools_DCMAP' filesep ListLMTools.LibrariesPath];
end

lstDir={
  [cd '\Cfg']
  [ToolsDir filesep ListLMTools.eAST]
  [ToolsDir filesep ListLMTools.eAST filesep ClassPath]
  %         [fileparts(ToolsDir) filesep 'Tools_DCMAP' filesep ListLMTools.LibrariesPath]
  LibrariesVerPath
  [ToolsDir filesep ListLMTools.COVM]
  [ToolsDir filesep ListLMTools.Dico_Tool]
  %'\\F-Khepri\Shared\P-VALIDATION\_Commun\Archive\_matlab\EMS2010_Phase2\Scripts_DICO\A_compil_R2011a\A_compilV223_224'
  [ToolsDir filesep ListLMTools.MXAM]
  [fileparts(ToolsDir) filesep 'Tools_DCMAP' filesep ListLMTools.Contrib_Scripts]
  };
% end
%% Mount needed path
CurrentPath=textscan(matlabpath,'%s','Delimiter',';');
CurrentPath=CurrentPath{:};
for n=length(lstDir):-1:1                                 % Absolute directories
  if isempty(find(strcmpi(lstDir{n},CurrentPath) > 0 ,1))
    if (exist([lstDir{n}],'dir')==7)
      addpath(lstDir{n},'-begin');
    elseif strcmpi(lstDir{n},[cd filesep 'Cfg'])
      ConfigDir='';
      for m=1:length(lstConfigDir)
        if (exist([cd filesep lstConfigDir{m}],'dir')==7)
          ConfigDir=lstConfigDir{m};
        end
      end
      if ~isempty(ConfigDir)
        addpath([cd filesep ConfigDir],'-begin')
      else
        fprintf(1,'(W) Config. directory not found !\n');
      end
    else
      fprintf(1,'(E) Directory not found %s !\n',lstDir{n});
      fprintf(1,'(E) Process stopped !\n');
      return
    end
  end                                                     %
end
%% Check script is available
eAST_Folder=fileparts(which('eAST_GUI'));
if ~isempty(eAST_Folder)
  fprintf(1,'%s\n\t-> %s\n',TxtPath,eAST_Folder);
  LinkString_MBDTools=...
    sprintf('<a href="matlab:try, eAST_GUI; end">%s</a>',...
    'Start eAST');
  LinkString_COVM=...
    sprintf('<a href="matlab:try, Start_COVM; end">%s</a>',...
    'Start COVM');
  fprintf(1,'\t%s - %s\n',LinkString_MBDTools,LinkString_COVM);
else
  fprintf(1,'(W) Script %s not found\n','eAST_GUI');
end

%% Is there AGS installation
if ~isempty(which('ags'))
  AGSRoot=fileparts(fileparts(which('ags')));
  if ~isempty(find(strcmpi([AGSRoot '\Bin'],CurrentPath) > 0 ,1))
    fprintf(1,'Remove %30s" from path !\n',['"' AGSRoot '\Bin']);
    rmpath([AGSRoot '\Bin'])                              %
  end                                                     %
  if ~isempty(find(strcmpi([AGSRoot '\Sources'],CurrentPath) > 0 ,1))
    fprintf(1,'Remove %30s" from path !\n',['"' AGSRoot '\Sources']);
    rmpath([AGSRoot '\Sources'])
  end
end
if (exist([eAST_Folder filesep '_ScriptsAGSEmpt_'],'dir')==7)
  addpath([eAST_Folder filesep '_ScriptsAGSEmpt_'],'-begin')
end
%% Save Tools Versions & LM Cycle in txt file
[Success,LogFolder,~]=Check_Log_Conf_Dir;
LogFileName=[LogFolder filesep LogFileToolsVersion '.Log'];
if(Success)
  FId=fopen(LogFileName,'wt');
  fprintf(FId,'%s\n',['[' LogFileToolsVersion ']']);
  for i=1:length(fieldnames(ListLMTools))
    fprintf(FId,'%s=%s\n', Fields{i},eval(['ListLMTools.' Fields{i}]));
  end
  fprintf(FId,'%s=%s\n', 'Delivery_Cycle',LM);
  Status=fclose(FId);
  if (Status==-1)
    fprintf('(E) Error closing file %s!',LogFileToolsVersion);
  end
end
%% Save LM Cycle in local database
% if (exist('DICO_ph2_UpdateMode','file')~=0)
%   Success=DICO_ph2_UpdateMode();
%   if (Success <= 0)
%     fprintf(1,' (W) Could not update mode into DataBase !\n');
%   end
% end

%% Close report
if strcmpi(get(0,'Diary'),'On'); diary off; end

clearvars

return                                                    % End function "StartUp"
end
%% =============================================================================================
%-------------------------------------- Interns Functions --------------------------------------
%===============================================================================================
function    varargout=Ident_Site                          % Function "Ident_Site"

%===============================================================================================
%-------------------------------------------- Init. --------------------------------------------
Factory=''; Site=''; Success=0;                           %
for n=1:nargout
  if (n==1), varargout{n}=-1; else varargout{n}=[]; end
end

%% IP configuration
try
  [Status,DOSMsg]=dos('IPConfig /all');                   %
  if ~(Status==0)
    fprintf(1,'(E) Executing "IPConfig /all" FAILED !\n\tError message %s\n',DOSMsg);
  end
catch Exception
  if isfield(Exception,'message')
  end
  return
end
cellTxtIPConfig=textscan(DOSMsg,'%s','delimiter',';\n');  %
if iscell(cellTxtIPConfig)
  Txt_IPConfig=cellTxtIPConfig{:};
end
%===============================================================================================

%% Identify Site & Factory
for n=1:length(Txt_IPConfig)                              %
  CurrentLine=Txt_IPConfig{n};                            %
  if ~isempty(CurrentLine)                                %
    Find_DDNS=strfind(lower(CurrentLine),lower('DDNS'));  %
    if ~isempty(Find_DDNS)                                %
      Txt_DDNS=CurrentLine(Find_DDNS:end);                %
      cellTxt=textscan(Txt_DDNS,'%s','delimiter','.');    %
      if iscell(cellTxt), cellTxt=cellTxt{:}; end         %
      if (length(cellTxt) >= 3)                           %
        Site=cellTxt{2}; Factory=cellTxt{3};              %
        Success=1; break                                  %
      end                                                 %
    end                                                   %
  end                                                     %
end                                                       %

%% Return values
for n=1:nargout
  switch n
    case 0
    case 1, varargout{n}=Success;                           % Success=1 if succeed
    case 2, varargout{n}=Factory;
    case 3, varargout{n}=Site;
    otherwise, varargout{n}=[];
  end
end

return                                                    % End function "Ident_Site"
end
%===============================================================================================
function varargout=MBD_Read_IniFile(Section,File)    % Function "MBD_Read_IniFile"

%===============================================================================================
%------------------------------------------ Settings -------------------------------------------
LinePattern='\w ?\W ?[\\, ,\w]';
% SectionPattern='[[..,\w]]';
%===============================================================================================

%===============================================================================================
%-------------------------------------------- Init. --------------------------------------------
for n=1:nargout, varargout{n}=[]; end
NbLines=0; Tree='';
if (exist(File,'file')==0)
  fprintf(1,'(E) File not found "%s" !\n',File); return
end
%===============================================================================================

FId=fopen(File,'r'); S={};
try
  while 1                                                 % Parse config file
    ReadLine=fgetl(FId);                                  %
    if ~ischar(ReadLine) || (all(ReadLine)==-1)
      break;                                              % Ending while loop
    else                                                  %
      NbLines=NbLines+1;                                  %
    end                                                   %
    xComment=strfind(ReadLine,'#');                       % StrFind(Text,Pattern)
    if ~isempty(xComment)
      Comment=ReadLine(xComment(1)+1:end);
      if isempty(Comment)
      end
      ReadLine=ReadLine(1:xComment(1)-1);                 % Extract. comment
    end
    
    ReadLine=strrep(ReadLine,char(9),' ');                % Supp. tab
    [Txt,Count]=sscanf(ReadLine,'[%s');
    if (Count==1)
      Tree=strrep(Txt,']',''); Tree=strrep(Tree,'.','_');
    else
      [Start,Finish]=regexp(ReadLine,LinePattern);        % Read one or two word(s)
      if ~isempty(Start) && ~isempty(Finish)
        Txt=ReadLine(1:Start(1)); Oper=ReadLine(Finish(1):end);
        if (length(Oper) > 1)
          while (Oper(1)==' ')
            Oper=Oper(2:end);
          end
        end
        if (length(Oper) > 1)
          while (Oper(end)==' ')
            Oper=Oper(1:end-1);
          end
        end
        if ~isempty(Tree)
          S(1).(Tree).(Txt)=Oper;
        end
      elseif ~isempty(Start)
      else
      end
    end
  end                                                     % End "While" loop
catch Exception
  if isfield(Exception,'message')
  end
  fprintf(1,'(E) Error reading %s file (%s)\n',File,mfilename);
end

Status=fclose(FId);
if (Status==-1)
end

if ~isstruct(S)
  fprintf(1,'(E) Incorrect file format "%s" !\n',File); return
end

Section=strrep(Section,'.','_');
ReadFields=fieldnames(S);
if ~isempty(Section)
  Found=find(strncmpi(Section,ReadFields,length(Section)) > 0,1);
  FieldTxt=ReadFields(Found);
else
  Found=find(strcmpi(Section,ReadFields) > 0,1);
  FieldTxt='';
end

if ~isempty(Found)
  eval(['Struct=S(1).' ReadFields{Found(1)} ';']);
else
  Struct=S;
end
Success=1;
for n=1:nargout
  switch n
    case 1, varargout{n}=Success;
    case 2, varargout{n}=Struct;
    case 3, varargout{n}=FieldTxt;
    otherwise, varargout{n}=[];
  end
end
return                                                    % End function "MBD_Read_IniFile"
end
%===============================================================================================
function    varargout=Check_Log_Conf_Dir                  % Function "Check_Log_Conf_Dir"
%===============================================================================================
%------------------------------------------ Settings -------------------------------------------
lstReportDir={'Reports';'_Reports';'_Reports_'};
lstConfigDir={'Cfg';'_Cfg';'_Cfg_'};
%===============================================================================================

%===============================================================================================
%-------------------------------------------- Init. --------------------------------------------
for n=1:nargout, varargout{n}=[]; end                     % Init. output parameters
Success=1;
% [Version,Count]=sscanf(version,'%d.%d'); Success=0;
%===============================================================================================

DirLog='';
for n=1:length(lstReportDir)                              % Log file directory
  ReportDir=lstReportDir{n};
  if (exist([cd filesep ReportDir],'dir')==7)
    DirLog=['.' filesep ReportDir]; break
  end
end
if isempty(DirLog)                                        % If doesn't exist - Create
  ReportDir=lstReportDir{1};
  [Success,Message]=mkdir(cd,ReportDir);
  if (Success==1)
    DirLog=['.' filesep ReportDir];
  else
    fprintf(1,'(E) Unable to create "%s" subdir\n\t Error : %s\n',ReportDir,Message);
    Success=0;
  end
end

DirCfg='';
for n=1:length(lstConfigDir)                              % Log file directory
  ConfDirectory=lstConfigDir{n};
  if (exist([cd filesep ConfDirectory],'dir')==7)
    DirCfg=['.' filesep ConfDirectory]; break
  end
end
if isempty(DirCfg)                                        % If doesn't exist - Create
  ConfDirectory=lstConfigDir{1};
  [Success,Message]=mkdir(cd,ConfDirectory);
  if (Success==1)
    DirCfg=['.' filesep ConfDirectory];
    addpath([cd filesep ConfDirectory],'-begin');
  else
    fprintf(1,'(E) Unable to create "%s" subdir\n\t Error : %s\n',ConfDirectory,Message);
    Success=0;
  end
end

for n=1:nargout
  switch n
    case 1, varargout{n}=Success;
    case 2, varargout{n}=DirLog;
    case 3, varargout{n}=DirCfg;
    otherwise, varargout{n}=[];
  end
end

return
end

function [NeedChoice]=choosedialog()

d = dialog('Units','pixels','Position',[500,550,850,60],'Name','Please select your need');
movegui(d,'center');

NeedChoice='';

uicontrol('Units',get(d,'Units'),'Parent',d,...
  'Position',[10 20 200 25],...
  'String','Delivery on current cycle',...
  'TooltipString','New cycle ends the first day of the next Metier Delivery (Thursday)',...
  'Callback',@Current_Cycle_callback);

uicontrol('Units',get(d,'Units'),'Parent',d,...
  'Position',[220 20 200 25],...
  'String','Mockup or Delivery on previous cycles',...
  'Callback',@Old_Cycle_callback);

uicontrol('Units',get(d,'Units'),'Parent',d,...
  'Position',[430 20 200 25],...
  'String','Rapid Prototyping',...
  'TooltipString','Used to develop prototype specifications (Designers) and models (RPA)',...
  'Callback',@Proto_Cycle_callback);

uicontrol('Units',get(d,'Units'),'Parent',d,...
  'Position',[640 20 200 25],...
  'String','Beta version',...
  'TooltipString','Used to test future tools release',...
  'Callback',@Beta_Cycle_callback);

uiwait(d);

  function Current_Cycle_callback(~,~)
    NeedChoice = 'Delivery on current cycle';
    delete(d);
  end

  function Old_Cycle_callback(~,~)
    NeedChoice = 'Mockup or Delivery on previous cycles';
    delete(d);
  end

  function Proto_Cycle_callback(~,~)
    NeedChoice = 'Rapid Prototyping';
    delete(d);
  end

  function Beta_Cycle_callback(~,~)
    NeedChoice = 'Beta version';
    delete(d);
  end

end