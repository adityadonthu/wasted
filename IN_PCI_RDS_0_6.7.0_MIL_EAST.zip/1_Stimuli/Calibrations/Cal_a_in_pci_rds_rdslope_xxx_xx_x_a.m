% Initialization file for a_in_pci_rds_rdslope_xxx_xx_x_a
%===============================================================================================
% FileName Cal_a_in_pci_rds_rdslope_xxx_xx_x_a.m
%-----------------------------------------------------------------------------------------------
% Created  : 2019-01-09 16:06:18                          Created by MBD_Export_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : P. Apperce - 66641
% Date     : 2019-01-09
%===============================================================================================

%% Cbx_agb_lg_acel_ena - Boolean to choose between ESP sensor or AGB sensor for longitudinal acceleration
if (exist('Cbx_agb_lg_acel_ena','var')==0)                % 
	Cbx_agb_lg_acel_ena           = true;
else
	if strcmpi(class(Cbx_agb_lg_acel_ena),'RSACSC.Parameter')
		Cbx_agb_lg_acel_ena.Value   = true;
	else
		Cbx_agb_lg_acel_ena         = true;
	end
end

%% Cbx_road_slop_cfm - Option to activate the bench mode
if (exist('Cbx_road_slop_cfm','var')==0)                  % 
	Cbx_road_slop_cfm             = false;
else
	if strcmpi(class(Cbx_road_slop_cfm),'RSACSC.Parameter')
		Cbx_road_slop_cfm.Value     = false;
	else
		Cbx_road_slop_cfm           = false;
	end
end

%% Cbx_road_slop_esp - Activation of use of slope calculation using ESP sensor
if (exist('Cbx_road_slop_esp','var')==0)                  % 
	Cbx_road_slop_esp             = false;
else
	if strcmpi(class(Cbx_road_slop_esp),'RSACSC.Parameter')
		Cbx_road_slop_esp.Value     = false;
	else
		Cbx_road_slop_esp           = false;
	end
end

%% Cxx_dft_road_slop - Default value of road slope for static state calculation
if (exist('Cxx_dft_road_slop','var')==0)                  % 
	Cxx_dft_road_slop             = 0;
else
	if strcmpi(class(Cxx_dft_road_slop),'RSACSC.Parameter')
		Cxx_dft_road_slop.Value     = 0;
	else
		Cxx_dft_road_slop           = 0;
	end
end

%% Cxx_lg_slop_val_stab - Maximum value between two static slope road values for one time step.
if (exist('Cxx_lg_slop_val_stab','var')==0)               % 
	Cxx_lg_slop_val_stab          = 1;
else
	if strcmpi(class(Cxx_lg_slop_val_stab),'RSACSC.Parameter')
		Cxx_lg_slop_val_stab.Value  = 1;
	else
		Cxx_lg_slop_val_stab        = 1;
	end
end

%% Cxx_lg_slop_val_stab_dly - Minimum time for the stabilisation of road slope value
if (exist('Cxx_lg_slop_val_stab_dly','var')==0)           % 
	Cxx_lg_slop_val_stab_dly      = 0.7;
else
	if strcmpi(class(Cxx_lg_slop_val_stab_dly),'RSACSC.Parameter')
		Cxx_lg_slop_val_stab_dly.Value= 0.7;
	else
		Cxx_lg_slop_val_stab_dly    = 0.7;
	end
end

%% Cxx_road_slop - Calibration for tuning activies (Bench mode)
if (exist('Cxx_road_slop','var')==0)                      % 
	Cxx_road_slop                 = 0;
else
	if strcmpi(class(Cxx_road_slop),'RSACSC.Parameter')
		Cxx_road_slop.Value         = 0;
	else
		Cxx_road_slop               = 0;
	end
end

%% Cxx_road_slop_neg_slop - Negative slope value for transition between static and dynamic road slope calculation
if (exist('Cxx_road_slop_neg_slop','var')==0)             % 
	Cxx_road_slop_neg_slop        = -1;
else
	if strcmpi(class(Cxx_road_slop_neg_slop),'RSACSC.Parameter')
		Cxx_road_slop_neg_slop.Value= -1;
	else
		Cxx_road_slop_neg_slop      = -1;
	end
end

%% Cxx_road_slop_pos_slop - Positive slope value for transition between static and dynamic road slope calculation
if (exist('Cxx_road_slop_pos_slop','var')==0)             % 
	Cxx_road_slop_pos_slop        = 1;
else
	if strcmpi(class(Cxx_road_slop_pos_slop),'RSACSC.Parameter')
		Cxx_road_slop_pos_slop.Value= 1;
	else
		Cxx_road_slop_pos_slop      = 1;
	end
end

%% Cxx_road_slop_tq_max_val - Default value of road slope for dynamic state calculation
if (exist('Cxx_road_slop_tq_max_val','var')==0)           % 
	Cxx_road_slop_tq_max_val      = 50;
else
	if strcmpi(class(Cxx_road_slop_tq_max_val),'RSACSC.Parameter')
		Cxx_road_slop_tq_max_val.Value= 50;
	else
		Cxx_road_slop_tq_max_val    = 50;
	end
end

%% Cxx_tkof_road_slop_lg_vs_max - Maximum vehicule speed to active road slope calculation from longitudinal acceleration sensor
if (exist('Cxx_tkof_road_slop_lg_vs_max','var')==0)       % 
	Cxx_tkof_road_slop_lg_vs_max  = 3;
else
	if strcmpi(class(Cxx_tkof_road_slop_lg_vs_max),'RSACSC.Parameter')
		Cxx_tkof_road_slop_lg_vs_max.Value= 3;
	else
		Cxx_tkof_road_slop_lg_vs_max= 3;
	end
end

%% Cxx_tq_diff_slop_out_stab_dly - Duration using the last correct value at the outlet of stabilization
if (exist('Cxx_tq_diff_slop_out_stab_dly','var')==0)      % 
	Cxx_tq_diff_slop_out_stab_dly = 2;
else
	if strcmpi(class(Cxx_tq_diff_slop_out_stab_dly),'RSACSC.Parameter')
		Cxx_tq_diff_slop_out_stab_dly.Value= 2;
	else
		Cxx_tq_diff_slop_out_stab_dly= 2;
	end
end

%% Cxx_tq_diff_slop_val_stab - Maximum value between two slope road values for one time step, for stabilization.
if (exist('Cxx_tq_diff_slop_val_stab','var')==0)          % 
	Cxx_tq_diff_slop_val_stab     = 1;
else
	if strcmpi(class(Cxx_tq_diff_slop_val_stab),'RSACSC.Parameter')
		Cxx_tq_diff_slop_val_stab.Value= 1;
	else
		Cxx_tq_diff_slop_val_stab   = 1;
	end
end

%% Cxx_tq_diff_slop_val_stab_dly - Minimum time for the stabilization of road slope value
if (exist('Cxx_tq_diff_slop_val_stab_dly','var')==0)      % 
	Cxx_tq_diff_slop_val_stab_dly = 0.7;
else
	if strcmpi(class(Cxx_tq_diff_slop_val_stab_dly),'RSACSC.Parameter')
		Cxx_tq_diff_slop_val_stab_dly.Value= 0.7;
	else
		Cxx_tq_diff_slop_val_stab_dly= 0.7;
	end
end

%% Cxx_tqdif_veh_weight - Vehicle weight
if (exist('Cxx_tqdif_veh_weight','var')==0)               % 
	Cxx_tqdif_veh_weight          = 1408;
else
	if strcmpi(class(Cxx_tqdif_veh_weight),'RSACSC.Parameter')
		Cxx_tqdif_veh_weight.Value  = 1408;
	else
		Cxx_tqdif_veh_weight        = 1408;
	end
end

%% Cxx_whl_rad - in_pci_rds_fstqdxx_xxx_xx_x_a/Wheel radius
if (exist('Cxx_whl_rad','var')==0)                        % 
	Cxx_whl_rad                   = 0.308;
else
	if strcmpi(class(Cxx_whl_rad),'RSACSC.Parameter')
		Cxx_whl_rad.Value           = 0.308;
	else
		Cxx_whl_rad                 = 0.308;
	end
end

%% Nsx_vld_fail_2 - Limp home data (1)
if (exist('Nsx_vld_fail_2','var')==0)                     % 
	Nsx_vld_fail_2                = 2;
else
	if strcmpi(class(Nsx_vld_fail_2),'RSACSC.Parameter')
		Nsx_vld_fail_2.Value        = 2;
	else
		Nsx_vld_fail_2              = 2;
	end
end

%% Nsx_vld_nok_0 - Invalid data
if (exist('Nsx_vld_nok_0','var')==0)                      % 
	Nsx_vld_nok_0                 = 0;
else
	if strcmpi(class(Nsx_vld_nok_0),'RSACSC.Parameter')
		Nsx_vld_nok_0.Value         = 0;
	else
		Nsx_vld_nok_0               = 0;
	end
end

%% Nsx_vld_ok_1 - Valid data
if (exist('Nsx_vld_ok_1','var')==0)                       % 
	Nsx_vld_ok_1                  = 1;
else
	if strcmpi(class(Nsx_vld_ok_1),'RSACSC.Parameter')
		Nsx_vld_ok_1.Value          = 1;
	else
		Nsx_vld_ok_1                = 1;
	end
end

%% Nxx_g - a_lb_lib_cst_univcst/ Standard acceleration of gravity
if (exist('Nxx_g','var')==0)                              % 
	Nxx_g                         = 9.81;
else
	if strcmpi(class(Nxx_g),'RSACSC.Parameter')
		Nxx_g.Value                 = 9.81;
	else
		Nxx_g                       = 9.81;
	end
end

%% Nxx_rdslope_samp - Sample time for road slope computation
if (exist('Nxx_rdslope_samp','var')==0)                   % 
	Nxx_rdslope_samp              = 0.02;
else
	if strcmpi(class(Nxx_rdslope_samp),'RSACSC.Parameter')
		Nxx_rdslope_samp.Value      = 0.02;
	else
		Nxx_rdslope_samp            = 0.02;
	end
end

% EOF a_in_pci_rds_rdslope_xxx_xx_x_a.m