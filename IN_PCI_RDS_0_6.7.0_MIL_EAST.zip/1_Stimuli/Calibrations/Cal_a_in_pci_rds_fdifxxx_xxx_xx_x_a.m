% Initialization file for a_in_pci_rds_fdifxxx_xxx_xx_x_a
%===============================================================================================
% FileName Cal_a_in_pci_rds_fdifxxx_xxx_xx_x_a.m
%-----------------------------------------------------------------------------------------------
% Created  : 2019-01-09 16:05:54                          Created by MBD_Export_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : P. Apperce - 66641
% Date     : 2019-01-09
%===============================================================================================

%% Cbx_forc_dif_opt_calc - Activate the calculation of Vxx_forc_dif even if current state is a reverse or a neutral state.
if (exist('Cbx_forc_dif_opt_calc','var')==0)              % 
	Cbx_forc_dif_opt_calc         = false;
else
	if strcmpi(class(Cbx_forc_dif_opt_calc),'RSACSC.Parameter')
		Cbx_forc_dif_opt_calc.Value = false;
	else
		Cbx_forc_dif_opt_calc       = false;
	end
end

%% Csx_use_acel_slop - 0 : no ESP or road_slope using ESP is not tuned1 : use of road_slope using ESP when classic tq_dif is frozen2 : always use road_slop using ESP in replacment of classic_tq_dif
if (exist('Csx_use_acel_slop','var')==0)                  % 
	Csx_use_acel_slop             = 0;
else
	if strcmpi(class(Csx_use_acel_slop),'RSACSC.Parameter')
		Csx_use_acel_slop.Value     = 0;
	else
		Csx_use_acel_slop           = 0;
	end
end

%% Csx_use_acel_slop_tot_res_forc - 0 : no ESP or road_slope using ESP is not tuned1 : use of road_slope using ESP when tot_res_forc is calculated through model2 : always use road_slop using ESP in replacement of tot_res_forc_calc
if (exist('Csx_use_acel_slop_tot_res_forc','var')==0)     % 
	Csx_use_acel_slop_tot_res_forc= 0;
else
	if strcmpi(class(Csx_use_acel_slop_tot_res_forc),'RSACSC.Parameter')
		Csx_use_acel_slop_tot_res_forc.Value= 0;
	else
		Csx_use_acel_slop_tot_res_forc= 0;
	end
end

%% Ctb_fdif_tra_acel_dz_end_vs - Vehicle speed breakpoints for transversal acceleration dead zone end.
if (exist('Ctb_fdif_tra_acel_dz_end_vs','var')==0)        % 
	Ctb_fdif_tra_acel_dz_end_vs   = [0 30 60 90 120 150];
else
	if strcmpi(class(Ctb_fdif_tra_acel_dz_end_vs),'RSACSC.Parameter')
		Ctb_fdif_tra_acel_dz_end_vs.Value= [0 30 60 90 120 150];
	else
		Ctb_fdif_tra_acel_dz_end_vs = [0 30 60 90 120 150];
	end
end

%% Ctb_forc_dif_ofs_tm_brk - Bkpts of Vxx_tm_brk_forc_dif.
if (exist('Ctb_forc_dif_ofs_tm_brk','var')==0)            % 
	Ctb_forc_dif_ofs_tm_brk       = [0 4 8 12 20 25.5];
else
	if strcmpi(class(Ctb_forc_dif_ofs_tm_brk),'RSACSC.Parameter')
		Ctb_forc_dif_ofs_tm_brk.Value= [0 4 8 12 20 25.5];
	else
		Ctb_forc_dif_ofs_tm_brk     = [0 4 8 12 20 25.5];
	end
end

%% Ctb_loadx_veh_spd - Breakpoints of Vehicle speed to calculate the load
if (exist('Ctb_loadx_veh_spd','var')==0)                  % 
	Ctb_loadx_veh_spd             = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 255];
else
	if strcmpi(class(Ctb_loadx_veh_spd),'RSACSC.Parameter')
		Ctb_loadx_veh_spd.Value     = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 255];
	else
		Ctb_loadx_veh_spd           = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 255];
	end
end

%% Ctb_tot_res_forc_mdl_vs - Vehicle speed breakpoints for theorical resistive force model.
if (exist('Ctb_tot_res_forc_mdl_vs','var')==0)            % 
	Ctb_tot_res_forc_mdl_vs       = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200];
else
	if strcmpi(class(Ctb_tot_res_forc_mdl_vs),'RSACSC.Parameter')
		Ctb_tot_res_forc_mdl_vs.Value= [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200];
	else
		Ctb_tot_res_forc_mdl_vs     = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200];
	end
end

%% Ctd_esti_forc_fdif_tau - Table of filtering time constant to apply on esti_forc. Depending of driveline state.
if (exist('Ctd_esti_forc_fdif_tau','var')==0)             % 
	Ctd_esti_forc_fdif_tau        = [0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2];
else
	if strcmpi(class(Ctd_esti_forc_fdif_tau),'RSACSC.Parameter')
		Ctd_esti_forc_fdif_tau.Value= [0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2];
	else
		Ctd_esti_forc_fdif_tau      = [0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2];
	end
end

%% Ctd_fdif_shf_end_tmr - Table of tempo started in the end of a driveline state shift during which the calculs are frozen.
if (exist('Ctd_fdif_shf_end_tmr','var')==0)               % 
	Ctd_fdif_shf_end_tmr          = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
else
	if strcmpi(class(Ctd_fdif_shf_end_tmr),'RSACSC.Parameter')
		Ctd_fdif_shf_end_tmr.Value  = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
	else
		Ctd_fdif_shf_end_tmr        = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
	end
end

%% Ctd_forc_dif_vh_wht - Table of equivalent mass depending of the current driveline state.
if (exist('Ctd_forc_dif_vh_wht','var')==0)                % 
	Ctd_forc_dif_vh_wht           = [1400 1400 1400 2150 1700 1850 1850 1900 1400 1400 1725 1725 1400 1400 1400 1400 1400 1400];
else
	if strcmpi(class(Ctd_forc_dif_vh_wht),'RSACSC.Parameter')
		Ctd_forc_dif_vh_wht.Value   = [1400 1400 1400 2150 1700 1850 1850 1900 1400 1400 1725 1725 1400 1400 1400 1400 1400 1400];
	else
		Ctd_forc_dif_vh_wht         = [1400 1400 1400 2150 1700 1850 1850 1900 1400 1400 1725 1725 1400 1400 1400 1400 1400 1400];
	end
end

%% Ctp_fdif_tra_acel_dz_end - Table of the end of the dead zone of Vxx_tra_acel.
if (exist('Ctp_fdif_tra_acel_dz_end','var')==0)           % 
	Ctp_fdif_tra_acel_dz_end      = [1 1 1 1 1 1];
else
	if strcmpi(class(Ctp_fdif_tra_acel_dz_end),'RSACSC.Parameter')
		Ctp_fdif_tra_acel_dz_end.Value= [1 1 1 1 1 1];
	else
		Ctp_fdif_tra_acel_dz_end    = [1 1 1 1 1 1];
	end
end

%% Ctp_forc_dif_brk_ofs - Table of the offset to apply to Vxx_forc_dif while braking.
if (exist('Ctp_forc_dif_brk_ofs','var')==0)               % 
	Ctp_forc_dif_brk_ofs          = [0 0 0 0 0 0];
else
	if strcmpi(class(Ctp_forc_dif_brk_ofs),'RSACSC.Parameter')
		Ctp_forc_dif_brk_ofs.Value  = [0 0 0 0 0 0];
	else
		Ctp_forc_dif_brk_ofs        = [0 0 0 0 0 0];
	end
end

%% Ctp_loadx_veh_spd - Gain on Vxx_tq_dif to calculate the load
if (exist('Ctp_loadx_veh_spd','var')==0)                  % 
	Ctp_loadx_veh_spd             = [0.6875 0.71875 0.75 0.78125 0.8125 0.84375 0.875 0.90625 0.9375 0.96875 1 1.03125 1.0625 1.09375 1.125 1.15625 1.1875 1.21875 1.25 1.28125];
else
	if strcmpi(class(Ctp_loadx_veh_spd),'RSACSC.Parameter')
		Ctp_loadx_veh_spd.Value     = [0.6875 0.71875 0.75 0.78125 0.8125 0.84375 0.875 0.90625 0.9375 0.96875 1 1.03125 1.0625 1.09375 1.125 1.15625 1.1875 1.21875 1.25 1.28125];
	else
		Ctp_loadx_veh_spd           = [0.6875 0.71875 0.75 0.78125 0.8125 0.84375 0.875 0.90625 0.9375 0.96875 1 1.03125 1.0625 1.09375 1.125 1.15625 1.1875 1.21875 1.25 1.28125];
	end
end

%% Ctp_tot_res_forc_mdl - Table of theorical resistive force applied to the vehicle.
if (exist('Ctp_tot_res_forc_mdl','var')==0)               % 
	Ctp_tot_res_forc_mdl          = [216 219 229 250 275 309 349 396 449 509 576 650 731 819 915 1019 1129 1252 1383 1525 1674];
else
	if strcmpi(class(Ctp_tot_res_forc_mdl),'RSACSC.Parameter')
		Ctp_tot_res_forc_mdl.Value  = [216 219 229 250 275 309 349 396 449 509 576 650 731 819 915 1019 1129 1252 1383 1525 1674];
	else
		Ctp_tot_res_forc_mdl        = [216 219 229 250 275 309 349 396 449 509 576 650 731 819 915 1019 1129 1252 1383 1525 1674];
	end
end

%% Cxx_esti_forc_min_thd - Minimal estimated wheels force to enable the computations
if (exist('Cxx_esti_forc_min_thd','var')==0)              % 
	Cxx_esti_forc_min_thd         = 100;
else
	if strcmpi(class(Cxx_esti_forc_min_thd),'RSACSC.Parameter')
		Cxx_esti_forc_min_thd.Value = 100;
	else
		Cxx_esti_forc_min_thd       = 100;
	end
end

%% Cxx_forc_brk_frz_dly - Temporisation activated after brake release to maintain computations desactivated.
if (exist('Cxx_forc_brk_frz_dly','var')==0)               % 
	Cxx_forc_brk_frz_dly          = 0.6;
else
	if strcmpi(class(Cxx_forc_brk_frz_dly),'RSACSC.Parameter')
		Cxx_forc_brk_frz_dly.Value  = 0.6;
	else
		Cxx_forc_brk_frz_dly        = 0.6;
	end
end

%% Cxx_forc_dif_acc_brk_thd - Threshold of acceleration below which an offset is applied to Vxx_forc_dif while braking
if (exist('Cxx_forc_dif_acc_brk_thd','var')==0)           % 
	Cxx_forc_dif_acc_brk_thd      = 0.5;
else
	if strcmpi(class(Cxx_forc_dif_acc_brk_thd),'RSACSC.Parameter')
		Cxx_forc_dif_acc_brk_thd.Value= 0.5;
	else
		Cxx_forc_dif_acc_brk_thd    = 0.5;
	end
end

%% Cxx_forc_dif_avg_max - Maximum value of Vxx_forc_dif_avg.
if (exist('Cxx_forc_dif_avg_max','var')==0)               % 
	Cxx_forc_dif_avg_max          = 600;
else
	if strcmpi(class(Cxx_forc_dif_avg_max),'RSACSC.Parameter')
		Cxx_forc_dif_avg_max.Value  = 600;
	else
		Cxx_forc_dif_avg_max        = 600;
	end
end

%% Cxx_forc_dif_avg_min - Minimum value of Vxx_forc_dif_avg.
if (exist('Cxx_forc_dif_avg_min','var')==0)               % 
	Cxx_forc_dif_avg_min          = 0;
else
	if strcmpi(class(Cxx_forc_dif_avg_min),'RSACSC.Parameter')
		Cxx_forc_dif_avg_min.Value  = 0;
	else
		Cxx_forc_dif_avg_min        = 0;
	end
end

%% Cxx_forc_dif_coef_bend - Coeff to take into account the transverse acceleration for the forc dif calculation
if (exist('Cxx_forc_dif_coef_bend','var')==0)             % 
	Cxx_forc_dif_coef_bend        = 85;
else
	if strcmpi(class(Cxx_forc_dif_coef_bend),'RSACSC.Parameter')
		Cxx_forc_dif_coef_bend.Value= 85;
	else
		Cxx_forc_dif_coef_bend      = 85;
	end
end

%% Cxx_forc_dif_tau - Time constante in second for the first order filter
if (exist('Cxx_forc_dif_tau','var')==0)                   % 
	Cxx_forc_dif_tau              = 0;
else
	if strcmpi(class(Cxx_forc_dif_tau),'RSACSC.Parameter')
		Cxx_forc_dif_tau.Value      = 0;
	else
		Cxx_forc_dif_tau            = 0;
	end
end

%% Cxx_forc_dif_tau_avg_dec - Time constante in second for the first order filter
if (exist('Cxx_forc_dif_tau_avg_dec','var')==0)           % 
	Cxx_forc_dif_tau_avg_dec      = 1;
else
	if strcmpi(class(Cxx_forc_dif_tau_avg_dec),'RSACSC.Parameter')
		Cxx_forc_dif_tau_avg_dec.Value= 1;
	else
		Cxx_forc_dif_tau_avg_dec    = 1;
	end
end

%% Cxx_forc_dif_tau_avg_inc - Time constante in second for the first order filter
if (exist('Cxx_forc_dif_tau_avg_inc','var')==0)           % 
	Cxx_forc_dif_tau_avg_inc      = 1;
else
	if strcmpi(class(Cxx_forc_dif_tau_avg_inc),'RSACSC.Parameter')
		Cxx_forc_dif_tau_avg_inc.Value= 1;
	else
		Cxx_forc_dif_tau_avg_inc    = 1;
	end
end

%% Cxx_forc_dif_tm_brk_del - Temporisation activated after brake release to maintain Vxx_forc_dif_avg computations desactivated.
if (exist('Cxx_forc_dif_tm_brk_del','var')==0)            % 
	Cxx_forc_dif_tm_brk_del       = 1.6;
else
	if strcmpi(class(Cxx_forc_dif_tm_brk_del),'RSACSC.Parameter')
		Cxx_forc_dif_tm_brk_del.Value= 1.6;
	else
		Cxx_forc_dif_tm_brk_del     = 1.6;
	end
end

%% Cxx_forc_dif_vs_hys - Vehicle speed hysteresys for forc_dif freeze threshold
if (exist('Cxx_forc_dif_vs_hys','var')==0)                % 
	Cxx_forc_dif_vs_hys           = 0;
else
	if strcmpi(class(Cxx_forc_dif_vs_hys),'RSACSC.Parameter')
		Cxx_forc_dif_vs_hys.Value   = 0;
	else
		Cxx_forc_dif_vs_hys         = 0;
	end
end

%% Cxx_forc_dif_vs_min_thd - Minimal vehicle speed to enable the computations.
if (exist('Cxx_forc_dif_vs_min_thd','var')==0)            % 
	Cxx_forc_dif_vs_min_thd       = 7.5;
else
	if strcmpi(class(Cxx_forc_dif_vs_min_thd),'RSACSC.Parameter')
		Cxx_forc_dif_vs_min_thd.Value= 7.5;
	else
		Cxx_forc_dif_vs_min_thd     = 7.5;
	end
end

%% Cxx_forc_dif_vs_ofs_thd - Minimum vehicle speed to activate the conditions of the offset calculation when braking.
if (exist('Cxx_forc_dif_vs_ofs_thd','var')==0)            % 
	Cxx_forc_dif_vs_ofs_thd       = 1;
else
	if strcmpi(class(Cxx_forc_dif_vs_ofs_thd),'RSACSC.Parameter')
		Cxx_forc_dif_vs_ofs_thd.Value= 1;
	else
		Cxx_forc_dif_vs_ofs_thd     = 1;
	end
end

%% Cxx_no_use_tot_res_forc_mdl_vld - Confirmation time for not use of tot_res_forc mdl
if (exist('Cxx_no_use_tot_res_forc_mdl_vld','var')==0)    % 
	Cxx_no_use_tot_res_forc_mdl_vld= 0.5;
else
	if strcmpi(class(Cxx_no_use_tot_res_forc_mdl_vld),'RSACSC.Parameter')
		Cxx_no_use_tot_res_forc_mdl_vld.Value= 0.5;
	else
		Cxx_no_use_tot_res_forc_mdl_vld= 0.5;
	end
end

%% Cxx_tot_res_forc_swi_neg_slop - Negative slope value for transition between tot_res_forc calculated and model
if (exist('Cxx_tot_res_forc_swi_neg_slop','var')==0)      % 
	Cxx_tot_res_forc_swi_neg_slop = -300;
else
	if strcmpi(class(Cxx_tot_res_forc_swi_neg_slop),'RSACSC.Parameter')
		Cxx_tot_res_forc_swi_neg_slop.Value= -300;
	else
		Cxx_tot_res_forc_swi_neg_slop= -300;
	end
end

%% Cxx_tot_res_forc_swi_pos_slop - Positive slope value for transition between tot_res_forc calculated and model
if (exist('Cxx_tot_res_forc_swi_pos_slop','var')==0)      % 
	Cxx_tot_res_forc_swi_pos_slop = 300;
else
	if strcmpi(class(Cxx_tot_res_forc_swi_pos_slop),'RSACSC.Parameter')
		Cxx_tot_res_forc_swi_pos_slop.Value= 300;
	else
		Cxx_tot_res_forc_swi_pos_slop= 300;
	end
end

%% Cxx_tot_res_forc_tau - Time constante in second for the first order filter
if (exist('Cxx_tot_res_forc_tau','var')==0)               % 
	Cxx_tot_res_forc_tau          = 0;
else
	if strcmpi(class(Cxx_tot_res_forc_tau),'RSACSC.Parameter')
		Cxx_tot_res_forc_tau.Value  = 0;
	else
		Cxx_tot_res_forc_tau        = 0;
	end
end

%% Cxx_tq_dif_no_frz_vld - Confirmation time after tq_dif un-freeze to switch on classic tq_dif
if (exist('Cxx_tq_dif_no_frz_vld','var')==0)              % 
	Cxx_tq_dif_no_frz_vld         = 0.5;
else
	if strcmpi(class(Cxx_tq_dif_no_frz_vld),'RSACSC.Parameter')
		Cxx_tq_dif_no_frz_vld.Value = 0.5;
	else
		Cxx_tq_dif_no_frz_vld       = 0.5;
	end
end

%% Cxx_tq_dif_swi_neg_slop - Negative slope value for transition between classic and ESP tq_dif
if (exist('Cxx_tq_dif_swi_neg_slop','var')==0)            % 
	Cxx_tq_dif_swi_neg_slop       = -100;
else
	if strcmpi(class(Cxx_tq_dif_swi_neg_slop),'RSACSC.Parameter')
		Cxx_tq_dif_swi_neg_slop.Value= -100;
	else
		Cxx_tq_dif_swi_neg_slop     = -100;
	end
end

%% Cxx_tq_dif_swi_pos_slop - Positive slope value for transition between classic and ESP tq_dif
if (exist('Cxx_tq_dif_swi_pos_slop','var')==0)            % 
	Cxx_tq_dif_swi_pos_slop       = 100;
else
	if strcmpi(class(Cxx_tq_dif_swi_pos_slop),'RSACSC.Parameter')
		Cxx_tq_dif_swi_pos_slop.Value= 100;
	else
		Cxx_tq_dif_swi_pos_slop     = 100;
	end
end

%% Cxx_tra_acel_fdif_tau - Time constante in second for the first order filter
if (exist('Cxx_tra_acel_fdif_tau','var')==0)              % 
	Cxx_tra_acel_fdif_tau         = 0;
else
	if strcmpi(class(Cxx_tra_acel_fdif_tau),'RSACSC.Parameter')
		Cxx_tra_acel_fdif_tau.Value = 0;
	else
		Cxx_tra_acel_fdif_tau       = 0;
	end
end

%% Nsx_always_use_acel_slop - 2 : always use road_slop using ESP in replacment of classic_tq_dif
if (exist('Nsx_always_use_acel_slop','var')==0)           % 
	Nsx_always_use_acel_slop      = 2;
else
	if strcmpi(class(Nsx_always_use_acel_slop),'RSACSC.Parameter')
		Nsx_always_use_acel_slop.Value= 2;
	else
		Nsx_always_use_acel_slop    = 2;
	end
end

%% Nsx_dls_1 - Driveline state in 1
if (exist('Nsx_dls_1','var')==0)                          % 
	Nsx_dls_1                     = 1;
else
	if strcmpi(class(Nsx_dls_1),'RSACSC.Parameter')
		Nsx_dls_1.Value             = 1;
	else
		Nsx_dls_1                   = 1;
	end
end

%% Nsx_dls_10 - Driveline state in 10
if (exist('Nsx_dls_10','var')==0)                         % 
	Nsx_dls_10                    = 10;
else
	if strcmpi(class(Nsx_dls_10),'RSACSC.Parameter')
		Nsx_dls_10.Value            = 10;
	else
		Nsx_dls_10                  = 10;
	end
end

%% Nsx_dls_11 - Driveline state in 11
if (exist('Nsx_dls_11','var')==0)                         % 
	Nsx_dls_11                    = 11;
else
	if strcmpi(class(Nsx_dls_11),'RSACSC.Parameter')
		Nsx_dls_11.Value            = 11;
	else
		Nsx_dls_11                  = 11;
	end
end

%% Nsx_dls_12 - Driveline state in 12
if (exist('Nsx_dls_12','var')==0)                         % 
	Nsx_dls_12                    = 12;
else
	if strcmpi(class(Nsx_dls_12),'RSACSC.Parameter')
		Nsx_dls_12.Value            = 12;
	else
		Nsx_dls_12                  = 12;
	end
end

%% Nsx_dls_13 - Driveline state in 13
if (exist('Nsx_dls_13','var')==0)                         % 
	Nsx_dls_13                    = 13;
else
	if strcmpi(class(Nsx_dls_13),'RSACSC.Parameter')
		Nsx_dls_13.Value            = 13;
	else
		Nsx_dls_13                  = 13;
	end
end

%% Nsx_dls_14 - Driveline state in 14
if (exist('Nsx_dls_14','var')==0)                         % 
	Nsx_dls_14                    = 14;
else
	if strcmpi(class(Nsx_dls_14),'RSACSC.Parameter')
		Nsx_dls_14.Value            = 14;
	else
		Nsx_dls_14                  = 14;
	end
end

%% Nsx_dls_15 - Driveline state in 15.
if (exist('Nsx_dls_15','var')==0)                         % 
	Nsx_dls_15                    = 15;
else
	if strcmpi(class(Nsx_dls_15),'RSACSC.Parameter')
		Nsx_dls_15.Value            = 15;
	else
		Nsx_dls_15                  = 15;
	end
end

%% Nsx_dls_2 - Driveline state in 2
if (exist('Nsx_dls_2','var')==0)                          % 
	Nsx_dls_2                     = 2;
else
	if strcmpi(class(Nsx_dls_2),'RSACSC.Parameter')
		Nsx_dls_2.Value             = 2;
	else
		Nsx_dls_2                   = 2;
	end
end

%% Nsx_dls_3 - Driveline state in 3
if (exist('Nsx_dls_3','var')==0)                          % 
	Nsx_dls_3                     = 3;
else
	if strcmpi(class(Nsx_dls_3),'RSACSC.Parameter')
		Nsx_dls_3.Value             = 3;
	else
		Nsx_dls_3                   = 3;
	end
end

%% Nsx_dls_4 - Driveline state in 4
if (exist('Nsx_dls_4','var')==0)                          % 
	Nsx_dls_4                     = 4;
else
	if strcmpi(class(Nsx_dls_4),'RSACSC.Parameter')
		Nsx_dls_4.Value             = 4;
	else
		Nsx_dls_4                   = 4;
	end
end

%% Nsx_dls_5 - Driveline state in 5
if (exist('Nsx_dls_5','var')==0)                          % 
	Nsx_dls_5                     = 5;
else
	if strcmpi(class(Nsx_dls_5),'RSACSC.Parameter')
		Nsx_dls_5.Value             = 5;
	else
		Nsx_dls_5                   = 5;
	end
end

%% Nsx_dls_6 - Driveline state in 6
if (exist('Nsx_dls_6','var')==0)                          % 
	Nsx_dls_6                     = 6;
else
	if strcmpi(class(Nsx_dls_6),'RSACSC.Parameter')
		Nsx_dls_6.Value             = 6;
	else
		Nsx_dls_6                   = 6;
	end
end

%% Nsx_dls_7 - Driveline state in 7
if (exist('Nsx_dls_7','var')==0)                          % 
	Nsx_dls_7                     = 7;
else
	if strcmpi(class(Nsx_dls_7),'RSACSC.Parameter')
		Nsx_dls_7.Value             = 7;
	else
		Nsx_dls_7                   = 7;
	end
end

%% Nsx_dls_8 - Driveline state in 8
if (exist('Nsx_dls_8','var')==0)                          % 
	Nsx_dls_8                     = 8;
else
	if strcmpi(class(Nsx_dls_8),'RSACSC.Parameter')
		Nsx_dls_8.Value             = 8;
	else
		Nsx_dls_8                   = 8;
	end
end

%% Nsx_dls_9 - Driveline state in 9
if (exist('Nsx_dls_9','var')==0)                          % 
	Nsx_dls_9                     = 9;
else
	if strcmpi(class(Nsx_dls_9),'RSACSC.Parameter')
		Nsx_dls_9.Value             = 9;
	else
		Nsx_dls_9                   = 9;
	end
end

%% Nsx_dls_neut - Driveline state in neutral
if (exist('Nsx_dls_neut','var')==0)                       % 
	Nsx_dls_neut                  = 0;
else
	if strcmpi(class(Nsx_dls_neut),'RSACSC.Parameter')
		Nsx_dls_neut.Value          = 0;
	else
		Nsx_dls_neut                = 0;
	end
end

%% Nsx_dls_rvr_1 - Driveline state in reverse 1
if (exist('Nsx_dls_rvr_1','var')==0)                      % 
	Nsx_dls_rvr_1                 = -1;
else
	if strcmpi(class(Nsx_dls_rvr_1),'RSACSC.Parameter')
		Nsx_dls_rvr_1.Value         = -1;
	else
		Nsx_dls_rvr_1               = -1;
	end
end

%% Nsx_dls_rvr_2 - Driveline state in 2.
if (exist('Nsx_dls_rvr_2','var')==0)                      % 
	Nsx_dls_rvr_2                 = -2;
else
	if strcmpi(class(Nsx_dls_rvr_2),'RSACSC.Parameter')
		Nsx_dls_rvr_2.Value         = -2;
	else
		Nsx_dls_rvr_2               = -2;
	end
end

%% Nsx_never_use_acel_slop - 0 : no ESP or road_slope using ESP is not tuned
if (exist('Nsx_never_use_acel_slop','var')==0)            % 
	Nsx_never_use_acel_slop       = 0;
else
	if strcmpi(class(Nsx_never_use_acel_slop),'RSACSC.Parameter')
		Nsx_never_use_acel_slop.Value= 0;
	else
		Nsx_never_use_acel_slop     = 0;
	end
end

%% Nsx_sometimes_use_acel_slop - 1 : use of road_slope using ESP when classic tq_dif is frozen
if (exist('Nsx_sometimes_use_acel_slop','var')==0)        % 
	Nsx_sometimes_use_acel_slop   = 1;
else
	if strcmpi(class(Nsx_sometimes_use_acel_slop),'RSACSC.Parameter')
		Nsx_sometimes_use_acel_slop.Value= 1;
	else
		Nsx_sometimes_use_acel_slop = 1;
	end
end

%% Nsx_vld_fail_2 - Limp home data (1)
if (exist('Nsx_vld_fail_2','var')==0)                     % 
	Nsx_vld_fail_2                = 2;
else
	if strcmpi(class(Nsx_vld_fail_2),'RSACSC.Parameter')
		Nsx_vld_fail_2.Value        = 2;
	else
		Nsx_vld_fail_2              = 2;
	end
end

%% Nsx_vld_fail_3 - Limp home data (2)
if (exist('Nsx_vld_fail_3','var')==0)                     % 
	Nsx_vld_fail_3                = 3;
else
	if strcmpi(class(Nsx_vld_fail_3),'RSACSC.Parameter')
		Nsx_vld_fail_3.Value        = 3;
	else
		Nsx_vld_fail_3              = 3;
	end
end

%% Nsx_vld_fail_4 - Limp home data (3)
if (exist('Nsx_vld_fail_4','var')==0)                     % 
	Nsx_vld_fail_4                = 4;
else
	if strcmpi(class(Nsx_vld_fail_4),'RSACSC.Parameter')
		Nsx_vld_fail_4.Value        = 4;
	else
		Nsx_vld_fail_4              = 4;
	end
end

%% Nsx_vld_nok_0 - Invalid data
if (exist('Nsx_vld_nok_0','var')==0)                      % 
	Nsx_vld_nok_0                 = 0;
else
	if strcmpi(class(Nsx_vld_nok_0),'RSACSC.Parameter')
		Nsx_vld_nok_0.Value         = 0;
	else
		Nsx_vld_nok_0               = 0;
	end
end

%% Nsx_vld_ok_1 - Valid data
if (exist('Nsx_vld_ok_1','var')==0)                       % 
	Nsx_vld_ok_1                  = 1;
else
	if strcmpi(class(Nsx_vld_ok_1),'RSACSC.Parameter')
		Nsx_vld_ok_1.Value          = 1;
	else
		Nsx_vld_ok_1                = 1;
	end
end

%% Ntb_dls - Breakpoints of the driveline state 
if (exist('Ntb_dls','var')==0)                            % 
	Ntb_dls                       = [-2 -1 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15];
else
	if strcmpi(class(Ntb_dls),'RSACSC.Parameter')
		Ntb_dls.Value               = [-2 -1 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15];
	else
		Ntb_dls                     = [-2 -1 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15];
	end
end

%% Nxx_fdif_samp - Fdif specification sample time.
if (exist('Nxx_fdif_samp','var')==0)                      % 
	Nxx_fdif_samp                 = 0.02;
else
	if strcmpi(class(Nxx_fdif_samp),'RSACSC.Parameter')
		Nxx_fdif_samp.Value         = 0.02;
	else
		Nxx_fdif_samp               = 0.02;
	end
end

% EOF a_in_pci_rds_fdifxxx_xxx_xx_x_a.m