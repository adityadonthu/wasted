% Initialization file for a_in_pci_rds_hevxstb_stb_xx_x_a
%===============================================================================================
% FileName Cal_a_in_pci_rds_hevxstb_stb_xx_x_a.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:09                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Nsx_dls_1 - Units: "wu" - Driveline state in 1
if (exist('Nsx_dls_1','var')==0)                          % 
	Nsx_dls_1                     = 1;
else
	if strcmpi(class(Nsx_dls_1),'RSACSC.Parameter')
		Nsx_dls_1.Value             = 1;
	else
		Nsx_dls_1                   = 1;
	end
end

%% Nsx_dls_10 - Units: "wu" - Driveline state in 10
if (exist('Nsx_dls_10','var')==0)                         % 
	Nsx_dls_10                    = 10;
else
	if strcmpi(class(Nsx_dls_10),'RSACSC.Parameter')
		Nsx_dls_10.Value            = 10;
	else
		Nsx_dls_10                  = 10;
	end
end

%% Nsx_dls_11 - Units: "wu" - Driveline state in 11
if (exist('Nsx_dls_11','var')==0)                         % 
	Nsx_dls_11                    = 11;
else
	if strcmpi(class(Nsx_dls_11),'RSACSC.Parameter')
		Nsx_dls_11.Value            = 11;
	else
		Nsx_dls_11                  = 11;
	end
end

%% Nsx_dls_12 - Units: "wu" - Driveline state in 12
if (exist('Nsx_dls_12','var')==0)                         % 
	Nsx_dls_12                    = 12;
else
	if strcmpi(class(Nsx_dls_12),'RSACSC.Parameter')
		Nsx_dls_12.Value            = 12;
	else
		Nsx_dls_12                  = 12;
	end
end

%% Nsx_dls_13 - Units: "wu" - Driveline state in 13
if (exist('Nsx_dls_13','var')==0)                         % 
	Nsx_dls_13                    = 13;
else
	if strcmpi(class(Nsx_dls_13),'RSACSC.Parameter')
		Nsx_dls_13.Value            = 13;
	else
		Nsx_dls_13                  = 13;
	end
end

%% Nsx_dls_14 - Units: "wu" - Driveline state in 14
if (exist('Nsx_dls_14','var')==0)                         % 
	Nsx_dls_14                    = 14;
else
	if strcmpi(class(Nsx_dls_14),'RSACSC.Parameter')
		Nsx_dls_14.Value            = 14;
	else
		Nsx_dls_14                  = 14;
	end
end

%% Nsx_dls_15 - Units: "wu" - Driveline state in 15.
if (exist('Nsx_dls_15','var')==0)                         % 
	Nsx_dls_15                    = 15;
else
	if strcmpi(class(Nsx_dls_15),'RSACSC.Parameter')
		Nsx_dls_15.Value            = 15;
	else
		Nsx_dls_15                  = 15;
	end
end

%% Nsx_dls_16 - Units: "wu" - Driveline state in 16
if (exist('Nsx_dls_16','var')==0)                         % 
	Nsx_dls_16                    = 16;
else
	if strcmpi(class(Nsx_dls_16),'RSACSC.Parameter')
		Nsx_dls_16.Value            = 16;
	else
		Nsx_dls_16                  = 16;
	end
end

%% Nsx_dls_17 - Units: "wu" - Driveline state in 17
if (exist('Nsx_dls_17','var')==0)                         % 
	Nsx_dls_17                    = 17;
else
	if strcmpi(class(Nsx_dls_17),'RSACSC.Parameter')
		Nsx_dls_17.Value            = 17;
	else
		Nsx_dls_17                  = 17;
	end
end

%% Nsx_dls_18 - Units: "wu" - Driveline state in 18
if (exist('Nsx_dls_18','var')==0)                         % 
	Nsx_dls_18                    = 18;
else
	if strcmpi(class(Nsx_dls_18),'RSACSC.Parameter')
		Nsx_dls_18.Value            = 18;
	else
		Nsx_dls_18                  = 18;
	end
end

%% Nsx_dls_19 - Units: "wu" - Driveline state in 19
if (exist('Nsx_dls_19','var')==0)                         % 
	Nsx_dls_19                    = 19;
else
	if strcmpi(class(Nsx_dls_19),'RSACSC.Parameter')
		Nsx_dls_19.Value            = 19;
	else
		Nsx_dls_19                  = 19;
	end
end

%% Nsx_dls_2 - Units: "wu" - Driveline state in 2
if (exist('Nsx_dls_2','var')==0)                          % 
	Nsx_dls_2                     = 2;
else
	if strcmpi(class(Nsx_dls_2),'RSACSC.Parameter')
		Nsx_dls_2.Value             = 2;
	else
		Nsx_dls_2                   = 2;
	end
end

%% Nsx_dls_20 - Units: "wu" - Driveline state in 20
if (exist('Nsx_dls_20','var')==0)                         % 
	Nsx_dls_20                    = 20;
else
	if strcmpi(class(Nsx_dls_20),'RSACSC.Parameter')
		Nsx_dls_20.Value            = 20;
	else
		Nsx_dls_20                  = 20;
	end
end

%% Nsx_dls_21 - Units: "wu" - Driveline state in 21
if (exist('Nsx_dls_21','var')==0)                         % 
	Nsx_dls_21                    = 21;
else
	if strcmpi(class(Nsx_dls_21),'RSACSC.Parameter')
		Nsx_dls_21.Value            = 21;
	else
		Nsx_dls_21                  = 21;
	end
end

%% Nsx_dls_22 - Units: "wu" - Driveline state in 22
if (exist('Nsx_dls_22','var')==0)                         % 
	Nsx_dls_22                    = 22;
else
	if strcmpi(class(Nsx_dls_22),'RSACSC.Parameter')
		Nsx_dls_22.Value            = 22;
	else
		Nsx_dls_22                  = 22;
	end
end

%% Nsx_dls_23 - Units: "wu" - Nsx_dls_23
if (exist('Nsx_dls_23','var')==0)                         % 
	Nsx_dls_23                    = 23;
else
	if strcmpi(class(Nsx_dls_23),'RSACSC.Parameter')
		Nsx_dls_23.Value            = 23;
	else
		Nsx_dls_23                  = 23;
	end
end

%% Nsx_dls_24 - Units: "wu" - Driveline state in 24
if (exist('Nsx_dls_24','var')==0)                         % 
	Nsx_dls_24                    = 24;
else
	if strcmpi(class(Nsx_dls_24),'RSACSC.Parameter')
		Nsx_dls_24.Value            = 24;
	else
		Nsx_dls_24                  = 24;
	end
end

%% Nsx_dls_25 - Units: "wu" - Driveline state in 25
if (exist('Nsx_dls_25','var')==0)                         % 
	Nsx_dls_25                    = 25;
else
	if strcmpi(class(Nsx_dls_25),'RSACSC.Parameter')
		Nsx_dls_25.Value            = 25;
	else
		Nsx_dls_25                  = 25;
	end
end

%% Nsx_dls_26 - Units: "wu" - Driveline state in 26
if (exist('Nsx_dls_26','var')==0)                         % 
	Nsx_dls_26                    = 26;
else
	if strcmpi(class(Nsx_dls_26),'RSACSC.Parameter')
		Nsx_dls_26.Value            = 26;
	else
		Nsx_dls_26                  = 26;
	end
end

%% Nsx_dls_3 - Units: "wu" - Driveline state in 3
if (exist('Nsx_dls_3','var')==0)                          % 
	Nsx_dls_3                     = 3;
else
	if strcmpi(class(Nsx_dls_3),'RSACSC.Parameter')
		Nsx_dls_3.Value             = 3;
	else
		Nsx_dls_3                   = 3;
	end
end

%% Nsx_dls_4 - Units: "wu" - Driveline state in 4
if (exist('Nsx_dls_4','var')==0)                          % 
	Nsx_dls_4                     = 4;
else
	if strcmpi(class(Nsx_dls_4),'RSACSC.Parameter')
		Nsx_dls_4.Value             = 4;
	else
		Nsx_dls_4                   = 4;
	end
end

%% Nsx_dls_5 - Units: "wu" - Driveline state in 5
if (exist('Nsx_dls_5','var')==0)                          % 
	Nsx_dls_5                     = 5;
else
	if strcmpi(class(Nsx_dls_5),'RSACSC.Parameter')
		Nsx_dls_5.Value             = 5;
	else
		Nsx_dls_5                   = 5;
	end
end

%% Nsx_dls_6 - Units: "wu" - Driveline state in 6
if (exist('Nsx_dls_6','var')==0)                          % 
	Nsx_dls_6                     = 6;
else
	if strcmpi(class(Nsx_dls_6),'RSACSC.Parameter')
		Nsx_dls_6.Value             = 6;
	else
		Nsx_dls_6                   = 6;
	end
end

%% Nsx_dls_7 - Units: "wu" - Driveline state in 7
if (exist('Nsx_dls_7','var')==0)                          % 
	Nsx_dls_7                     = 7;
else
	if strcmpi(class(Nsx_dls_7),'RSACSC.Parameter')
		Nsx_dls_7.Value             = 7;
	else
		Nsx_dls_7                   = 7;
	end
end

%% Nsx_dls_8 - Units: "wu" - Driveline state in 8
if (exist('Nsx_dls_8','var')==0)                          % 
	Nsx_dls_8                     = 8;
else
	if strcmpi(class(Nsx_dls_8),'RSACSC.Parameter')
		Nsx_dls_8.Value             = 8;
	else
		Nsx_dls_8                   = 8;
	end
end

%% Nsx_dls_9 - Units: "wu" - Driveline state in 9
if (exist('Nsx_dls_9','var')==0)                          % 
	Nsx_dls_9                     = 9;
else
	if strcmpi(class(Nsx_dls_9),'RSACSC.Parameter')
		Nsx_dls_9.Value             = 9;
	else
		Nsx_dls_9                   = 9;
	end
end

%% Nsx_dls_neut - Units: "wu" - Driveline state in neutral
if (exist('Nsx_dls_neut','var')==0)                       % 
	Nsx_dls_neut                  = 0;
else
	if strcmpi(class(Nsx_dls_neut),'RSACSC.Parameter')
		Nsx_dls_neut.Value          = 0;
	else
		Nsx_dls_neut                = 0;
	end
end

%% Nsx_dls_rvr_1 - Units: "wu" - Driveline state in reverse 1
if (exist('Nsx_dls_rvr_1','var')==0)                      % 
	Nsx_dls_rvr_1                 = -1;
else
	if strcmpi(class(Nsx_dls_rvr_1),'RSACSC.Parameter')
		Nsx_dls_rvr_1.Value         = -1;
	else
		Nsx_dls_rvr_1               = -1;
	end
end

%% Nsx_dls_rvr_2 - Units: "wu" - Driveline state in 2.
if (exist('Nsx_dls_rvr_2','var')==0)                      % 
	Nsx_dls_rvr_2                 = -2;
else
	if strcmpi(class(Nsx_dls_rvr_2),'RSACSC.Parameter')
		Nsx_dls_rvr_2.Value         = -2;
	else
		Nsx_dls_rvr_2               = -2;
	end
end

%% Nsx_vld_fail_2 - Units: "wu" - Limp home data (1)
if (exist('Nsx_vld_fail_2','var')==0)                     % 
	Nsx_vld_fail_2                = 2;
else
	if strcmpi(class(Nsx_vld_fail_2),'RSACSC.Parameter')
		Nsx_vld_fail_2.Value        = 2;
	else
		Nsx_vld_fail_2              = 2;
	end
end

%% Nsx_vld_nok_0 - Units: "wu" - Invalid data
if (exist('Nsx_vld_nok_0','var')==0)                      % 
	Nsx_vld_nok_0                 = 0;
else
	if strcmpi(class(Nsx_vld_nok_0),'RSACSC.Parameter')
		Nsx_vld_nok_0.Value         = 0;
	else
		Nsx_vld_nok_0               = 0;
	end
end

%% Nsx_vld_ok_1 - Units: "wu" - Valid data
if (exist('Nsx_vld_ok_1','var')==0)                       % 
	Nsx_vld_ok_1                  = 1;
else
	if strcmpi(class(Nsx_vld_ok_1),'RSACSC.Parameter')
		Nsx_vld_ok_1.Value          = 1;
	else
		Nsx_vld_ok_1                = 1;
	end
end

% EOF Cal_a_in_pci_rds_hevxstb_stb_xx_x_a.m