% Initialization file for a_in_pci_rds_schxxxx_xxx_xx_x_a
%===============================================================================================
% FileName Cal_a_in_pci_rds_schxxxx_xxx_xx_x_a.m
%-----------------------------------------------------------------------------------------------
% Created  : 2019-01-09 16:06:24                          Created by MBD_Export_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : P. Apperce - 66641
% Date     : 2019-01-09
%===============================================================================================

%% Nxx_atcu - Target ECU is an Automatic Transmission Control Unit
if (exist('Nxx_atcu','var')==0)                           % 
	Nxx_atcu                      = 2;
else
	if strcmpi(class(Nxx_atcu),'RSACSC.Parameter')
		Nxx_atcu.Value              = 2;
	else
		Nxx_atcu                    = 2;
	end
end

%% Nxx_ecm - Target ECU is an Engine Control Module
if (exist('Nxx_ecm','var')==0)                            % 
	Nxx_ecm                       = 1;
else
	if strcmpi(class(Nxx_ecm),'RSACSC.Parameter')
		Nxx_ecm.Value               = 1;
	else
		Nxx_ecm                     = 1;
	end
end

%% Nxx_ecu_typ_cfm - ECU type, list of (Nxx_ecm, Nxx_atcu, Nxx_ptcu, Nxx_scu, Nxx_hevc, Nxx_evc)
if (exist('Nxx_ecu_typ_cfm','var')==0)                    % 
	Nxx_ecu_typ_cfm               = 3;
else
	if strcmpi(class(Nxx_ecu_typ_cfm),'RSACSC.Parameter')
		Nxx_ecu_typ_cfm.Value       = 3;
	else
		Nxx_ecu_typ_cfm             = 3;
	end
end

%% Nxx_evc - Target ECU is a electric vehicule controler
if (exist('Nxx_evc','var')==0)                            % 
	Nxx_evc                       = 6;
else
	if strcmpi(class(Nxx_evc),'RSACSC.Parameter')
		Nxx_evc.Value               = 6;
	else
		Nxx_evc                     = 6;
	end
end

%% Nxx_hevc - Target ECU is a Hybrid Electric Vehicle Control Unit
if (exist('Nxx_hevc','var')==0)                           % 
	Nxx_hevc                      = 5;
else
	if strcmpi(class(Nxx_hevc),'RSACSC.Parameter')
		Nxx_hevc.Value              = 5;
	else
		Nxx_hevc                    = 5;
	end
end

%% Nxx_ptcu - Target ECU is a PowerTrain Control Module
if (exist('Nxx_ptcu','var')==0)                           % 
	Nxx_ptcu                      = 3;
else
	if strcmpi(class(Nxx_ptcu),'RSACSC.Parameter')
		Nxx_ptcu.Value              = 3;
	else
		Nxx_ptcu                    = 3;
	end
end

%% Nxx_scu - Target ECU is a Shifter Control Unit
if (exist('Nxx_scu','var')==0)                            % 
	Nxx_scu                       = 4;
else
	if strcmpi(class(Nxx_scu),'RSACSC.Parameter')
		Nxx_scu.Value               = 4;
	else
		Nxx_scu                     = 4;
	end
end

% EOF a_in_pci_rds_schxxxx_xxx_xx_x_a.m