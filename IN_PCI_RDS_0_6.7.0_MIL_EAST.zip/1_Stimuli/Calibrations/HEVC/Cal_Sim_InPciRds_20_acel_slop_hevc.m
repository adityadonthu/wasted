% Initialization file for Sim_InPciRds_20_acel_slop_hevc
%===============================================================================================
% FileName Cal_Sim_InPciRds_20_acel_slop_hevc.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:20                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Cbx_agb_lg_acel_ena - Units: "bool" - Boolean to choose between ESP sensor or AGB sensor for longitudinal acceleration
if (exist('Cbx_agb_lg_acel_ena','var')==0)                % 
	Cbx_agb_lg_acel_ena           = false;
else
	if strcmpi(class(Cbx_agb_lg_acel_ena),'RSACSC.Parameter')
		Cbx_agb_lg_acel_ena.Value   = false;
	else
		Cbx_agb_lg_acel_ena         = false;
	end
end

%% Cbx_forc_dif_opt_calc - Units: "bool" - Activate the calculation of Vxx_forc_dif even if current state is a reverse or a neutral state.
if (exist('Cbx_forc_dif_opt_calc','var')==0)              % 
	Cbx_forc_dif_opt_calc         = true;
else
	if strcmpi(class(Cbx_forc_dif_opt_calc),'RSACSC.Parameter')
		Cbx_forc_dif_opt_calc.Value = true;
	else
		Cbx_forc_dif_opt_calc       = true;
	end
end

%% Cbx_road_slop_esp - Units: "bool" - Activation of use of slope calculation using ESP sensor
if (exist('Cbx_road_slop_esp','var')==0)                  % 
	Cbx_road_slop_esp             = true;
else
	if strcmpi(class(Cbx_road_slop_esp),'RSACSC.Parameter')
		Cbx_road_slop_esp.Value     = true;
	else
		Cbx_road_slop_esp           = true;
	end
end

%% Cbx_tqdif_opt_1st_calc - Units: "bool" - Option to calculate Vxx_tq_diff in 1st gear, reverse gear and neutral.
if (exist('Cbx_tqdif_opt_1st_calc','var')==0)             % 
	Cbx_tqdif_opt_1st_calc        = true;
else
	if strcmpi(class(Cbx_tqdif_opt_1st_calc),'RSACSC.Parameter')
		Cbx_tqdif_opt_1st_calc.Value= true;
	else
		Cbx_tqdif_opt_1st_calc      = true;
	end
end

%% Csx_use_acel_slop - Units: "wu" - 0 : no ESP or road_slope using ESP is not tuned1 : use of road_slope using ESP when classic tq_dif is frozen2 : always use road_slop using ESP in replacment of classic_tq_dif
if (exist('Csx_use_acel_slop','var')==0)                  % 
	Csx_use_acel_slop             = 1;
else
	if strcmpi(class(Csx_use_acel_slop),'RSACSC.Parameter')
		Csx_use_acel_slop.Value     = 1;
	else
		Csx_use_acel_slop           = 1;
	end
end

%% Csx_use_acel_slop_tot_res_forc - Units: "wu" - 0 : no ESP or road_slope using ESP is not tuned1 : use of road_slope using ESP when tot_res_forc is calculated through model2 : always use road_slop using ESP in replacement of tot_res_forc_calc
if (exist('Csx_use_acel_slop_tot_res_forc','var')==0)     % 
	Csx_use_acel_slop_tot_res_forc= 1;
else
	if strcmpi(class(Csx_use_acel_slop_tot_res_forc),'RSACSC.Parameter')
		Csx_use_acel_slop_tot_res_forc.Value= 1;
	else
		Csx_use_acel_slop_tot_res_forc= 1;
	end
end

%% Ctd_esti_forc_fdif_tau - Units: "s" - Table of filtering time constant to apply on esti_forc. Depending of driveline state.
if (exist('Ctd_esti_forc_fdif_tau','var')==0)             % 
	Ctd_esti_forc_fdif_tau        = [0.1 0.1 0.1 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.2 0.2 0.2 0.2 0.2 0.2 0.2];
else
	if strcmpi(class(Ctd_esti_forc_fdif_tau),'RSACSC.Parameter')
		Ctd_esti_forc_fdif_tau.Value= [0.1 0.1 0.1 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.2 0.2 0.2 0.2 0.2 0.2 0.2];
	else
		Ctd_esti_forc_fdif_tau      = [0.1 0.1 0.1 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.2 0.2 0.2 0.2 0.2 0.2 0.2];
	end
end

%% Cxx_esti_forc_min_thd - Units: "N" - Minimal estimated wheels force to enable the computations
if (exist('Cxx_esti_forc_min_thd','var')==0)              % 
	Cxx_esti_forc_min_thd         = 30;
else
	if strcmpi(class(Cxx_esti_forc_min_thd),'RSACSC.Parameter')
		Cxx_esti_forc_min_thd.Value = 30;
	else
		Cxx_esti_forc_min_thd       = 30;
	end
end

%% Cxx_forc_dif_vs_hys - Units: "km/h" - Vehicle speed hysteresys for forc_dif freeze threshold
if (exist('Cxx_forc_dif_vs_hys','var')==0)                % 
	Cxx_forc_dif_vs_hys           = 4;
else
	if strcmpi(class(Cxx_forc_dif_vs_hys),'RSACSC.Parameter')
		Cxx_forc_dif_vs_hys.Value   = 4;
	else
		Cxx_forc_dif_vs_hys         = 4;
	end
end

%% Cxx_pow_r_slop_tau_fil - Units: "s" - first order filter time constant for resistive power using slope
if (exist('Cxx_pow_r_slop_tau_fil','var')==0)             % 
	Cxx_pow_r_slop_tau_fil        = 0.2;
else
	if strcmpi(class(Cxx_pow_r_slop_tau_fil),'RSACSC.Parameter')
		Cxx_pow_r_slop_tau_fil.Value= 0.2;
	else
		Cxx_pow_r_slop_tau_fil      = 0.2;
	end
end

%% Cxx_pow_r_swi_neg_slop - Units: "% / 0.01s" - Negative slope value for transition between resistive power calculation using torque or using slope
if (exist('Cxx_pow_r_swi_neg_slop','var')==0)             % 
	Cxx_pow_r_swi_neg_slop        = -1500;
else
	if strcmpi(class(Cxx_pow_r_swi_neg_slop),'RSACSC.Parameter')
		Cxx_pow_r_swi_neg_slop.Value= -1500;
	else
		Cxx_pow_r_swi_neg_slop      = -1500;
	end
end

%% Cxx_pow_r_swi_pos_slop - Units: "% / 0.01s" - Positive slope value for transition between resistive power calculation using torque or using slope
if (exist('Cxx_pow_r_swi_pos_slop','var')==0)             % 
	Cxx_pow_r_swi_pos_slop        = 1500;
else
	if strcmpi(class(Cxx_pow_r_swi_pos_slop),'RSACSC.Parameter')
		Cxx_pow_r_swi_pos_slop.Value= 1500;
	else
		Cxx_pow_r_swi_pos_slop      = 1500;
	end
end

%% Cxx_road_slop_neg_slop - Units: "% / 0.01s" - Negative slope value for transition between static and dynamic road slope calculation
if (exist('Cxx_road_slop_neg_slop','var')==0)             % 
	Cxx_road_slop_neg_slop        = -10;
else
	if strcmpi(class(Cxx_road_slop_neg_slop),'RSACSC.Parameter')
		Cxx_road_slop_neg_slop.Value= -10;
	else
		Cxx_road_slop_neg_slop      = -10;
	end
end

%% Cxx_road_slop_pos_slop - Units: "% / 0.01s" - Positive slope value for transition between static and dynamic road slope calculation
if (exist('Cxx_road_slop_pos_slop','var')==0)             % 
	Cxx_road_slop_pos_slop        = 10;
else
	if strcmpi(class(Cxx_road_slop_pos_slop),'RSACSC.Parameter')
		Cxx_road_slop_pos_slop.Value= 10;
	else
		Cxx_road_slop_pos_slop      = 10;
	end
end

%% Cxx_tq_dif_swi_neg_slop - Units: "% / 0.01s" - Negative slope value for transition between classic and ESP tq_dif
if (exist('Cxx_tq_dif_swi_neg_slop','var')==0)            % 
	Cxx_tq_dif_swi_neg_slop       = -500;
else
	if strcmpi(class(Cxx_tq_dif_swi_neg_slop),'RSACSC.Parameter')
		Cxx_tq_dif_swi_neg_slop.Value= -500;
	else
		Cxx_tq_dif_swi_neg_slop     = -500;
	end
end

%% Cxx_tq_dif_swi_pos_slop - Units: "% / 0.01s" - Positive slope value for transition between classic and ESP tq_dif
if (exist('Cxx_tq_dif_swi_pos_slop','var')==0)            % 
	Cxx_tq_dif_swi_pos_slop       = 500;
else
	if strcmpi(class(Cxx_tq_dif_swi_pos_slop),'RSACSC.Parameter')
		Cxx_tq_dif_swi_pos_slop.Value= 500;
	else
		Cxx_tq_dif_swi_pos_slop     = 500;
	end
end

%% Cxx_tqdif_brk_frz_dly - Units: "s" - Delay after braking during which the calculation of Vxx_tq_dif is frozen
if (exist('Cxx_tqdif_brk_frz_dly','var')==0)              % 
	Cxx_tqdif_brk_frz_dly         = 0;
else
	if strcmpi(class(Cxx_tqdif_brk_frz_dly),'RSACSC.Parameter')
		Cxx_tqdif_brk_frz_dly.Value = 0;
	else
		Cxx_tqdif_brk_frz_dly       = 0;
	end
end

%% Cxx_tqdif_tau_fil - Units: "s" - Time constante in second for  the first order filter
if (exist('Cxx_tqdif_tau_fil','var')==0)                  % 
	Cxx_tqdif_tau_fil             = 0.3;
else
	if strcmpi(class(Cxx_tqdif_tau_fil),'RSACSC.Parameter')
		Cxx_tqdif_tau_fil.Value     = 0.3;
	else
		Cxx_tqdif_tau_fil           = 0.3;
	end
end

%% Cxx_tqdif_tm_brk_del - Units: "s" - Temporization started after end of braking during which the calculation of Vxx_tq_dif is frozen
if (exist('Cxx_tqdif_tm_brk_del','var')==0)               % 
	Cxx_tqdif_tm_brk_del          = 0;
else
	if strcmpi(class(Cxx_tqdif_tm_brk_del),'RSACSC.Parameter')
		Cxx_tqdif_tm_brk_del.Value  = 0;
	else
		Cxx_tqdif_tm_brk_del        = 0;
	end
end

%% Nxx_ecu_typ_cfm - Units: "wu" - ECU type, list of (Nxx_ecm, Nxx_atcu, Nxx_ptcu, Nxx_scu, Nxx_hevc, Nxx_evc)
if (exist('Nxx_ecu_typ_cfm','var')==0)                    % 
	Nxx_ecu_typ_cfm               = 5;
else
	if strcmpi(class(Nxx_ecu_typ_cfm),'RSACSC.Parameter')
		Nxx_ecu_typ_cfm.Value       = 5;
	else
		Nxx_ecu_typ_cfm             = 5;
	end
end

%% Nxx_hsco_cfm - Units: "wu" - HSCO  configuration, list of (Nxx_hsco_abst, Nxx_hsco_pres, Nxx_hsco_cho)
if (exist('Nxx_hsco_cfm','var')==0)                       % 
	Nxx_hsco_cfm                  = 1;
else
	if strcmpi(class(Nxx_hsco_cfm),'RSACSC.Parameter')
		Nxx_hsco_cfm.Value          = 1;
	else
		Nxx_hsco_cfm                = 1;
	end
end

% EOF Cal_Sim_InPciRds_20_acel_slop_hevc.m