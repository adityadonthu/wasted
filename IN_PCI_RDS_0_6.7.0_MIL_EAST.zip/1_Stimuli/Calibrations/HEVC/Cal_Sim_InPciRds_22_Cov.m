% Initialization file for Sim_InPciRds_22_Cov
%===============================================================================================
% FileName Cal_Sim_InPciRds_22_Cov.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:23                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Csx_use_acel_slop - Units: "wu" - 0 : no ESP or road_slope using ESP is not tuned1 : use of road_slope using ESP when classic tq_dif is frozen2 : always use road_slop using ESP in replacment of classic_tq_dif
if (exist('Csx_use_acel_slop','var')==0)                  % 
	Csx_use_acel_slop             = 2;
else
	if strcmpi(class(Csx_use_acel_slop),'RSACSC.Parameter')
		Csx_use_acel_slop.Value     = 2;
	else
		Csx_use_acel_slop           = 2;
	end
end

%% Csx_use_acel_slop_tot_res_forc - Units: "wu" - 0 : no ESP or road_slope using ESP is not tuned1 : use of road_slope using ESP when tot_res_forc is calculated through model2 : always use road_slop using ESP in replacement of tot_res_forc_calc
if (exist('Csx_use_acel_slop_tot_res_forc','var')==0)     % 
	Csx_use_acel_slop_tot_res_forc= 2;
else
	if strcmpi(class(Csx_use_acel_slop_tot_res_forc),'RSACSC.Parameter')
		Csx_use_acel_slop_tot_res_forc.Value= 2;
	else
		Csx_use_acel_slop_tot_res_forc= 2;
	end
end

%% Cxx_tqdacel_vs_thd_stop - Units: "km/h" - Vehicle speed minimum to detect  stop condition
if (exist('Cxx_tqdacel_vs_thd_stop','var')==0)            % 
	Cxx_tqdacel_vs_thd_stop       = 5;
else
	if strcmpi(class(Cxx_tqdacel_vs_thd_stop),'RSACSC.Parameter')
		Cxx_tqdacel_vs_thd_stop.Value= 5;
	else
		Cxx_tqdacel_vs_thd_stop     = 5;
	end
end

%% Nxx_ecu_typ_cfm - Units: "wu" - ECU type, list of (Nxx_ecm, Nxx_atcu, Nxx_ptcu, Nxx_scu, Nxx_hevc, Nxx_evc)
if (exist('Nxx_ecu_typ_cfm','var')==0)                    % 
	Nxx_ecu_typ_cfm               = 5;
else
	if strcmpi(class(Nxx_ecu_typ_cfm),'RSACSC.Parameter')
		Nxx_ecu_typ_cfm.Value       = 5;
	else
		Nxx_ecu_typ_cfm             = 5;
	end
end

%% Nxx_hsco_cfm - Units: "wu" - HSCO  configuration, list of (Nxx_hsco_abst, Nxx_hsco_pres, Nxx_hsco_cho)
if (exist('Nxx_hsco_cfm','var')==0)                       % 
	Nxx_hsco_cfm                  = 1;
else
	if strcmpi(class(Nxx_hsco_cfm),'RSACSC.Parameter')
		Nxx_hsco_cfm.Value          = 1;
	else
		Nxx_hsco_cfm                = 1;
	end
end

% EOF Cal_Sim_InPciRds_22_Cov.m