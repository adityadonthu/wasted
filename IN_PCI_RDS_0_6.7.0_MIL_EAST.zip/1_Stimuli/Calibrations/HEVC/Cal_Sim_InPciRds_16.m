% Initialization file for Sim_InPciRds_16
%===============================================================================================
% FileName Cal_Sim_InPciRds_16.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:18                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Cxx_forc_dif_avg_max - Units: "N" - Maximum value of Vxx_forc_dif_avg.
if (exist('Cxx_forc_dif_avg_max','var')==0)               % 
	Cxx_forc_dif_avg_max          = 25;
else
	if strcmpi(class(Cxx_forc_dif_avg_max),'RSACSC.Parameter')
		Cxx_forc_dif_avg_max.Value  = 25;
	else
		Cxx_forc_dif_avg_max        = 25;
	end
end

%% Cxx_forc_dif_vs_min_thd - Units: "km/h" - Minimal vehicle speed to enable the computations.
if (exist('Cxx_forc_dif_vs_min_thd','var')==0)            % 
	Cxx_forc_dif_vs_min_thd       = 60;
else
	if strcmpi(class(Cxx_forc_dif_vs_min_thd),'RSACSC.Parameter')
		Cxx_forc_dif_vs_min_thd.Value= 60;
	else
		Cxx_forc_dif_vs_min_thd     = 60;
	end
end

%% Cxx_forc_dif_vs_ofs_thd - Units: "km/h" - Minimum vehicle speed to activate the conditions of the offset calculation when braking.
if (exist('Cxx_forc_dif_vs_ofs_thd','var')==0)            % 
	Cxx_forc_dif_vs_ofs_thd       = 60;
else
	if strcmpi(class(Cxx_forc_dif_vs_ofs_thd),'RSACSC.Parameter')
		Cxx_forc_dif_vs_ofs_thd.Value= 60;
	else
		Cxx_forc_dif_vs_ofs_thd     = 60;
	end
end

%% Nxx_ecu_typ_cfm - Units: "wu" - ECU type, list of (Nxx_ecm, Nxx_atcu, Nxx_ptcu, Nxx_scu, Nxx_hevc, Nxx_evc)
if (exist('Nxx_ecu_typ_cfm','var')==0)                    % 
	Nxx_ecu_typ_cfm               = 5;
else
	if strcmpi(class(Nxx_ecu_typ_cfm),'RSACSC.Parameter')
		Nxx_ecu_typ_cfm.Value       = 5;
	else
		Nxx_ecu_typ_cfm             = 5;
	end
end

%% Nxx_hsco_cfm - Units: "wu" - HSCO  configuration, list of (Nxx_hsco_abst, Nxx_hsco_pres, Nxx_hsco_cho)
if (exist('Nxx_hsco_cfm','var')==0)                       % 
	Nxx_hsco_cfm                  = 1;
else
	if strcmpi(class(Nxx_hsco_cfm),'RSACSC.Parameter')
		Nxx_hsco_cfm.Value          = 1;
	else
		Nxx_hsco_cfm                = 1;
	end
end

% EOF Cal_Sim_InPciRds_16.m