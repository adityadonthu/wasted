% Initialization file for a_in_pci_rds_tqdacel_xxx_xx_x_a
%===============================================================================================
% FileName Cal_a_in_pci_rds_tqdacel_xxx_xx_x_a.m
%-----------------------------------------------------------------------------------------------
% Created  : 2019-01-09 16:06:31                          Created by MBD_Export_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : P. Apperce - 66641
% Date     : 2019-01-09
%===============================================================================================

%% Cbx_agb_lg_acel_ena - Boolean to choose between ESP sensor or AGB sensor for longitudinal acceleration
if (exist('Cbx_agb_lg_acel_ena','var')==0)                % 
	Cbx_agb_lg_acel_ena           = true;
else
	if strcmpi(class(Cbx_agb_lg_acel_ena),'RSACSC.Parameter')
		Cbx_agb_lg_acel_ena.Value   = true;
	else
		Cbx_agb_lg_acel_ena         = true;
	end
end

%% Ctb_lg_acel_lfv_stop - Breakpoint for deceleration value
if (exist('Ctb_lg_acel_lfv_stop','var')==0)               % 
	Ctb_lg_acel_lfv_stop          = [-10 -5 -2 -1 0];
else
	if strcmpi(class(Ctb_lg_acel_lfv_stop),'RSACSC.Parameter')
		Ctb_lg_acel_lfv_stop.Value  = [-10 -5 -2 -1 0];
	else
		Ctb_lg_acel_lfv_stop        = [-10 -5 -2 -1 0];
	end
end

%% Ctb_tqdacel_vs_asc - table of  vehicle speed
if (exist('Ctb_tqdacel_vs_asc','var')==0)                 % 
	Ctb_tqdacel_vs_asc            = [0 1 2 3 4 5 10 15 20 30];
else
	if strcmpi(class(Ctb_tqdacel_vs_asc),'RSACSC.Parameter')
		Ctb_tqdacel_vs_asc.Value    = [0 1 2 3 4 5 10 15 20 30];
	else
		Ctb_tqdacel_vs_asc          = [0 1 2 3 4 5 10 15 20 30];
	end
end

%% Ctp_tqdacel_dly_stop - Interpolated table of delay of stop phasis duration
if (exist('Ctp_tqdacel_dly_stop','var')==0)               % 
	Ctp_tqdacel_dly_stop          = [2 2 1 0.5 0];
else
	if strcmpi(class(Ctp_tqdacel_dly_stop),'RSACSC.Parameter')
		Ctp_tqdacel_dly_stop.Value  = [2 2 1 0.5 0];
	else
		Ctp_tqdacel_dly_stop        = [2 2 1 0.5 0];
	end
end

%% Ctp_tqdacel_fwd_ftc - Filtering time constant for the normal driving condition
if (exist('Ctp_tqdacel_fwd_ftc','var')==0)                % 
	Ctp_tqdacel_fwd_ftc           = [0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174];
else
	if strcmpi(class(Ctp_tqdacel_fwd_ftc),'RSACSC.Parameter')
		Ctp_tqdacel_fwd_ftc.Value   = [0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174];
	else
		Ctp_tqdacel_fwd_ftc         = [0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174 0.3174];
	end
end

%% Ctp_tqdacel_fwd_pg - Proportional gain for the filtering of the normal driving 
if (exist('Ctp_tqdacel_fwd_pg','var')==0)                 % 
	Ctp_tqdacel_fwd_pg            = [0.87 0.87 0.87 0.87 0.87 0.87 0.87 0.87 0.87 0.87];
else
	if strcmpi(class(Ctp_tqdacel_fwd_pg),'RSACSC.Parameter')
		Ctp_tqdacel_fwd_pg.Value    = [0.87 0.87 0.87 0.87 0.87 0.87 0.87 0.87 0.87 0.87];
	else
		Ctp_tqdacel_fwd_pg          = [0.87 0.87 0.87 0.87 0.87 0.87 0.87 0.87 0.87 0.87];
	end
end

%% Ctp_tqdacel_stop_ftc - Time constant of filtering of the phase stop
if (exist('Ctp_tqdacel_stop_ftc','var')==0)               % 
	Ctp_tqdacel_stop_ftc          = [0.96 0.96 0.96 0.96 0.96];
else
	if strcmpi(class(Ctp_tqdacel_stop_ftc),'RSACSC.Parameter')
		Ctp_tqdacel_stop_ftc.Value  = [0.96 0.96 0.96 0.96 0.96];
	else
		Ctp_tqdacel_stop_ftc        = [0.96 0.96 0.96 0.96 0.96];
	end
end

%% Ctp_tqdacel_stop_pg - Proportional gain for the filtering of the phase stop
if (exist('Ctp_tqdacel_stop_pg','var')==0)                % 
	Ctp_tqdacel_stop_pg           = [0.28 0.28 0.28 0.28 0.28];
else
	if strcmpi(class(Ctp_tqdacel_stop_pg),'RSACSC.Parameter')
		Ctp_tqdacel_stop_pg.Value   = [0.28 0.28 0.28 0.28 0.28];
	else
		Ctp_tqdacel_stop_pg         = [0.28 0.28 0.28 0.28 0.28];
	end
end

%% Cxx_lg_acel_lfv_stop_t - Time constant for vehicle deceleration filtering before stop phasis
if (exist('Cxx_lg_acel_lfv_stop_t','var')==0)             % 
	Cxx_lg_acel_lfv_stop_t        = 0.25;
else
	if strcmpi(class(Cxx_lg_acel_lfv_stop_t),'RSACSC.Parameter')
		Cxx_lg_acel_lfv_stop_t.Value= 0.25;
	else
		Cxx_lg_acel_lfv_stop_t      = 0.25;
	end
end

%% Cxx_mux_lg_acel_max - Longitudinal acceleration max value
if (exist('Cxx_mux_lg_acel_max','var')==0)                % 
	Cxx_mux_lg_acel_max           = 2.67;
else
	if strcmpi(class(Cxx_mux_lg_acel_max),'RSACSC.Parameter')
		Cxx_mux_lg_acel_max.Value   = 2.67;
	else
		Cxx_mux_lg_acel_max         = 2.67;
	end
end

%% Cxx_mux_lg_acel_pg - Proportional gain for the filtering longitudinal acceleration 
if (exist('Cxx_mux_lg_acel_pg','var')==0)                 % 
	Cxx_mux_lg_acel_pg            = 2.3685;
else
	if strcmpi(class(Cxx_mux_lg_acel_pg),'RSACSC.Parameter')
		Cxx_mux_lg_acel_pg.Value    = 2.3685;
	else
		Cxx_mux_lg_acel_pg          = 2.3685;
	end
end

%% Cxx_tqdacel_fullstop_ftc - Constant time for the filtering of the full stop condition
if (exist('Cxx_tqdacel_fullstop_ftc','var')==0)           % 
	Cxx_tqdacel_fullstop_ftc      = 1.587;
else
	if strcmpi(class(Cxx_tqdacel_fullstop_ftc),'RSACSC.Parameter')
		Cxx_tqdacel_fullstop_ftc.Value= 1.587;
	else
		Cxx_tqdacel_fullstop_ftc    = 1.587;
	end
end

%% Cxx_tqdacel_fullstop_pg - Proportional gain for the filtering of the phase full stop condition
if (exist('Cxx_tqdacel_fullstop_pg','var')==0)            % 
	Cxx_tqdacel_fullstop_pg       = 0.1657;
else
	if strcmpi(class(Cxx_tqdacel_fullstop_pg),'RSACSC.Parameter')
		Cxx_tqdacel_fullstop_pg.Value= 0.1657;
	else
		Cxx_tqdacel_fullstop_pg     = 0.1657;
	end
end

%% Cxx_tqdacel_mux_lg_acel_ftc - Constant time to filtering longitudinal acceleration
if (exist('Cxx_tqdacel_mux_lg_acel_ftc','var')==0)        % 
	Cxx_tqdacel_mux_lg_acel_ftc   = 0.12;
else
	if strcmpi(class(Cxx_tqdacel_mux_lg_acel_ftc),'RSACSC.Parameter')
		Cxx_tqdacel_mux_lg_acel_ftc.Value= 0.12;
	else
		Cxx_tqdacel_mux_lg_acel_ftc = 0.12;
	end
end

%% Cxx_tqdacel_sta_ftc - Constant time to filtering start condition
if (exist('Cxx_tqdacel_sta_ftc','var')==0)                % 
	Cxx_tqdacel_sta_ftc           = 1.587;
else
	if strcmpi(class(Cxx_tqdacel_sta_ftc),'RSACSC.Parameter')
		Cxx_tqdacel_sta_ftc.Value   = 1.587;
	else
		Cxx_tqdacel_sta_ftc         = 1.587;
	end
end

%% Cxx_tqdacel_sta_pg - Proportional gain to filtering longitudinal acceleration
if (exist('Cxx_tqdacel_sta_pg','var')==0)                 % 
	Cxx_tqdacel_sta_pg            = 0.1657;
else
	if strcmpi(class(Cxx_tqdacel_sta_pg),'RSACSC.Parameter')
		Cxx_tqdacel_sta_pg.Value    = 0.1657;
	else
		Cxx_tqdacel_sta_pg          = 0.1657;
	end
end

%% Cxx_tqdacel_sta_tmr - duration of the phase start
if (exist('Cxx_tqdacel_sta_tmr','var')==0)                % 
	Cxx_tqdacel_sta_tmr           = 2;
else
	if strcmpi(class(Cxx_tqdacel_sta_tmr),'RSACSC.Parameter')
		Cxx_tqdacel_sta_tmr.Value   = 2;
	else
		Cxx_tqdacel_sta_tmr         = 2;
	end
end

%% Cxx_tqdacel_vs_thd_fwd - The vehicle speed max for the exit of the start condition
if (exist('Cxx_tqdacel_vs_thd_fwd','var')==0)             % 
	Cxx_tqdacel_vs_thd_fwd        = 15;
else
	if strcmpi(class(Cxx_tqdacel_vs_thd_fwd),'RSACSC.Parameter')
		Cxx_tqdacel_vs_thd_fwd.Value= 15;
	else
		Cxx_tqdacel_vs_thd_fwd      = 15;
	end
end

%% Cxx_tqdacel_vs_thd_sta - Vehicle speed minimum to detect  start condition
if (exist('Cxx_tqdacel_vs_thd_sta','var')==0)             % 
	Cxx_tqdacel_vs_thd_sta        = 2;
else
	if strcmpi(class(Cxx_tqdacel_vs_thd_sta),'RSACSC.Parameter')
		Cxx_tqdacel_vs_thd_sta.Value= 2;
	else
		Cxx_tqdacel_vs_thd_sta      = 2;
	end
end

%% Cxx_tqdacel_vs_thd_stop - Vehicle speed minimum to detect  stop condition
if (exist('Cxx_tqdacel_vs_thd_stop','var')==0)            % 
	Cxx_tqdacel_vs_thd_stop       = 1;
else
	if strcmpi(class(Cxx_tqdacel_vs_thd_stop),'RSACSC.Parameter')
		Cxx_tqdacel_vs_thd_stop.Value= 1;
	else
		Cxx_tqdacel_vs_thd_stop     = 1;
	end
end

%% Cxx_tqdif_veh_weight - Vehicle weight
if (exist('Cxx_tqdif_veh_weight','var')==0)               % 
	Cxx_tqdif_veh_weight          = 1408;
else
	if strcmpi(class(Cxx_tqdif_veh_weight),'RSACSC.Parameter')
		Cxx_tqdif_veh_weight.Value  = 1408;
	else
		Cxx_tqdif_veh_weight        = 1408;
	end
end

%% Cxx_whl_rad - in_pci_rds_fstqdxx_xxx_xx_x_a/Wheel radius
if (exist('Cxx_whl_rad','var')==0)                        % 
	Cxx_whl_rad                   = 0.308;
else
	if strcmpi(class(Cxx_whl_rad),'RSACSC.Parameter')
		Cxx_whl_rad.Value           = 0.308;
	else
		Cxx_whl_rad                 = 0.308;
	end
end

%% Nsx_vld_fail_2 - Limp home data (1)
if (exist('Nsx_vld_fail_2','var')==0)                     % 
	Nsx_vld_fail_2                = 2;
else
	if strcmpi(class(Nsx_vld_fail_2),'RSACSC.Parameter')
		Nsx_vld_fail_2.Value        = 2;
	else
		Nsx_vld_fail_2              = 2;
	end
end

%% Nsx_vld_fail_3 - Limp home data (2)
if (exist('Nsx_vld_fail_3','var')==0)                     % 
	Nsx_vld_fail_3                = 3;
else
	if strcmpi(class(Nsx_vld_fail_3),'RSACSC.Parameter')
		Nsx_vld_fail_3.Value        = 3;
	else
		Nsx_vld_fail_3              = 3;
	end
end

%% Nsx_vld_fail_4 - Limp home data (3)
if (exist('Nsx_vld_fail_4','var')==0)                     % 
	Nsx_vld_fail_4                = 4;
else
	if strcmpi(class(Nsx_vld_fail_4),'RSACSC.Parameter')
		Nsx_vld_fail_4.Value        = 4;
	else
		Nsx_vld_fail_4              = 4;
	end
end

%% Nsx_vld_nok_0 - Invalid data
if (exist('Nsx_vld_nok_0','var')==0)                      % 
	Nsx_vld_nok_0                 = 0;
else
	if strcmpi(class(Nsx_vld_nok_0),'RSACSC.Parameter')
		Nsx_vld_nok_0.Value         = 0;
	else
		Nsx_vld_nok_0               = 0;
	end
end

%% Nsx_vld_ok_1 - Valid data
if (exist('Nsx_vld_ok_1','var')==0)                       % 
	Nsx_vld_ok_1                  = 1;
else
	if strcmpi(class(Nsx_vld_ok_1),'RSACSC.Parameter')
		Nsx_vld_ok_1.Value          = 1;
	else
		Nsx_vld_ok_1                = 1;
	end
end

%% Nxx_tqdacel_samp - sample time
if (exist('Nxx_tqdacel_samp','var')==0)                   % 
	Nxx_tqdacel_samp              = 0.02;
else
	if strcmpi(class(Nxx_tqdacel_samp),'RSACSC.Parameter')
		Nxx_tqdacel_samp.Value      = 0.02;
	else
		Nxx_tqdacel_samp            = 0.02;
	end
end

% EOF a_in_pci_rds_tqdacel_xxx_xx_x_a.m