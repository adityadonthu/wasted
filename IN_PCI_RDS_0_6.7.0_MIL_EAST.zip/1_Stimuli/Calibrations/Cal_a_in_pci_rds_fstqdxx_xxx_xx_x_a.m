% Initialization file for a_in_pci_rds_fstqdxx_xxx_xx_x_a
%===============================================================================================
% FileName Cal_a_in_pci_rds_fstqdxx_xxx_xx_x_a.m
%-----------------------------------------------------------------------------------------------
% Created  : 2019-01-09 16:06:03                          Created by MBD_Export_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : P. Apperce - 66641
% Date     : 2019-01-09
%===============================================================================================

%% Cbx_atcu_ptcu_typ_cfm - Configration of ATCU or PTCU confirmation
if (exist('Cbx_atcu_ptcu_typ_cfm','var')==0)              % 
	Cbx_atcu_ptcu_typ_cfm         = false;
else
	if strcmpi(class(Cbx_atcu_ptcu_typ_cfm),'RSACSC.Parameter')
		Cbx_atcu_ptcu_typ_cfm.Value = false;
	else
		Cbx_atcu_ptcu_typ_cfm       = false;
	end
end

%% Cbx_flt_rst_cfm - Option to activate the reset of the filter by the state of Clutch (Open to sliding)
if (exist('Cbx_flt_rst_cfm','var')==0)                    % 
	Cbx_flt_rst_cfm               = false;
else
	if strcmpi(class(Cbx_flt_rst_cfm),'RSACSC.Parameter')
		Cbx_flt_rst_cfm.Value       = false;
	else
		Cbx_flt_rst_cfm             = false;
	end
end

%% Cbx_sign_cho_cfm - Option to select the sign of the primary torque following the clutch or engine torque
if (exist('Cbx_sign_cho_cfm','var')==0)                   % 
	Cbx_sign_cho_cfm              = true;
else
	if strcmpi(class(Cbx_sign_cho_cfm),'RSACSC.Parameter')
		Cbx_sign_cho_cfm.Value      = true;
	else
		Cbx_sign_cho_cfm            = true;
	end
end

%% Cbx_swadp_opt_dry_coup - Configuration option : no convertissor
if (exist('Cbx_swadp_opt_dry_coup','var')==0)             % 
	Cbx_swadp_opt_dry_coup        = true;
else
	if strcmpi(class(Cbx_swadp_opt_dry_coup),'RSACSC.Parameter')
		Cbx_swadp_opt_dry_coup.Value= true;
	else
		Cbx_swadp_opt_dry_coup      = true;
	end
end

%% Cbx_tqdif_opt_1st_calc - Option to calculate Vxx_tq_diff in 1st gear, reverse gear and neutral.
if (exist('Cbx_tqdif_opt_1st_calc','var')==0)             % 
	Cbx_tqdif_opt_1st_calc        = false;
else
	if strcmpi(class(Cbx_tqdif_opt_1st_calc),'RSACSC.Parameter')
		Cbx_tqdif_opt_1st_calc.Value= false;
	else
		Cbx_tqdif_opt_1st_calc      = false;
	end
end

%% Cbx_tqdif_opt_luip - Option to disable the calculation of the tq-dif during lock-up in progress
if (exist('Cbx_tqdif_opt_luip','var')==0)                 % 
	Cbx_tqdif_opt_luip            = false;
else
	if strcmpi(class(Cbx_tqdif_opt_luip),'RSACSC.Parameter')
		Cbx_tqdif_opt_luip.Value    = false;
	else
		Cbx_tqdif_opt_luip          = false;
	end
end

%% Cmp_prmtq_gbx_loss_g1 - Map of Turbine torque losses on 1 gear
if (exist('Cmp_prmtq_gbx_loss_g1','var')==0)              % 
	Cmp_prmtq_gbx_loss_g1         = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g1),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g1.Value = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	else
		Cmp_prmtq_gbx_loss_g1       = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	end
end

%% Cmp_prmtq_gbx_loss_g2 - Map of Turbine torque losses on 2 gear
if (exist('Cmp_prmtq_gbx_loss_g2','var')==0)              % 
	Cmp_prmtq_gbx_loss_g2         = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g2),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g2.Value = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	else
		Cmp_prmtq_gbx_loss_g2       = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	end
end

%% Cmp_prmtq_gbx_loss_g3 - Map of Turbine torque losses on 3 gear
if (exist('Cmp_prmtq_gbx_loss_g3','var')==0)              % 
	Cmp_prmtq_gbx_loss_g3         = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g3),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g3.Value = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	else
		Cmp_prmtq_gbx_loss_g3       = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	end
end

%% Cmp_prmtq_gbx_loss_g4 - Map of Turbine torque losses on 4 gear
if (exist('Cmp_prmtq_gbx_loss_g4','var')==0)              % 
	Cmp_prmtq_gbx_loss_g4         = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g4),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g4.Value = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	else
		Cmp_prmtq_gbx_loss_g4       = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	end
end

%% Cmp_prmtq_gbx_loss_g5 - Map of Turbine torque losses on 5 gear
if (exist('Cmp_prmtq_gbx_loss_g5','var')==0)              % 
	Cmp_prmtq_gbx_loss_g5         = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g5),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g5.Value = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	else
		Cmp_prmtq_gbx_loss_g5       = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	end
end

%% Cmp_prmtq_gbx_loss_g6 - Map of Turbine torque losses on 6 gear
if (exist('Cmp_prmtq_gbx_loss_g6','var')==0)              % 
	Cmp_prmtq_gbx_loss_g6         = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g6),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g6.Value = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	else
		Cmp_prmtq_gbx_loss_g6       = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	end
end

%% Cmp_prmtq_gbx_loss_g7 - Map of Turbine torque losses on 7 gear
if (exist('Cmp_prmtq_gbx_loss_g7','var')==0)              % 
	Cmp_prmtq_gbx_loss_g7         = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g7),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g7.Value = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	else
		Cmp_prmtq_gbx_loss_g7       = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	end
end

%% Cmp_prmtq_gbx_loss_g8 - Map of Turbine torque losses on 8 gear
if (exist('Cmp_prmtq_gbx_loss_g8','var')==0)              % 
	Cmp_prmtq_gbx_loss_g8         = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g8),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g8.Value = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	else
		Cmp_prmtq_gbx_loss_g8       = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	end
end

%% Cmp_prmtq_gbx_loss_g9 - Map of Turbine torque losses on 9 gear
if (exist('Cmp_prmtq_gbx_loss_g9','var')==0)              % 
	Cmp_prmtq_gbx_loss_g9         = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g9),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g9.Value = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	else
		Cmp_prmtq_gbx_loss_g9       = [2.5 2.5 2.5 2.5
                                0 0 0 0
                                2.5 2.5 2.5 2.5
                                5 5 5 5
                                7.5 7.5 7.5 7.5
                                12.5 12.5 12.5 12.5];
	end
end

%% Csx_pow_r_use_acel_slop - 0 : no ESP or road_slope using ESP is not tuned ; 1 : use of slope pow_r using ESP when pow_r using primary_tq is frozen ; 2 : always use slope pow_r  using ESP in replacment of pow_r using primary_tq
if (exist('Csx_pow_r_use_acel_slop','var')==0)            % 
	Csx_pow_r_use_acel_slop       = 0;
else
	if strcmpi(class(Csx_pow_r_use_acel_slop),'RSACSC.Parameter')
		Csx_pow_r_use_acel_slop.Value= 0;
	else
		Csx_pow_r_use_acel_slop     = 0;
	end
end

%% Csx_use_acel_slop - 0 : no ESP or road_slope using ESP is not tuned1 : use of road_slope using ESP when classic tq_dif is frozen2 : always use road_slop using ESP in replacment of classic_tq_dif
if (exist('Csx_use_acel_slop','var')==0)                  % 
	Csx_use_acel_slop             = 0;
else
	if strcmpi(class(Csx_use_acel_slop),'RSACSC.Parameter')
		Csx_use_acel_slop.Value     = 0;
	else
		Csx_use_acel_slop           = 0;
	end
end

%% Ctb_acpot_tco - Breakpoints of engine coolant temperature to calculate resistive efforts power
if (exist('Ctb_acpot_tco','var')==0)                      % 
	Ctb_acpot_tco                 = [0 20 40 60 86 106];
else
	if strcmpi(class(Ctb_acpot_tco),'RSACSC.Parameter')
		Ctb_acpot_tco.Value         = [0 20 40 60 86 106];
	else
		Ctb_acpot_tco               = [0 20 40 60 86 106];
	end
end

%% Ctb_loadx_veh_spd - Breakpoints of Vehicle speed to calculate the load
if (exist('Ctb_loadx_veh_spd','var')==0)                  % 
	Ctb_loadx_veh_spd             = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 255];
else
	if strcmpi(class(Ctb_loadx_veh_spd),'RSACSC.Parameter')
		Ctb_loadx_veh_spd.Value     = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 255];
	else
		Ctb_loadx_veh_spd           = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 255];
	end
end

%% Ctb_prmtq_gbx_los_tbn_spd - Bkpts of turbine speed to calculate gearbox losses
if (exist('Ctb_prmtq_gbx_los_tbn_spd','var')==0)          % 
	Ctb_prmtq_gbx_los_tbn_spd     = [1216 2400 4000 6016];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_spd),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_spd.Value= [1216 2400 4000 6016];
	else
		Ctb_prmtq_gbx_los_tbn_spd   = [1216 2400 4000 6016];
	end
end

%% Ctb_prmtq_gbx_los_tbn_tq_g1 - Bkpts of turbine torque to calculate gearbox losses on 1 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g1','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g1   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g1),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g1.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g1 = [-48 0 48 104 152 248];
	end
end

%% Ctb_prmtq_gbx_los_tbn_tq_g2 - Bkpts of turbine torque to calculate gearbox losses on 2 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g2','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g2   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g2),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g2.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g2 = [-48 0 48 104 152 248];
	end
end

%% Ctb_prmtq_gbx_los_tbn_tq_g3 - Bkpts of turbine torque to calculate gearbox losses on 3 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g3','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g3   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g3),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g3.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g3 = [-48 0 48 104 152 248];
	end
end

%% Ctb_prmtq_gbx_los_tbn_tq_g4 - Bkpts of turbine torque to calculate gearbox losses on 4 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g4','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g4   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g4),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g4.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g4 = [-48 0 48 104 152 248];
	end
end

%% Ctb_prmtq_gbx_los_tbn_tq_g5 - Bkpts of turbine torque to calculate gearbox losses on 5 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g5','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g5   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g5),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g5.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g5 = [-48 0 48 104 152 248];
	end
end

%% Ctb_prmtq_gbx_los_tbn_tq_g6 - Bkpts of turbine torque to calculate gearbox losses on 6 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g6','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g6   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g6),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g6.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g6 = [-48 0 48 104 152 248];
	end
end

%% Ctb_prmtq_gbx_los_tbn_tq_g7 - Bkpts of turbine torque to calculate gearbox losses on 7 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g7','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g7   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g7),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g7.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g7 = [-48 0 48 104 152 248];
	end
end

%% Ctb_prmtq_gbx_los_tbn_tq_g8 - Bkpts of turbine torque to calculate gearbox losses on 8 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g8','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g8   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g8),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g8.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g8 = [-48 0 48 104 152 248];
	end
end

%% Ctb_prmtq_gbx_los_tbn_tq_g9 - Bkpts of turbine torque to calculate gearbox losses on 9 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g9','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g9   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g9),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g9.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g9 = [-48 0 48 104 152 248];
	end
end

%% Ctb_prmtq_oil_temp_cor_tbn_spd - Bkpts of gearbox oil temperature
if (exist('Ctb_prmtq_oil_temp_cor_tbn_spd','var')==0)     % 
	Ctb_prmtq_oil_temp_cor_tbn_spd= [0 20 50 80 100 120];
else
	if strcmpi(class(Ctb_prmtq_oil_temp_cor_tbn_spd),'RSACSC.Parameter')
		Ctb_prmtq_oil_temp_cor_tbn_spd.Value= [0 20 50 80 100 120];
	else
		Ctb_prmtq_oil_temp_cor_tbn_spd= [0 20 50 80 100 120];
	end
end

%% Ctb_prmtq_sli_spd_rat - Bkpts of converter sliding ratio
if (exist('Ctb_prmtq_sli_spd_rat','var')==0)              % 
	Ctb_prmtq_sli_spd_rat         = [0 0.1015625 0.203125 0.296875 0.3984375 0.5 0.6015625 0.703125 0.75 0.796875 0.8203125 0.8515625 0.8671875 0.8984375 0.921875 0.953125 1];
else
	if strcmpi(class(Ctb_prmtq_sli_spd_rat),'RSACSC.Parameter')
		Ctb_prmtq_sli_spd_rat.Value = [0 0.1015625 0.203125 0.296875 0.3984375 0.5 0.6015625 0.703125 0.75 0.796875 0.8203125 0.8515625 0.8671875 0.8984375 0.921875 0.953125 1];
	else
		Ctb_prmtq_sli_spd_rat       = [0 0.1015625 0.203125 0.296875 0.3984375 0.5 0.6015625 0.703125 0.75 0.796875 0.8203125 0.8515625 0.8671875 0.8984375 0.921875 0.953125 1];
	end
end

%% Ctb_res_forc - Vehicle speed breakpoints for theorical resistive force model.
if (exist('Ctb_res_forc','var')==0)                       % 
	Ctb_res_forc                  = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200];
else
	if strcmpi(class(Ctb_res_forc),'RSACSC.Parameter')
		Ctb_res_forc.Value          = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200];
	else
		Ctb_res_forc                = [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200];
	end
end

%% Ctb_tqdif_ofs_tm_brk - Bkpts of Vxx_tm_brk_tq_dif
if (exist('Ctb_tqdif_ofs_tm_brk','var')==0)               % 
	Ctb_tqdif_ofs_tm_brk          = [0 4 8 12 20 25.5];
else
	if strcmpi(class(Ctb_tqdif_ofs_tm_brk),'RSACSC.Parameter')
		Ctb_tqdif_ofs_tm_brk.Value  = [0 4 8 12 20 25.5];
	else
		Ctb_tqdif_ofs_tm_brk        = [0 4 8 12 20 25.5];
	end
end

%% Ctp_acpot_efficiency - Efficiency of the gearbox for each gear
if (exist('Ctp_acpot_efficiency','var')==0)               % 
	Ctp_acpot_efficiency          = [1 1 1 1 1 1 1 1 1];
else
	if strcmpi(class(Ctp_acpot_efficiency),'RSACSC.Parameter')
		Ctp_acpot_efficiency.Value  = [1 1 1 1 1 1 1 1 1];
	else
		Ctp_acpot_efficiency        = [1 1 1 1 1 1 1 1 1];
	end
end

%% Ctp_acpot_pow_r_fac - Correction factor depending on engine coolant temperature for resistive efforts power
if (exist('Ctp_acpot_pow_r_fac','var')==0)                % 
	Ctp_acpot_pow_r_fac           = [1 1 1 1 1 1];
else
	if strcmpi(class(Ctp_acpot_pow_r_fac),'RSACSC.Parameter')
		Ctp_acpot_pow_r_fac.Value   = [1 1 1 1 1 1];
	else
		Ctp_acpot_pow_r_fac         = [1 1 1 1 1 1];
	end
end

%% Ctp_loadx_veh_spd - Gain on Vxx_tq_dif to calculate the load
if (exist('Ctp_loadx_veh_spd','var')==0)                  % 
	Ctp_loadx_veh_spd             = [0.6875 0.71875 0.75 0.78125 0.8125 0.84375 0.875 0.90625 0.9375 0.96875 1 1.03125 1.0625 1.09375 1.125 1.15625 1.1875 1.21875 1.25 1.28125];
else
	if strcmpi(class(Ctp_loadx_veh_spd),'RSACSC.Parameter')
		Ctp_loadx_veh_spd.Value     = [0.6875 0.71875 0.75 0.78125 0.8125 0.84375 0.875 0.90625 0.9375 0.96875 1 1.03125 1.0625 1.09375 1.125 1.15625 1.1875 1.21875 1.25 1.28125];
	else
		Ctp_loadx_veh_spd           = [0.6875 0.71875 0.75 0.78125 0.8125 0.84375 0.875 0.90625 0.9375 0.96875 1 1.03125 1.0625 1.09375 1.125 1.15625 1.1875 1.21875 1.25 1.28125];
	end
end

%% Ctp_prmtq_conv_rat - Table of Converter gain function of the sliding ratio
if (exist('Ctp_prmtq_conv_rat','var')==0)                 % 
	Ctp_prmtq_conv_rat            = [1.625 1.546875 1.484375 1.421875 1.34375 1.265625 1.171875 1.125 1.09375 1.046875 1.03125 1 1 1 1 1 1];
else
	if strcmpi(class(Ctp_prmtq_conv_rat),'RSACSC.Parameter')
		Ctp_prmtq_conv_rat.Value    = [1.625 1.546875 1.484375 1.421875 1.34375 1.265625 1.171875 1.125 1.09375 1.046875 1.03125 1 1 1 1 1 1];
	else
		Ctp_prmtq_conv_rat          = [1.625 1.546875 1.484375 1.421875 1.34375 1.265625 1.171875 1.125 1.09375 1.046875 1.03125 1 1 1 1 1 1];
	end
end

%% Ctp_prmtq_oil_temp_cor - Table of factor of correction on turbine torque losses function of the oil temperature
if (exist('Ctp_prmtq_oil_temp_cor','var')==0)             % 
	Ctp_prmtq_oil_temp_cor        = [2 2 1.40625 1 1 1];
else
	if strcmpi(class(Ctp_prmtq_oil_temp_cor),'RSACSC.Parameter')
		Ctp_prmtq_oil_temp_cor.Value= [2 2 1.40625 1 1 1];
	else
		Ctp_prmtq_oil_temp_cor      = [2 2 1.40625 1 1 1];
	end
end

%% Ctp_prmtq_tau_eng_tq_dwn - Time constant in second for first order filter
if (exist('Ctp_prmtq_tau_eng_tq_dwn','var')==0)           % 
	Ctp_prmtq_tau_eng_tq_dwn      = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
else
	if strcmpi(class(Ctp_prmtq_tau_eng_tq_dwn),'RSACSC.Parameter')
		Ctp_prmtq_tau_eng_tq_dwn.Value= [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
	else
		Ctp_prmtq_tau_eng_tq_dwn    = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
	end
end

%% Ctp_prmtq_tau_eng_tq_up - Time constant in second for first order filter
if (exist('Ctp_prmtq_tau_eng_tq_up','var')==0)            % 
	Ctp_prmtq_tau_eng_tq_up       = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
else
	if strcmpi(class(Ctp_prmtq_tau_eng_tq_up),'RSACSC.Parameter')
		Ctp_prmtq_tau_eng_tq_up.Value= [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
	else
		Ctp_prmtq_tau_eng_tq_up     = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
	end
end

%% Ctp_res_forc - Known resistant forces : air drag load and resistance to the rolling
if (exist('Ctp_res_forc','var')==0)                       % 
	Ctp_res_forc                  = [216 219.8 231.1 253.9 282.3 320.3 364.8 416.8 476.4 544 619.1 701.8 792.1 891.4 998.2 1114 1237 1375 1520 1678 1844];
else
	if strcmpi(class(Ctp_res_forc),'RSACSC.Parameter')
		Ctp_res_forc.Value          = [216 219.8 231.1 253.9 282.3 320.3 364.8 416.8 476.4 544 619.1 701.8 792.1 891.4 998.2 1114 1237 1375 1520 1678 1844];
	else
		Ctp_res_forc                = [216 219.8 231.1 253.9 282.3 320.3 364.8 416.8 476.4 544 619.1 701.8 792.1 891.4 998.2 1114 1237 1375 1520 1678 1844];
	end
end

%% Ctp_tau_coup_tq_dwn_fil - Time constant in second for first order filter
if (exist('Ctp_tau_coup_tq_dwn_fil','var')==0)            % 
	Ctp_tau_coup_tq_dwn_fil       = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
else
	if strcmpi(class(Ctp_tau_coup_tq_dwn_fil),'RSACSC.Parameter')
		Ctp_tau_coup_tq_dwn_fil.Value= [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
	else
		Ctp_tau_coup_tq_dwn_fil     = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
	end
end

%% Ctp_tau_coup_tq_up_fil - Time constant in second for first order filter
if (exist('Ctp_tau_coup_tq_up_fil','var')==0)             % 
	Ctp_tau_coup_tq_up_fil        = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
else
	if strcmpi(class(Ctp_tau_coup_tq_up_fil),'RSACSC.Parameter')
		Ctp_tau_coup_tq_up_fil.Value= [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
	else
		Ctp_tau_coup_tq_up_fil      = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
	end
end

%% Ctp_tqdif_brk_ofs - Table of the offset to apply to Vxx_tq_dif while braking
if (exist('Ctp_tqdif_brk_ofs','var')==0)                  % 
	Ctp_tqdif_brk_ofs             = [0 0 0 0 0 0];
else
	if strcmpi(class(Ctp_tqdif_brk_ofs),'RSACSC.Parameter')
		Ctp_tqdif_brk_ofs.Value     = [0 0 0 0 0 0];
	else
		Ctp_tqdif_brk_ofs           = [0 0 0 0 0 0];
	end
end

%% Ctp_tqdif_gearbox_inertias - Table of Inertia weight on every gear position
if (exist('Ctp_tqdif_gearbox_inertias','var')==0)         % 
	Ctp_tqdif_gearbox_inertias    = [308 112 56 32 16 12 12 12 12];
else
	if strcmpi(class(Ctp_tqdif_gearbox_inertias),'RSACSC.Parameter')
		Ctp_tqdif_gearbox_inertias.Value= [308 112 56 32 16 12 12 12 12];
	else
		Ctp_tqdif_gearbox_inertias  = [308 112 56 32 16 12 12 12 12];
	end
end

%% Ctp_tqdif_shf_end_tmr - Table of tempo started in the end of a gearshift during which the calcul. of Vxx_tq-dif is frozen
if (exist('Ctp_tqdif_shf_end_tmr','var')==0)              % 
	Ctp_tqdif_shf_end_tmr         = [0 0 0 0 0 0 0 0 0];
else
	if strcmpi(class(Ctp_tqdif_shf_end_tmr),'RSACSC.Parameter')
		Ctp_tqdif_shf_end_tmr.Value = [0 0 0 0 0 0 0 0 0];
	else
		Ctp_tqdif_shf_end_tmr       = [0 0 0 0 0 0 0 0 0];
	end
end

%% Cxx_acpot_failure_tco - Engine coolant temperature in case of failure
if (exist('Cxx_acpot_failure_tco','var')==0)              % 
	Cxx_acpot_failure_tco         = 20;
else
	if strcmpi(class(Cxx_acpot_failure_tco),'RSACSC.Parameter')
		Cxx_acpot_failure_tco.Value = 20;
	else
		Cxx_acpot_failure_tco       = 20;
	end
end

%% Cxx_end_sip_ena_dly - Value of temporization started at the end of a gearshift
if (exist('Cxx_end_sip_ena_dly','var')==0)                % 
	Cxx_end_sip_ena_dly           = 0.52;
else
	if strcmpi(class(Cxx_end_sip_ena_dly),'RSACSC.Parameter')
		Cxx_end_sip_ena_dly.Value   = 0.52;
	else
		Cxx_end_sip_ena_dly         = 0.52;
	end
end

%% Cxx_pow_r_slop_tau_fil - first order filter time constant for resistive power using slope
if (exist('Cxx_pow_r_slop_tau_fil','var')==0)             % 
	Cxx_pow_r_slop_tau_fil        = 0;
else
	if strcmpi(class(Cxx_pow_r_slop_tau_fil),'RSACSC.Parameter')
		Cxx_pow_r_slop_tau_fil.Value= 0;
	else
		Cxx_pow_r_slop_tau_fil      = 0;
	end
end

%% Cxx_pow_r_swi_neg_slop - Negative slope value for transition between resistive power calculation using torque or using slope
if (exist('Cxx_pow_r_swi_neg_slop','var')==0)             % 
	Cxx_pow_r_swi_neg_slop        = -300;
else
	if strcmpi(class(Cxx_pow_r_swi_neg_slop),'RSACSC.Parameter')
		Cxx_pow_r_swi_neg_slop.Value= -300;
	else
		Cxx_pow_r_swi_neg_slop      = -300;
	end
end

%% Cxx_pow_r_swi_pos_slop - Positive slope value for transition between resistive power calculation using torque or using slope
if (exist('Cxx_pow_r_swi_pos_slop','var')==0)             % 
	Cxx_pow_r_swi_pos_slop        = 300;
else
	if strcmpi(class(Cxx_pow_r_swi_pos_slop),'RSACSC.Parameter')
		Cxx_pow_r_swi_pos_slop.Value= 300;
	else
		Cxx_pow_r_swi_pos_slop      = 300;
	end
end

%% Cxx_pow_r_tau_fil - Time constant in second for  the first order filter of resistive power
if (exist('Cxx_pow_r_tau_fil','var')==0)                  % 
	Cxx_pow_r_tau_fil             = 0.4;
else
	if strcmpi(class(Cxx_pow_r_tau_fil),'RSACSC.Parameter')
		Cxx_pow_r_tau_fil.Value     = 0.4;
	else
		Cxx_pow_r_tau_fil           = 0.4;
	end
end

%% Cxx_prmtq_eng_spd_min - Minimum of engine speed to calculate the gain of the converter
if (exist('Cxx_prmtq_eng_spd_min','var')==0)              % 
	Cxx_prmtq_eng_spd_min         = 50;
else
	if strcmpi(class(Cxx_prmtq_eng_spd_min),'RSACSC.Parameter')
		Cxx_prmtq_eng_spd_min.Value = 50;
	else
		Cxx_prmtq_eng_spd_min       = 50;
	end
end

%% Cxx_prmtq_jengine - Inertia of the engine
if (exist('Cxx_prmtq_jengine','var')==0)                  % 
	Cxx_prmtq_jengine             = 0.23828125;
else
	if strcmpi(class(Cxx_prmtq_jengine),'RSACSC.Parameter')
		Cxx_prmtq_jengine.Value     = 0.23828125;
	else
		Cxx_prmtq_jengine           = 0.23828125;
	end
end

%% Cxx_prmtq_oil_temp_ctrl_tmr - Timer launched after the detection default on oil temperature before to consider oil temperature
if (exist('Cxx_prmtq_oil_temp_ctrl_tmr','var')==0)        % 
	Cxx_prmtq_oil_temp_ctrl_tmr   = 0.4;
else
	if strcmpi(class(Cxx_prmtq_oil_temp_ctrl_tmr),'RSACSC.Parameter')
		Cxx_prmtq_oil_temp_ctrl_tmr.Value= 0.4;
	else
		Cxx_prmtq_oil_temp_ctrl_tmr = 0.4;
	end
end

%% Cxx_prmtq_temp_min - Minimum threshold of oil temperature to calculate primary torque
if (exist('Cxx_prmtq_temp_min','var')==0)                 % 
	Cxx_prmtq_temp_min            = 16;
else
	if strcmpi(class(Cxx_prmtq_temp_min),'RSACSC.Parameter')
		Cxx_prmtq_temp_min.Value    = 16;
	else
		Cxx_prmtq_temp_min          = 16;
	end
end

%% Cxx_tq_dif_no_frz_vld - Confirmation time after tq_dif un-freeze to switch on classic tq_dif
if (exist('Cxx_tq_dif_no_frz_vld','var')==0)              % 
	Cxx_tq_dif_no_frz_vld         = 0.5;
else
	if strcmpi(class(Cxx_tq_dif_no_frz_vld),'RSACSC.Parameter')
		Cxx_tq_dif_no_frz_vld.Value = 0.5;
	else
		Cxx_tq_dif_no_frz_vld       = 0.5;
	end
end

%% Cxx_tq_dif_swi_neg_slop - Negative slope value for transition between classic and ESP tq_dif
if (exist('Cxx_tq_dif_swi_neg_slop','var')==0)            % 
	Cxx_tq_dif_swi_neg_slop       = -100;
else
	if strcmpi(class(Cxx_tq_dif_swi_neg_slop),'RSACSC.Parameter')
		Cxx_tq_dif_swi_neg_slop.Value= -100;
	else
		Cxx_tq_dif_swi_neg_slop     = -100;
	end
end

%% Cxx_tq_dif_swi_pos_slop - Positive slope value for transition between classic and ESP tq_dif
if (exist('Cxx_tq_dif_swi_pos_slop','var')==0)            % 
	Cxx_tq_dif_swi_pos_slop       = 100;
else
	if strcmpi(class(Cxx_tq_dif_swi_pos_slop),'RSACSC.Parameter')
		Cxx_tq_dif_swi_pos_slop.Value= 100;
	else
		Cxx_tq_dif_swi_pos_slop     = 100;
	end
end

%% Cxx_tqdif_acc_brk_thd - Threshold of acceleration below which an offset is applied to Vxx_tq_dif while braking
if (exist('Cxx_tqdif_acc_brk_thd','var')==0)              % 
	Cxx_tqdif_acc_brk_thd         = 0.5;
else
	if strcmpi(class(Cxx_tqdif_acc_brk_thd),'RSACSC.Parameter')
		Cxx_tqdif_acc_brk_thd.Value = 0.5;
	else
		Cxx_tqdif_acc_brk_thd       = 0.5;
	end
end

%% Cxx_tqdif_avg_max - Maximum value of Vxx_tq_dif_avg
if (exist('Cxx_tqdif_avg_max','var')==0)                  % 
	Cxx_tqdif_avg_max             = 200;
else
	if strcmpi(class(Cxx_tqdif_avg_max),'RSACSC.Parameter')
		Cxx_tqdif_avg_max.Value     = 200;
	else
		Cxx_tqdif_avg_max           = 200;
	end
end

%% Cxx_tqdif_avg_min - Minimum value of Vxx_tq_dif_avg
if (exist('Cxx_tqdif_avg_min','var')==0)                  % 
	Cxx_tqdif_avg_min             = 0;
else
	if strcmpi(class(Cxx_tqdif_avg_min),'RSACSC.Parameter')
		Cxx_tqdif_avg_min.Value     = 0;
	else
		Cxx_tqdif_avg_min           = 0;
	end
end

%% Cxx_tqdif_brk_frz_dly - Delay after braking during which the calculation of Vxx_tq_dif is frozen
if (exist('Cxx_tqdif_brk_frz_dly','var')==0)              % 
	Cxx_tqdif_brk_frz_dly         = 0.6;
else
	if strcmpi(class(Cxx_tqdif_brk_frz_dly),'RSACSC.Parameter')
		Cxx_tqdif_brk_frz_dly.Value = 0.6;
	else
		Cxx_tqdif_brk_frz_dly       = 0.6;
	end
end

%% Cxx_tqdif_coef_bend - Coeff to take into account the transverse acceleration for the tq dif calculation
if (exist('Cxx_tqdif_coef_bend','var')==0)                % 
	Cxx_tqdif_coef_bend           = 0;
else
	if strcmpi(class(Cxx_tqdif_coef_bend),'RSACSC.Parameter')
		Cxx_tqdif_coef_bend.Value   = 0;
	else
		Cxx_tqdif_coef_bend         = 0;
	end
end

%% Cxx_tqdif_coup_tq_min - Minimum clutch torque to calculate Vxx_tq_dif
if (exist('Cxx_tqdif_coup_tq_min','var')==0)              % 
	Cxx_tqdif_coup_tq_min         = 0;
else
	if strcmpi(class(Cxx_tqdif_coup_tq_min),'RSACSC.Parameter')
		Cxx_tqdif_coup_tq_min.Value = 0;
	else
		Cxx_tqdif_coup_tq_min       = 0;
	end
end

%% Cxx_tqdif_gear_min - Minimum gear to calculate Vxx_tq_dif
if (exist('Cxx_tqdif_gear_min','var')==0)                 % 
	Cxx_tqdif_gear_min            = 2;
else
	if strcmpi(class(Cxx_tqdif_gear_min),'RSACSC.Parameter')
		Cxx_tqdif_gear_min.Value    = 2;
	else
		Cxx_tqdif_gear_min          = 2;
	end
end

%% Cxx_tqdif_tau_avg_dec - Time constante in second for  the first order filter
if (exist('Cxx_tqdif_tau_avg_dec','var')==0)              % 
	Cxx_tqdif_tau_avg_dec         = 1;
else
	if strcmpi(class(Cxx_tqdif_tau_avg_dec),'RSACSC.Parameter')
		Cxx_tqdif_tau_avg_dec.Value = 1;
	else
		Cxx_tqdif_tau_avg_dec       = 1;
	end
end

%% Cxx_tqdif_tau_avg_inc - Time constante in second for  the first order filter
if (exist('Cxx_tqdif_tau_avg_inc','var')==0)              % 
	Cxx_tqdif_tau_avg_inc         = 1;
else
	if strcmpi(class(Cxx_tqdif_tau_avg_inc),'RSACSC.Parameter')
		Cxx_tqdif_tau_avg_inc.Value = 1;
	else
		Cxx_tqdif_tau_avg_inc       = 1;
	end
end

%% Cxx_tqdif_tau_fil - Time constante in second for  the first order filter
if (exist('Cxx_tqdif_tau_fil','var')==0)                  % 
	Cxx_tqdif_tau_fil             = 1;
else
	if strcmpi(class(Cxx_tqdif_tau_fil),'RSACSC.Parameter')
		Cxx_tqdif_tau_fil.Value     = 1;
	else
		Cxx_tqdif_tau_fil           = 1;
	end
end

%% Cxx_tqdif_tm_brk_del - Temporization started after end of braking during which the calculation of Vxx_tq_dif is frozen
if (exist('Cxx_tqdif_tm_brk_del','var')==0)               % 
	Cxx_tqdif_tm_brk_del          = 1.6;
else
	if strcmpi(class(Cxx_tqdif_tm_brk_del),'RSACSC.Parameter')
		Cxx_tqdif_tm_brk_del.Value  = 1.6;
	else
		Cxx_tqdif_tm_brk_del        = 1.6;
	end
end

%% Cxx_tqdif_veh_weight - Vehicle weight
if (exist('Cxx_tqdif_veh_weight','var')==0)               % 
	Cxx_tqdif_veh_weight          = 1408;
else
	if strcmpi(class(Cxx_tqdif_veh_weight),'RSACSC.Parameter')
		Cxx_tqdif_veh_weight.Value  = 1408;
	else
		Cxx_tqdif_veh_weight        = 1408;
	end
end

%% Cxx_tqdif_vs_hys - Vehicle speed hysteresys for tq_dif freeze threshold
if (exist('Cxx_tqdif_vs_hys','var')==0)                   % 
	Cxx_tqdif_vs_hys              = 0;
else
	if strcmpi(class(Cxx_tqdif_vs_hys),'RSACSC.Parameter')
		Cxx_tqdif_vs_hys.Value      = 0;
	else
		Cxx_tqdif_vs_hys            = 0;
	end
end

%% Cxx_tqdif_vs_min_thd - Minimum vehicle speed to calculate Vxx_tq_dif
if (exist('Cxx_tqdif_vs_min_thd','var')==0)               % 
	Cxx_tqdif_vs_min_thd          = 10;
else
	if strcmpi(class(Cxx_tqdif_vs_min_thd),'RSACSC.Parameter')
		Cxx_tqdif_vs_min_thd.Value  = 10;
	else
		Cxx_tqdif_vs_min_thd        = 10;
	end
end

%% Cxx_tqdif_vs_ofs_thd - Minimum vehicle speed to activate the conditions of the offset calculation when braking
if (exist('Cxx_tqdif_vs_ofs_thd','var')==0)               % 
	Cxx_tqdif_vs_ofs_thd          = 1;
else
	if strcmpi(class(Cxx_tqdif_vs_ofs_thd),'RSACSC.Parameter')
		Cxx_tqdif_vs_ofs_thd.Value  = 1;
	else
		Cxx_tqdif_vs_ofs_thd        = 1;
	end
end

%% Cxx_whl_rad - in_pci_rds_fstqdxx_xxx_xx_x_a/Wheel radius
if (exist('Cxx_whl_rad','var')==0)                        % 
	Cxx_whl_rad                   = 0.308;
else
	if strcmpi(class(Cxx_whl_rad),'RSACSC.Parameter')
		Cxx_whl_rad.Value           = 0.308;
	else
		Cxx_whl_rad                 = 0.308;
	end
end

%% Nsx_always_use_acel_slop - 2 : always use road_slop using ESP in replacment of classic_tq_dif
if (exist('Nsx_always_use_acel_slop','var')==0)           % 
	Nsx_always_use_acel_slop      = 2;
else
	if strcmpi(class(Nsx_always_use_acel_slop),'RSACSC.Parameter')
		Nsx_always_use_acel_slop.Value= 2;
	else
		Nsx_always_use_acel_slop    = 2;
	end
end

%% Nsx_coup_clos - The transmission coupler is closed (for dry clutch, no slip between friction and plate)
if (exist('Nsx_coup_clos','var')==0)                      % 
	Nsx_coup_clos                 = 1;
else
	if strcmpi(class(Nsx_coup_clos),'RSACSC.Parameter')
		Nsx_coup_clos.Value         = 1;
	else
		Nsx_coup_clos               = 1;
	end
end

%% Nsx_coup_open - Calibration corresponding to the coupler State open
if (exist('Nsx_coup_open','var')==0)                      % 
	Nsx_coup_open                 = 8;
else
	if strcmpi(class(Nsx_coup_open),'RSACSC.Parameter')
		Nsx_coup_open.Value         = 8;
	else
		Nsx_coup_open               = 8;
	end
end

%% Nsx_coup_sli - Transmission coupler is sliding. For dry clutch, friction touching plate with differential speed
if (exist('Nsx_coup_sli','var')==0)                       % 
	Nsx_coup_sli                  = 2;
else
	if strcmpi(class(Nsx_coup_sli),'RSACSC.Parameter')
		Nsx_coup_sli.Value          = 2;
	else
		Nsx_coup_sli                = 2;
	end
end

%% Nsx_levr_psn_1 - Gear lever on position 1 (first gear)
if (exist('Nsx_levr_psn_1','var')==0)                     % 
	Nsx_levr_psn_1                = 1;
else
	if strcmpi(class(Nsx_levr_psn_1),'RSACSC.Parameter')
		Nsx_levr_psn_1.Value        = 1;
	else
		Nsx_levr_psn_1              = 1;
	end
end

%% Nsx_levr_psn_2 - Gear lever on position 2 (second gear)
if (exist('Nsx_levr_psn_2','var')==0)                     % 
	Nsx_levr_psn_2                = 2;
else
	if strcmpi(class(Nsx_levr_psn_2),'RSACSC.Parameter')
		Nsx_levr_psn_2.Value        = 2;
	else
		Nsx_levr_psn_2              = 2;
	end
end

%% Nsx_levr_psn_3 - Gear lever on position 3 (third gear)
if (exist('Nsx_levr_psn_3','var')==0)                     % 
	Nsx_levr_psn_3                = 3;
else
	if strcmpi(class(Nsx_levr_psn_3),'RSACSC.Parameter')
		Nsx_levr_psn_3.Value        = 3;
	else
		Nsx_levr_psn_3              = 3;
	end
end

%% Nsx_levr_psn_4 - Gear lever on position 4 (fourth gear)
if (exist('Nsx_levr_psn_4','var')==0)                     % 
	Nsx_levr_psn_4                = 4;
else
	if strcmpi(class(Nsx_levr_psn_4),'RSACSC.Parameter')
		Nsx_levr_psn_4.Value        = 4;
	else
		Nsx_levr_psn_4              = 4;
	end
end

%% Nsx_levr_psn_5 - Gear lever on position 5 (fifth gear)
if (exist('Nsx_levr_psn_5','var')==0)                     % 
	Nsx_levr_psn_5                = 5;
else
	if strcmpi(class(Nsx_levr_psn_5),'RSACSC.Parameter')
		Nsx_levr_psn_5.Value        = 5;
	else
		Nsx_levr_psn_5              = 5;
	end
end

%% Nsx_levr_psn_6 - Gear lever on position 6 (sixth gear)
if (exist('Nsx_levr_psn_6','var')==0)                     % 
	Nsx_levr_psn_6                = 6;
else
	if strcmpi(class(Nsx_levr_psn_6),'RSACSC.Parameter')
		Nsx_levr_psn_6.Value        = 6;
	else
		Nsx_levr_psn_6              = 6;
	end
end

%% Nsx_levr_psn_7 - Gear lever on position 7 (seventh gear)
if (exist('Nsx_levr_psn_7','var')==0)                     % 
	Nsx_levr_psn_7                = 7;
else
	if strcmpi(class(Nsx_levr_psn_7),'RSACSC.Parameter')
		Nsx_levr_psn_7.Value        = 7;
	else
		Nsx_levr_psn_7              = 7;
	end
end

%% Nsx_levr_psn_drive - Gear lever in Drive position
if (exist('Nsx_levr_psn_drive','var')==0)                 % 
	Nsx_levr_psn_drive            = 12;
else
	if strcmpi(class(Nsx_levr_psn_drive),'RSACSC.Parameter')
		Nsx_levr_psn_drive.Value    = 12;
	else
		Nsx_levr_psn_drive          = 12;
	end
end

%% Nsx_levr_psn_med - Gear lever in intermediate position
if (exist('Nsx_levr_psn_med','var')==0)                   % 
	Nsx_levr_psn_med              = 23;
else
	if strcmpi(class(Nsx_levr_psn_med),'RSACSC.Parameter')
		Nsx_levr_psn_med.Value      = 23;
	else
		Nsx_levr_psn_med            = 23;
	end
end

%% Nsx_levr_psn_med_drive - Gear lever in intermediate position (N/D)
if (exist('Nsx_levr_psn_med_drive','var')==0)             % 
	Nsx_levr_psn_med_drive        = 22;
else
	if strcmpi(class(Nsx_levr_psn_med_drive),'RSACSC.Parameter')
		Nsx_levr_psn_med_drive.Value= 22;
	else
		Nsx_levr_psn_med_drive      = 22;
	end
end

%% Nsx_levr_psn_med_rvr - Gear lever in intermediate position (P/R or N/R)
if (exist('Nsx_levr_psn_med_rvr','var')==0)               % 
	Nsx_levr_psn_med_rvr          = 21;
else
	if strcmpi(class(Nsx_levr_psn_med_rvr),'RSACSC.Parameter')
		Nsx_levr_psn_med_rvr.Value  = 21;
	else
		Nsx_levr_psn_med_rvr        = 21;
	end
end

%% Nsx_levr_psn_neut - Gear lever in Neutral position
if (exist('Nsx_levr_psn_neut','var')==0)                  % 
	Nsx_levr_psn_neut             = 0;
else
	if strcmpi(class(Nsx_levr_psn_neut),'RSACSC.Parameter')
		Nsx_levr_psn_neut.Value     = 0;
	else
		Nsx_levr_psn_neut           = 0;
	end
end

%% Nsx_levr_psn_park - Gear lever in Parking position
if (exist('Nsx_levr_psn_park','var')==0)                  % 
	Nsx_levr_psn_park             = 11;
else
	if strcmpi(class(Nsx_levr_psn_park),'RSACSC.Parameter')
		Nsx_levr_psn_park.Value     = 11;
	else
		Nsx_levr_psn_park           = 11;
	end
end

%% Nsx_levr_psn_rvr - Gear lever in Reverse position
if (exist('Nsx_levr_psn_rvr','var')==0)                   % 
	Nsx_levr_psn_rvr              = -1;
else
	if strcmpi(class(Nsx_levr_psn_rvr),'RSACSC.Parameter')
		Nsx_levr_psn_rvr.Value      = -1;
	else
		Nsx_levr_psn_rvr            = -1;
	end
end

%% Nsx_levr_psn_seq - Gear lever in Manual Mode position
if (exist('Nsx_levr_psn_seq','var')==0)                   % 
	Nsx_levr_psn_seq              = 13;
else
	if strcmpi(class(Nsx_levr_psn_seq),'RSACSC.Parameter')
		Nsx_levr_psn_seq.Value      = 13;
	else
		Nsx_levr_psn_seq            = 13;
	end
end

%% Nsx_never_use_acel_slop - 0 : no ESP or road_slope using ESP is not tuned
if (exist('Nsx_never_use_acel_slop','var')==0)            % 
	Nsx_never_use_acel_slop       = 0;
else
	if strcmpi(class(Nsx_never_use_acel_slop),'RSACSC.Parameter')
		Nsx_never_use_acel_slop.Value= 0;
	else
		Nsx_never_use_acel_slop     = 0;
	end
end

%% Nsx_sail_entry_req - ECM Sailing Request : Entry Sailing Request
if (exist('Nsx_sail_entry_req','var')==0)                 % 
	Nsx_sail_entry_req            = 1;
else
	if strcmpi(class(Nsx_sail_entry_req),'RSACSC.Parameter')
		Nsx_sail_entry_req.Value    = 1;
	else
		Nsx_sail_entry_req          = 1;
	end
end

%% Nsx_sail_idle_req - ECM Sailing Request : Sailing Idle Request
if (exist('Nsx_sail_idle_req','var')==0)                  % 
	Nsx_sail_idle_req             = 2;
else
	if strcmpi(class(Nsx_sail_idle_req),'RSACSC.Parameter')
		Nsx_sail_idle_req.Value     = 2;
	else
		Nsx_sail_idle_req           = 2;
	end
end

%% Nsx_sail_no_req - ECM Sailing Request : No Request
if (exist('Nsx_sail_no_req','var')==0)                    % 
	Nsx_sail_no_req               = 0;
else
	if strcmpi(class(Nsx_sail_no_req),'RSACSC.Parameter')
		Nsx_sail_no_req.Value       = 0;
	else
		Nsx_sail_no_req             = 0;
	end
end

%% Nsx_sail_stop_req - ECM Sailing Request : Sailing Stop Request
if (exist('Nsx_sail_stop_req','var')==0)                  % 
	Nsx_sail_stop_req             = 3;
else
	if strcmpi(class(Nsx_sail_stop_req),'RSACSC.Parameter')
		Nsx_sail_stop_req.Value     = 3;
	else
		Nsx_sail_stop_req           = 3;
	end
end

%% Nsx_sometimes_use_acel_slop - 1 : use of road_slope using ESP when classic tq_dif is frozen
if (exist('Nsx_sometimes_use_acel_slop','var')==0)        % 
	Nsx_sometimes_use_acel_slop   = 1;
else
	if strcmpi(class(Nsx_sometimes_use_acel_slop),'RSACSC.Parameter')
		Nsx_sometimes_use_acel_slop.Value= 1;
	else
		Nsx_sometimes_use_acel_slop = 1;
	end
end

%% Nsx_vld_fail_2 - Limp home data (1)
if (exist('Nsx_vld_fail_2','var')==0)                     % 
	Nsx_vld_fail_2                = 2;
else
	if strcmpi(class(Nsx_vld_fail_2),'RSACSC.Parameter')
		Nsx_vld_fail_2.Value        = 2;
	else
		Nsx_vld_fail_2              = 2;
	end
end

%% Nsx_vld_fail_3 - Limp home data (2)
if (exist('Nsx_vld_fail_3','var')==0)                     % 
	Nsx_vld_fail_3                = 3;
else
	if strcmpi(class(Nsx_vld_fail_3),'RSACSC.Parameter')
		Nsx_vld_fail_3.Value        = 3;
	else
		Nsx_vld_fail_3              = 3;
	end
end

%% Nsx_vld_fail_4 - Limp home data (3)
if (exist('Nsx_vld_fail_4','var')==0)                     % 
	Nsx_vld_fail_4                = 4;
else
	if strcmpi(class(Nsx_vld_fail_4),'RSACSC.Parameter')
		Nsx_vld_fail_4.Value        = 4;
	else
		Nsx_vld_fail_4              = 4;
	end
end

%% Nsx_vld_fail_5 - Limp home data (4)
if (exist('Nsx_vld_fail_5','var')==0)                     % 
	Nsx_vld_fail_5                = 5;
else
	if strcmpi(class(Nsx_vld_fail_5),'RSACSC.Parameter')
		Nsx_vld_fail_5.Value        = 5;
	else
		Nsx_vld_fail_5              = 5;
	end
end

%% Nsx_vld_fail_6 - Limp home data (5)
if (exist('Nsx_vld_fail_6','var')==0)                     % 
	Nsx_vld_fail_6                = 6;
else
	if strcmpi(class(Nsx_vld_fail_6),'RSACSC.Parameter')
		Nsx_vld_fail_6.Value        = 6;
	else
		Nsx_vld_fail_6              = 6;
	end
end

%% Nsx_vld_fail_7 - Limp home data (6)
if (exist('Nsx_vld_fail_7','var')==0)                     % 
	Nsx_vld_fail_7                = 7;
else
	if strcmpi(class(Nsx_vld_fail_7),'RSACSC.Parameter')
		Nsx_vld_fail_7.Value        = 7;
	else
		Nsx_vld_fail_7              = 7;
	end
end

%% Nsx_vld_nok_0 - Invalid data
if (exist('Nsx_vld_nok_0','var')==0)                      % 
	Nsx_vld_nok_0                 = 0;
else
	if strcmpi(class(Nsx_vld_nok_0),'RSACSC.Parameter')
		Nsx_vld_nok_0.Value         = 0;
	else
		Nsx_vld_nok_0               = 0;
	end
end

%% Nsx_vld_ok_1 - Valid data
if (exist('Nsx_vld_ok_1','var')==0)                       % 
	Nsx_vld_ok_1                  = 1;
else
	if strcmpi(class(Nsx_vld_ok_1),'RSACSC.Parameter')
		Nsx_vld_ok_1.Value          = 1;
	else
		Nsx_vld_ok_1                = 1;
	end
end

%% Ntb_1_9_asc - Breakpoints  [1 2 3 4 5 6 7 8 9]
if (exist('Ntb_1_9_asc','var')==0)                        % 
	Ntb_1_9_asc                   = [1 2 3 4 5 6 7 8 9];
else
	if strcmpi(class(Ntb_1_9_asc),'RSACSC.Parameter')
		Ntb_1_9_asc.Value           = [1 2 3 4 5 6 7 8 9];
	else
		Ntb_1_9_asc                 = [1 2 3 4 5 6 7 8 9];
	end
end

%% Nxx_fstqd_samp - Tqdif sample time
if (exist('Nxx_fstqd_samp','var')==0)                     % 
	Nxx_fstqd_samp                = 0.02;
else
	if strcmpi(class(Nxx_fstqd_samp),'RSACSC.Parameter')
		Nxx_fstqd_samp.Value        = 0.02;
	else
		Nxx_fstqd_samp              = 0.02;
	end
end

%% Nxx_prmtq_rpm_to_rads - Conversion constant : 2pi/60
if (exist('Nxx_prmtq_rpm_to_rads','var')==0)              % 
	Nxx_prmtq_rpm_to_rads         = 0.10449219;
else
	if strcmpi(class(Nxx_prmtq_rpm_to_rads),'RSACSC.Parameter')
		Nxx_prmtq_rpm_to_rads.Value = 0.10449219;
	else
		Nxx_prmtq_rpm_to_rads       = 0.10449219;
	end
end

% EOF a_in_pci_rds_fstqdxx_xxx_xx_x_a.m