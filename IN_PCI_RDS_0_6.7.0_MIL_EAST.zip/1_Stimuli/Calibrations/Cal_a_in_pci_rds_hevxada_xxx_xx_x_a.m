% Initialization file for a_in_pci_rds_hevxada_xxx_xx_x_a
%===============================================================================================
% FileName Cal_a_in_pci_rds_hevxada_xxx_xx_x_a.m
%-----------------------------------------------------------------------------------------------
% Created  : 2019-01-09 16:06:11                          Created by MBD_Export_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : P. Apperce - 66641
% Date     : 2019-01-09
%===============================================================================================

%% Cxx_whl_rad - in_pci_rds_fstqdxx_xxx_xx_x_a/Wheel radius
if (exist('Cxx_whl_rad','var')==0)                        % 
	Cxx_whl_rad                   = 0.308;
else
	if strcmpi(class(Cxx_whl_rad),'RSACSC.Parameter')
		Cxx_whl_rad.Value           = 0.308;
	else
		Cxx_whl_rad                 = 0.308;
	end
end

%% Nsx_vld_fail_2 - Limp home data (1)
if (exist('Nsx_vld_fail_2','var')==0)                     % 
	Nsx_vld_fail_2                = 2;
else
	if strcmpi(class(Nsx_vld_fail_2),'RSACSC.Parameter')
		Nsx_vld_fail_2.Value        = 2;
	else
		Nsx_vld_fail_2              = 2;
	end
end

%% Nsx_vld_nok_0 - Invalid data
if (exist('Nsx_vld_nok_0','var')==0)                      % 
	Nsx_vld_nok_0                 = 0;
else
	if strcmpi(class(Nsx_vld_nok_0),'RSACSC.Parameter')
		Nsx_vld_nok_0.Value         = 0;
	else
		Nsx_vld_nok_0               = 0;
	end
end

%% Nsx_vld_ok_1 - Valid data
if (exist('Nsx_vld_ok_1','var')==0)                       % 
	Nsx_vld_ok_1                  = 1;
else
	if strcmpi(class(Nsx_vld_ok_1),'RSACSC.Parameter')
		Nsx_vld_ok_1.Value          = 1;
	else
		Nsx_vld_ok_1                = 1;
	end
end

% EOF a_in_pci_rds_hevxada_xxx_xx_x_a.m