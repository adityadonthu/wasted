% Initialization file for Sim_InPciRds_10
%===============================================================================================
% FileName Cal_Sim_InPciRds_10.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:30                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Cbx_tqdif_opt_1st_calc - Units: "bool" - Option to calculate Vxx_tq_diff in 1st gear, reverse gear and neutral.
if (exist('Cbx_tqdif_opt_1st_calc','var')==0)             % 
	Cbx_tqdif_opt_1st_calc        = true;
else
	if strcmpi(class(Cbx_tqdif_opt_1st_calc),'RSACSC.Parameter')
		Cbx_tqdif_opt_1st_calc.Value= true;
	else
		Cbx_tqdif_opt_1st_calc      = true;
	end
end

% EOF Cal_Sim_InPciRds_10.m