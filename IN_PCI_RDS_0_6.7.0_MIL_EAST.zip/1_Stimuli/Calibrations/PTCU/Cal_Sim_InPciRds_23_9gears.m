% Initialization file for Sim_InPciRds_21_Cov
%===============================================================================================
% FileName Cal_Sim_InPciRds_21_Cov.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:47                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Cbx_swadp_opt_dry_coup - Units: "bool" - Configuration option : no convertissor
if (exist('Cbx_swadp_opt_dry_coup','var')==0)             % 
	Cbx_swadp_opt_dry_coup        = true;
else
	if strcmpi(class(Cbx_swadp_opt_dry_coup),'RSACSC.Parameter')
		Cbx_swadp_opt_dry_coup.Value= true;
	else
		Cbx_swadp_opt_dry_coup      = true;
	end
end

%% Cbx_tqdif_opt_luip - Units: "bool" - Option to disable the calculation of the tq-dif during lock-up in progress
if (exist('Cbx_tqdif_opt_luip','var')==0)                 % 
	Cbx_tqdif_opt_luip            = false;
else
	if strcmpi(class(Cbx_tqdif_opt_luip),'RSACSC.Parameter')
		Cbx_tqdif_opt_luip.Value    = false;
	else
		Cbx_tqdif_opt_luip          = false;
	end
end

%% Csx_pow_r_use_acel_slop - Units: "wu" - 0 : no ESP or road_slope using ESP is not tuned ; 1 : use of slope pow_r using ESP when pow_r using primary_tq is frozen ; 2 : always use slope pow_r  using ESP in replacment of pow_r using primary_tq
if (exist('Csx_pow_r_use_acel_slop','var')==0)            % 
	Csx_pow_r_use_acel_slop       = 0;
else
	if strcmpi(class(Csx_pow_r_use_acel_slop),'RSACSC.Parameter')
		Csx_pow_r_use_acel_slop.Value= 0;
	else
		Csx_pow_r_use_acel_slop     = 0;
	end
end

%% Csx_use_acel_slop - Units: "wu" - 0 : no ESP or road_slope using ESP is not tuned1 : use of road_slope using ESP when classic tq_dif is frozen2 : always use road_slop using ESP in replacment of classic_tq_dif
if (exist('Csx_use_acel_slop','var')==0)                  % 
	Csx_use_acel_slop             = 0;
else
	if strcmpi(class(Csx_use_acel_slop),'RSACSC.Parameter')
		Csx_use_acel_slop.Value     = 0;
	else
		Csx_use_acel_slop           = 0;
	end
end

%% Cxx_tqdacel_vs_thd_stop - Units: "km/h" - Vehicle speed minimum to detect  stop condition
if (exist('Cxx_tqdacel_vs_thd_stop','var')==0)            % 
	Cxx_tqdacel_vs_thd_stop       = 1;
else
	if strcmpi(class(Cxx_tqdacel_vs_thd_stop),'RSACSC.Parameter')
		Cxx_tqdacel_vs_thd_stop.Value= 1;
	else
		Cxx_tqdacel_vs_thd_stop     = 1;
	end
end

%% Nxx_fdif_samp - Fdif specification sample time.
if (exist('Nxx_fdif_samp','var')==0)                      % 
	Nxx_fdif_samp                 = 0.02;
else
	if strcmpi(class(Nxx_fdif_samp),'RSACSC.Parameter')
		Nxx_fdif_samp.Value         = 0.02;
	else
		Nxx_fdif_samp               = 0.02;
	end
end

%% Ctp_tau_coup_tq_dwn_fil - Time constant in second for first order filter
if (exist('Ctp_tau_coup_tq_dwn_fil','var')==0)            % 
	Ctp_tau_coup_tq_dwn_fil       = [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
else
	if strcmpi(class(Ctp_tau_coup_tq_dwn_fil),'RSACSC.Parameter')
		Ctp_tau_coup_tq_dwn_fil.Value= [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
	else
		Ctp_tau_coup_tq_dwn_fil     = [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
	end
end
%% Ctp_tau_coup_tq_up_fil - Time constant in second for first order filter
if (exist('Ctp_tau_coup_tq_up_fil','var')==0)             % 
	Ctp_tau_coup_tq_up_fil        = [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
else
	if strcmpi(class(Ctp_tau_coup_tq_up_fil),'RSACSC.Parameter')
		Ctp_tau_coup_tq_up_fil.Value= [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
	else
		Ctp_tau_coup_tq_up_fil      = [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
	end
end
% %% Ctp_tau_coup_tq_dwn_fil - Time constant in second for first order filter
% if (exist('Ctp_tau_coup_tq_dwn_fil','var')==0)            % 
% 	Ctp_tau_coup_tq_dwn_fil       = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
% else
% 	if strcmpi(class(Ctp_tau_coup_tq_dwn_fil),'RSACSC.Parameter')
% 		Ctp_tau_coup_tq_dwn_fil.Value= [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
% 	else
% 		Ctp_tau_coup_tq_dwn_fil     = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
% 	end
% end
% %% Ctp_tau_coup_tq_up_fil - Time constant in second for first order filter
% if (exist('Ctp_tau_coup_tq_up_fil','var')==0)             % 
% 	Ctp_tau_coup_tq_up_fil        = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
% else
% 	if strcmpi(class(Ctp_tau_coup_tq_up_fil),'RSACSC.Parameter')
% 		Ctp_tau_coup_tq_up_fil.Value= [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
% 	else
% 		Ctp_tau_coup_tq_up_fil      = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
% 	end
% end
%% Ctp_prmtq_tau_eng_tq_dwn - Time constant in second for first order filter
if (exist('Ctp_prmtq_tau_eng_tq_dwn','var')==0)           % 
	Ctp_prmtq_tau_eng_tq_dwn      = [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
else
	if strcmpi(class(Ctp_prmtq_tau_eng_tq_dwn),'RSACSC.Parameter')
		Ctp_prmtq_tau_eng_tq_dwn.Value= [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
	else
		Ctp_prmtq_tau_eng_tq_dwn    = [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
	end
end

%% Ctp_prmtq_tau_eng_tq_up - Time constant in second for first order filter
if (exist('Ctp_prmtq_tau_eng_tq_up','var')==0)            % 
	Ctp_prmtq_tau_eng_tq_up       = [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
else
	if strcmpi(class(Ctp_prmtq_tau_eng_tq_up),'RSACSC.Parameter')
		Ctp_prmtq_tau_eng_tq_up.Value= [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
	else
		Ctp_prmtq_tau_eng_tq_up     = [0.1 0.1 0.1 0.1 0.1 0.1 0.1 1 4];
	end
end
%% Ctb_prmtq_gbx_los_tbn_spd - Bkpts of turbine speed to calculate gearbox losses
if (exist('Ctb_prmtq_gbx_los_tbn_spd','var')==0)          % 
	Ctb_prmtq_gbx_los_tbn_spd     = [1216 2400 4000 6016];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_spd),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_spd.Value= [1216 2400 4000 6016];
	else
		Ctb_prmtq_gbx_los_tbn_spd   = [1216 2400 4000 6016];
	end
end
%% Ctb_prmtq_gbx_los_tbn_tq_g8 - Bkpts of turbine torque to calculate gearbox losses on 8 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g8','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g8   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g8),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g8.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g8 = [-48 0 48 104 152 248];
	end
end

%% Cmp_prmtq_gbx_loss_g8 - Map of Turbine torque losses on 8 gear
if (exist('Cmp_prmtq_gbx_loss_g8','var')==0)              % 
	Cmp_prmtq_gbx_loss_g8         = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g8),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g8.Value = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
	else
		Cmp_prmtq_gbx_loss_g8       = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
	end
end
%% Ctb_prmtq_gbx_los_tbn_tq_g9 - Bkpts of turbine torque to calculate gearbox losses on 9 gear
if (exist('Ctb_prmtq_gbx_los_tbn_tq_g9','var')==0)        % 
	Ctb_prmtq_gbx_los_tbn_tq_g9   = [-48 0 48 104 152 248];
else
	if strcmpi(class(Ctb_prmtq_gbx_los_tbn_tq_g9),'RSACSC.Parameter')
		Ctb_prmtq_gbx_los_tbn_tq_g9.Value= [-48 0 48 104 152 248];
	else
		Ctb_prmtq_gbx_los_tbn_tq_g9 = [-48 0 48 104 152 248];
	end
end
%% Cmp_prmtq_gbx_loss_g9 - Map of Turbine torque losses on 9 gear
if (exist('Cmp_prmtq_gbx_loss_g9','var')==0)              % 
	Cmp_prmtq_gbx_loss_g9         = [1 1 1 1
                                1 1 1 1
                                1 1 1 1
                                1 1 1 1
                                1 1 1 1
                                1 1 1 1];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g9),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g9.Value = [1 1 1 1
                                1 1 1 1
                                1 1 1 1
                                1 1 1 1
                                1 1 1 1
                                1 1 1 1];
	else
		Cmp_prmtq_gbx_loss_g9       = [1 1 1 1
                                1 1 1 1
                                1 1 1 1
                                1 1 1 1
                                1 1 1 1
                                1 1 1 1];
	end
end
%% Ctp_tqdif_shf_end_tmr - Table of tempo started in the end of a gearshift during which the calcul. of Vxx_tq-dif is frozen default value [0 0 0 0 0 0 0 0 0]
if (exist('Ctp_tqdif_shf_end_tmr','var')==0)              % 
	Ctp_tqdif_shf_end_tmr         = [0 0 0 0 0 0 0 1 4];
else
	if strcmpi(class(Ctp_tqdif_shf_end_tmr),'RSACSC.Parameter')
		Ctp_tqdif_shf_end_tmr.Value = [0 0 0 0 0 0 0 1 4];
	else
		Ctp_tqdif_shf_end_tmr       = [0 0 0 0 0 0 0 1 4];
	end
end

%% Ctp_tqdif_gearbox_inertias - Table of Inertia weight on every gear position default value [308 112 56 32 16 12 12 12 12]
if (exist('Ctp_tqdif_gearbox_inertias','var')==0)         % 
	Ctp_tqdif_gearbox_inertias    = [308 308 308 308 308 308 308 150 1];
else
	if strcmpi(class(Ctp_tqdif_gearbox_inertias),'RSACSC.Parameter')
		Ctp_tqdif_gearbox_inertias.Value= [308 308 308 308 308 308 308 150 1];
	else
		Ctp_tqdif_gearbox_inertias  = [308 308 308 308 308 308 308 150 1];
	end
end
%% Ctp_acpot_efficiency - Efficiency of the gearbox for each gear  default value [1 1 1 1 1 1 1 1 1]
if (exist('Ctp_acpot_efficiency','var')==0)               % 
	Ctp_acpot_efficiency          = [0 0 0 0 0 0 0 0.5 1.9];
else
	if strcmpi(class(Ctp_acpot_efficiency),'RSACSC.Parameter')
		Ctp_acpot_efficiency.Value  = [0 0 0 0 0 0 0 0.5 1.9];
	else
		Ctp_acpot_efficiency        = [0 0 0 0 0 0 0 0.5 1.9];
	end
end

% EOF Cal_Sim_InPciRds_21_Cov.m