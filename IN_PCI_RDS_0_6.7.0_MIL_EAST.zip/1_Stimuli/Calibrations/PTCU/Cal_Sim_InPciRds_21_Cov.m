% Initialization file for Sim_InPciRds_21_Cov
%===============================================================================================
% FileName Cal_Sim_InPciRds_21_Cov.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:47                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Cbx_swadp_opt_dry_coup - Units: "bool" - Configuration option : no convertissor
if (exist('Cbx_swadp_opt_dry_coup','var')==0)             % 
	Cbx_swadp_opt_dry_coup        = false;
else
	if strcmpi(class(Cbx_swadp_opt_dry_coup),'RSACSC.Parameter')
		Cbx_swadp_opt_dry_coup.Value= false;
	else
		Cbx_swadp_opt_dry_coup      = false;
	end
end

%% Cbx_tqdif_opt_luip - Units: "bool" - Option to disable the calculation of the tq-dif during lock-up in progress
if (exist('Cbx_tqdif_opt_luip','var')==0)                 % 
	Cbx_tqdif_opt_luip            = true;
else
	if strcmpi(class(Cbx_tqdif_opt_luip),'RSACSC.Parameter')
		Cbx_tqdif_opt_luip.Value    = true;
	else
		Cbx_tqdif_opt_luip          = true;
	end
end

%% Csx_pow_r_use_acel_slop - Units: "wu" - 0 : no ESP or road_slope using ESP is not tuned ; 1 : use of slope pow_r using ESP when pow_r using primary_tq is frozen ; 2 : always use slope pow_r  using ESP in replacment of pow_r using primary_tq
if (exist('Csx_pow_r_use_acel_slop','var')==0)            % 
	Csx_pow_r_use_acel_slop       = 2;
else
	if strcmpi(class(Csx_pow_r_use_acel_slop),'RSACSC.Parameter')
		Csx_pow_r_use_acel_slop.Value= 2;
	else
		Csx_pow_r_use_acel_slop     = 2;
	end
end

%% Csx_use_acel_slop - Units: "wu" - 0 : no ESP or road_slope using ESP is not tuned1 : use of road_slope using ESP when classic tq_dif is frozen2 : always use road_slop using ESP in replacment of classic_tq_dif
if (exist('Csx_use_acel_slop','var')==0)                  % 
	Csx_use_acel_slop             = 2;
else
	if strcmpi(class(Csx_use_acel_slop),'RSACSC.Parameter')
		Csx_use_acel_slop.Value     = 2;
	else
		Csx_use_acel_slop           = 2;
	end
end

%% Cxx_tqdacel_vs_thd_stop - Units: "km/h" - Vehicle speed minimum to detect  stop condition
if (exist('Cxx_tqdacel_vs_thd_stop','var')==0)            % 
	Cxx_tqdacel_vs_thd_stop       = 10;
else
	if strcmpi(class(Cxx_tqdacel_vs_thd_stop),'RSACSC.Parameter')
		Cxx_tqdacel_vs_thd_stop.Value= 10;
	else
		Cxx_tqdacel_vs_thd_stop     = 10;
	end
end

%% Nxx_fdif_samp - Fdif specification sample time.
if (exist('Nxx_fdif_samp','var')==0)                      % 
	Nxx_fdif_samp                 = 0.02;
else
	if strcmpi(class(Nxx_fdif_samp),'RSACSC.Parameter')
		Nxx_fdif_samp.Value         = 0.02;
	else
		Nxx_fdif_samp               = 0.02;
	end
end

% EOF Cal_Sim_InPciRds_21_Cov.m