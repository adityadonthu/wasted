% Initialization file for Sim_InPciRds_19_acel_slop_2
%===============================================================================================
% FileName Cal_Sim_InPciRds_19_acel_slop_2.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:45                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Cbx_agb_lg_acel_ena - Units: "bool" - Boolean to choose between ESP sensor or AGB sensor for longitudinal acceleration
if (exist('Cbx_agb_lg_acel_ena','var')==0)                % 
	Cbx_agb_lg_acel_ena           = false;
else
	if strcmpi(class(Cbx_agb_lg_acel_ena),'RSACSC.Parameter')
		Cbx_agb_lg_acel_ena.Value   = false;
	else
		Cbx_agb_lg_acel_ena         = false;
	end
end

%% Cbx_road_slop_esp - Units: "bool" - Activation of use of slope calculation using ESP sensor
if (exist('Cbx_road_slop_esp','var')==0)                  % 
	Cbx_road_slop_esp             = true;
else
	if strcmpi(class(Cbx_road_slop_esp),'RSACSC.Parameter')
		Cbx_road_slop_esp.Value     = true;
	else
		Cbx_road_slop_esp           = true;
	end
end

%% Cbx_tqdif_opt_1st_calc - Units: "bool" - Option to calculate Vxx_tq_diff in 1st gear, reverse gear and neutral.
if (exist('Cbx_tqdif_opt_1st_calc','var')==0)             % 
	Cbx_tqdif_opt_1st_calc        = true;
else
	if strcmpi(class(Cbx_tqdif_opt_1st_calc),'RSACSC.Parameter')
		Cbx_tqdif_opt_1st_calc.Value= true;
	else
		Cbx_tqdif_opt_1st_calc      = true;
	end
end

%% Cmp_prmtq_gbx_loss_g1 - Units: "Nm" - Map of Turbine torque losses on 1 gear
if (exist('Cmp_prmtq_gbx_loss_g1','var')==0)              % 
	Cmp_prmtq_gbx_loss_g1         = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g1),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g1.Value = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
	else
		Cmp_prmtq_gbx_loss_g1       = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
	end
end

%% Cmp_prmtq_gbx_loss_g2 - Units: "Nm" - Map of Turbine torque losses on 2 gear
if (exist('Cmp_prmtq_gbx_loss_g2','var')==0)              % 
	Cmp_prmtq_gbx_loss_g2         = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g2),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g2.Value = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
	else
		Cmp_prmtq_gbx_loss_g2       = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
	end
end

%% Cmp_prmtq_gbx_loss_g3 - Units: "Nm" - Map of Turbine torque losses on 3 gear
if (exist('Cmp_prmtq_gbx_loss_g3','var')==0)              % 
	Cmp_prmtq_gbx_loss_g3         = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
else
	if strcmpi(class(Cmp_prmtq_gbx_loss_g3),'RSACSC.Parameter')
		Cmp_prmtq_gbx_loss_g3.Value = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
	else
		Cmp_prmtq_gbx_loss_g3       = [0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0
                                0 0 0 0];
	end
end

%% Csx_pow_r_use_acel_slop - Units: "wu" - 0 : no ESP or road_slope using ESP is not tuned ; 1 : use of slope pow_r using ESP when pow_r using primary_tq is frozen ; 2 : always use slope pow_r  using ESP in replacment of pow_r using primary_tq
if (exist('Csx_pow_r_use_acel_slop','var')==0)            % 
	Csx_pow_r_use_acel_slop       = 1;
else
	if strcmpi(class(Csx_pow_r_use_acel_slop),'RSACSC.Parameter')
		Csx_pow_r_use_acel_slop.Value= 1;
	else
		Csx_pow_r_use_acel_slop     = 1;
	end
end

%% Csx_use_acel_slop - Units: "wu" - 0 : no ESP or road_slope using ESP is not tuned1 : use of road_slope using ESP when classic tq_dif is frozen2 : always use road_slop using ESP in replacment of classic_tq_dif
if (exist('Csx_use_acel_slop','var')==0)                  % 
	Csx_use_acel_slop             = 1;
else
	if strcmpi(class(Csx_use_acel_slop),'RSACSC.Parameter')
		Csx_use_acel_slop.Value     = 1;
	else
		Csx_use_acel_slop           = 1;
	end
end

%% Ctp_prmtq_tau_eng_tq_dwn - Units: "s" - Time constant in second for first order filter
if (exist('Ctp_prmtq_tau_eng_tq_dwn','var')==0)           % 
	Ctp_prmtq_tau_eng_tq_dwn      = [0.3 0.4 0.5 0.6 0.3 0.3 0.3];
else
	if strcmpi(class(Ctp_prmtq_tau_eng_tq_dwn),'RSACSC.Parameter')
		Ctp_prmtq_tau_eng_tq_dwn.Value= [0.3 0.4 0.5 0.6 0.3 0.3 0.3 0.3 0.3];
	else
		Ctp_prmtq_tau_eng_tq_dwn    = [0.3 0.4 0.5 0.6 0.3 0.3 0.3 0.3 0.3];
	end
end

%% Ctp_prmtq_tau_eng_tq_up - Units: "s" - Time constant in second for first order filter
if (exist('Ctp_prmtq_tau_eng_tq_up','var')==0)            % 
	Ctp_prmtq_tau_eng_tq_up       = [0.3 0.4 0.5 0.6 0.3 0.3 0.3 0.3 0.3];
else
	if strcmpi(class(Ctp_prmtq_tau_eng_tq_up),'RSACSC.Parameter')
		Ctp_prmtq_tau_eng_tq_up.Value= [0.3 0.4 0.5 0.6 0.3 0.3 0.3 0.3 0.3];
	else
		Ctp_prmtq_tau_eng_tq_up     = [0.3 0.4 0.5 0.6 0.3 0.3 0.3 0.3 0.3];
	end
end

%% Ctp_res_forc - Units: "N" - Known resistant forces : air drag load and resistance to the rolling
if (exist('Ctp_res_forc','var')==0)                       % 
	Ctp_res_forc                  = [200 203.8 215.1 233.9 260.3 294.3 335.8 384.8 441.4 505.5 577.1 656.3 743.1 837.4 939.2 1049 1165 1290 1422 1561 1709];
else
	if strcmpi(class(Ctp_res_forc),'RSACSC.Parameter')
		Ctp_res_forc.Value          = [200 203.8 215.1 233.9 260.3 294.3 335.8 384.8 441.4 505.5 577.1 656.3 743.1 837.4 939.2 1049 1165 1290 1422 1561 1709];
	else
		Ctp_res_forc                = [200 203.8 215.1 233.9 260.3 294.3 335.8 384.8 441.4 505.5 577.1 656.3 743.1 837.4 939.2 1049 1165 1290 1422 1561 1709];
	end
end

%% Cxx_pow_r_slop_tau_fil - Units: "s" - first order filter time constant for resistive power using slope
if (exist('Cxx_pow_r_slop_tau_fil','var')==0)             % 
	Cxx_pow_r_slop_tau_fil        = 0.2;
else
	if strcmpi(class(Cxx_pow_r_slop_tau_fil),'RSACSC.Parameter')
		Cxx_pow_r_slop_tau_fil.Value= 0.2;
	else
		Cxx_pow_r_slop_tau_fil      = 0.2;
	end
end

%% Cxx_pow_r_swi_neg_slop - Units: "% / 0.01s" - Negative slope value for transition between resistive power calculation using torque or using slope
if (exist('Cxx_pow_r_swi_neg_slop','var')==0)             % 
	Cxx_pow_r_swi_neg_slop        = -1500;
else
	if strcmpi(class(Cxx_pow_r_swi_neg_slop),'RSACSC.Parameter')
		Cxx_pow_r_swi_neg_slop.Value= -1500;
	else
		Cxx_pow_r_swi_neg_slop      = -1500;
	end
end

%% Cxx_pow_r_swi_pos_slop - Units: "% / 0.01s" - Positive slope value for transition between resistive power calculation using torque or using slope
if (exist('Cxx_pow_r_swi_pos_slop','var')==0)             % 
	Cxx_pow_r_swi_pos_slop        = 1500;
else
	if strcmpi(class(Cxx_pow_r_swi_pos_slop),'RSACSC.Parameter')
		Cxx_pow_r_swi_pos_slop.Value= 1500;
	else
		Cxx_pow_r_swi_pos_slop      = 1500;
	end
end

%% Cxx_road_slop_neg_slop - Units: "% / 0.01s" - Negative slope value for transition between static and dynamic road slope calculation
if (exist('Cxx_road_slop_neg_slop','var')==0)             % 
	Cxx_road_slop_neg_slop        = -10;
else
	if strcmpi(class(Cxx_road_slop_neg_slop),'RSACSC.Parameter')
		Cxx_road_slop_neg_slop.Value= -10;
	else
		Cxx_road_slop_neg_slop      = -10;
	end
end

%% Cxx_road_slop_pos_slop - Units: "% / 0.01s" - Positive slope value for transition between static and dynamic road slope calculation
if (exist('Cxx_road_slop_pos_slop','var')==0)             % 
	Cxx_road_slop_pos_slop        = 10;
else
	if strcmpi(class(Cxx_road_slop_pos_slop),'RSACSC.Parameter')
		Cxx_road_slop_pos_slop.Value= 10;
	else
		Cxx_road_slop_pos_slop      = 10;
	end
end

%% Cxx_tqdif_brk_frz_dly - Units: "s" - Delay after braking during which the calculation of Vxx_tq_dif is frozen
if (exist('Cxx_tqdif_brk_frz_dly','var')==0)              % 
	Cxx_tqdif_brk_frz_dly         = 0;
else
	if strcmpi(class(Cxx_tqdif_brk_frz_dly),'RSACSC.Parameter')
		Cxx_tqdif_brk_frz_dly.Value = 0;
	else
		Cxx_tqdif_brk_frz_dly       = 0;
	end
end

%% Cxx_tqdif_gear_min - Units: "wu" - Minimum gear to calculate Vxx_tq_dif
if (exist('Cxx_tqdif_gear_min','var')==0)                 % 
	Cxx_tqdif_gear_min            = 1;
else
	if strcmpi(class(Cxx_tqdif_gear_min),'RSACSC.Parameter')
		Cxx_tqdif_gear_min.Value    = 1;
	else
		Cxx_tqdif_gear_min          = 1;
	end
end

%% Cxx_tqdif_tau_fil - Units: "s" - Time constante in second for  the first order filter
if (exist('Cxx_tqdif_tau_fil','var')==0)                  % 
	Cxx_tqdif_tau_fil             = 0.3;
else
	if strcmpi(class(Cxx_tqdif_tau_fil),'RSACSC.Parameter')
		Cxx_tqdif_tau_fil.Value     = 0.3;
	else
		Cxx_tqdif_tau_fil           = 0.3;
	end
end

%% Cxx_tqdif_tm_brk_del - Units: "s" - Temporization started after end of braking during which the calculation of Vxx_tq_dif is frozen
if (exist('Cxx_tqdif_tm_brk_del','var')==0)               % 
	Cxx_tqdif_tm_brk_del          = 0;
else
	if strcmpi(class(Cxx_tqdif_tm_brk_del),'RSACSC.Parameter')
		Cxx_tqdif_tm_brk_del.Value  = 0;
	else
		Cxx_tqdif_tm_brk_del        = 0;
	end
end

%% Cxx_tqdif_vs_hys - Units: "km/h" - Vehicle speed hysteresys for tq_dif freeze threshold
if (exist('Cxx_tqdif_vs_hys','var')==0)                   % 
	Cxx_tqdif_vs_hys              = 4;
else
	if strcmpi(class(Cxx_tqdif_vs_hys),'RSACSC.Parameter')
		Cxx_tqdif_vs_hys.Value      = 4;
	else
		Cxx_tqdif_vs_hys            = 4;
	end
end

% EOF Cal_Sim_InPciRds_19_acel_slop_2.m