% Initialization file for Sim_InPciRds_14
%===============================================================================================
% FileName Cal_Sim_InPciRds_14.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:37                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Cbx_atcu_ptcu_typ_cfm - Units: "bool" - Configration of ATCU or PTCU confirmation
if (exist('Cbx_atcu_ptcu_typ_cfm','var')==0)              % 
	Cbx_atcu_ptcu_typ_cfm         = true;
else
	if strcmpi(class(Cbx_atcu_ptcu_typ_cfm),'RSACSC.Parameter')
		Cbx_atcu_ptcu_typ_cfm.Value = true;
	else
		Cbx_atcu_ptcu_typ_cfm       = true;
	end
end

%% Cbx_flt_rst_cfm - Units: "bool" - Option to activate the reset of the filter by the state of Clutch (Open to sliding)
if (exist('Cbx_flt_rst_cfm','var')==0)                    % 
	Cbx_flt_rst_cfm               = true;
else
	if strcmpi(class(Cbx_flt_rst_cfm),'RSACSC.Parameter')
		Cbx_flt_rst_cfm.Value       = true;
	else
		Cbx_flt_rst_cfm             = true;
	end
end

% EOF Cal_Sim_InPciRds_14.m