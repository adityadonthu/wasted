% Initialization file for Sim_InPciRds_13
%===============================================================================================
% FileName Cal_Sim_InPciRds_13.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:35                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Cbx_atcu_ptcu_typ_cfm - Units: "bool" - Configration of ATCU or PTCU confirmation
if (exist('Cbx_atcu_ptcu_typ_cfm','var')==0)              % 
	Cbx_atcu_ptcu_typ_cfm         = true;
else
	if strcmpi(class(Cbx_atcu_ptcu_typ_cfm),'RSACSC.Parameter')
		Cbx_atcu_ptcu_typ_cfm.Value = true;
	else
		Cbx_atcu_ptcu_typ_cfm       = true;
	end
end

%% Cbx_tqdif_opt_1st_calc - Units: "bool" - Option to calculate Vxx_tq_diff in 1st gear, reverse gear and neutral.
if (exist('Cbx_tqdif_opt_1st_calc','var')==0)             % 
	Cbx_tqdif_opt_1st_calc        = true;
else
	if strcmpi(class(Cbx_tqdif_opt_1st_calc),'RSACSC.Parameter')
		Cbx_tqdif_opt_1st_calc.Value= true;
	else
		Cbx_tqdif_opt_1st_calc      = true;
	end
end

%% Cbx_tqdif_opt_luip - Units: "bool" - Option to disable the calculation of the tq-dif during lock-up in progress
if (exist('Cbx_tqdif_opt_luip','var')==0)                 % 
	Cbx_tqdif_opt_luip            = true;
else
	if strcmpi(class(Cbx_tqdif_opt_luip),'RSACSC.Parameter')
		Cbx_tqdif_opt_luip.Value    = true;
	else
		Cbx_tqdif_opt_luip          = true;
	end
end

% EOF Cal_Sim_InPciRds_13.m