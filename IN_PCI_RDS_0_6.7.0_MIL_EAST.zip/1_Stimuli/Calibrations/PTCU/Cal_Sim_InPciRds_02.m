% Initialization file for Sim_InPciRds_02
%===============================================================================================
% FileName Cal_Sim_InPciRds_02.m
%-----------------------------------------------------------------------------------------------
% Created  : 2016-01-20 15:21:26                          Created by MBD_Convert_mFiles
%-----------------------------------------------------------------------------------------------
% Author   : J. Le-Bail - 66641
% Date     : 2016-01-20
%===============================================================================================

%% Cbx_swadp_opt_dry_coup - Units: "bool" - Configuration option : no convertissor
if (exist('Cbx_swadp_opt_dry_coup','var')==0)             % 
	Cbx_swadp_opt_dry_coup        = false;
else
	if strcmpi(class(Cbx_swadp_opt_dry_coup),'RSACSC.Parameter')
		Cbx_swadp_opt_dry_coup.Value= false;
	else
		Cbx_swadp_opt_dry_coup      = false;
	end
end

% EOF Cal_Sim_InPciRds_02.m