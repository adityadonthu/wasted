function popupmenu1_Callback(hObject, eventdata, handles)
switch get(handles.popupmenu,'Value')   
  case 1
    S.I=7;
    S.V=20;
    S.p=130;
  case 2
    S.I=5;
    S.V=30;
    S.p=170;
  otherwise
end 
set(handles.popupmenu, 'UserData', S);
function popupmenu2_Callback(hObject, eventdata, handles)
switch get(handles.popupmenu,'Value')   
  case 1
set(handles.popupmenu, 'UserData', S);    
     i=S.I
     v=S.V
     p=i*v
    case 2
     set(handles.popupmenu, 'UserData', S);    
      i=S.I
      v=S.V
      p=i*v
    otherwise
  end