function inputs
clear all
clc
Report_Dir='D:\aditya\Aditya_Scripts\Reports';
Sc_Doc_path='D:\aditya\Aditya_Scripts\Scenario_Excel';
Module='PC_TRA_ARB_0_4.0.1_RI_6.0';
if ~isdir(Sc_Doc_path)
mkdir(Sc_Doc_path)
end
filename='D:\aditya\Aditya_Scripts\Report_Validation.xlsm';
%Report_Validation(Report_Dir,Sc_Doc_path,filename)
if ~exist(strcat(Sc_Doc_path,'\Scenario_Doc.xlsx'))
    msgbox('Scenario_Excel was not created', 'Error','error');
    return
end
file3=strcat(Sc_Doc_path,'\Scenario_Doc.xlsx');
[~,txt,~]=xlsread(file3);
Z=txt(:,1:2);
total_Scenario=data_extract1(Z);
kk=1;   Zero_errors=0;
Error_Scenario=[];
for ii=2:length(total_Scenario)
    Scenario=evalin('base',total_Scenario{ii,2});
    for jj=1:length(Scenario) 
        if (strcmp(strtrim(Scenario{jj,1}),'NA'))
            total_Scenario{ii,1}=ii-1;
            total_Scenario{ii,3}=Scenario{jj,1};
            total_Scenario{ii,4}='NA';
            total_Scenario{ii,5}='NA';
            total_Scenario{ii,6}='NA';
            total_Scenario{ii,7}='NA';
            total_Scenario{ii,8}='NA';
            Zero_errors=Zero_errors+1;
        else 
            total_Scenario{ii,1}=ii-1;
            total_Scenario{ii,3}=Scenario;
            Error_Scenario{kk,1}=total_Scenario{ii,2};
            kk=kk+1;
        end   
    end
end
Error_Scenario=unique(Error_Scenario);
if isempty(Error_Scenario)
    msgbox('Zero Error')
     %Excel_data(total_Scenario,Module);
end
assignin('base','Error_Scenario',Error_Scenario);
assignin('base','total_Scenario',total_Scenario);
end


function total_Scenario=data_extract1(Z)
[m,~]=size(Z);
for ii=2:m
if(~isempty(Z{ii,1}))
    a=Z{ii,1};
    b={Z{ii,2}};
else
    c={Z{ii,2}};
    b=[b;c];
end
assignin('base',a,b);
end
kk=2;
total_Scenario{1,1}='SL.No';
total_Scenario{1,2}='Scenario Name';
total_Scenario{1,3}='Mismatch';
total_Scenario{1,4}='Variable';
total_Scenario{1,5}='Error type';
total_Scenario{1,6}='Error Description';
total_Scenario{1,7}='Possible Solution(if applicable)';
total_Scenario{1,8}='Issue NO';

for ii=2:m
if(~isempty(Z{ii,1}))
    total_Scenario{kk,2}=Z{ii,1};
    kk=kk+1;
end
end
end
