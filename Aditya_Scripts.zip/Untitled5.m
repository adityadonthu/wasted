xlCenter = -4108;
excelOutputFileName = 'full path\excelfile.xlsx'
Excel = actxserver('Excel.Application');
Excel.Visible = 0; % to see the excel file real time make 1;
Workbook = Excel.Workbooks.Open(excelOutputFileName);
Range = Excel.Range('A1:I1');
Range.Select;
Range.MergeCells = 1;
Range.HorizontalAlignment = xlCenter;