fuction Screen_adit(Model_Name,TR_Number,Authour_Name,Authour_ID,Screener_Name,Screener_ID,Current_date,Checker_Name,Root_Folder)
Root_dir=pwd;
            addpath(genpath(Root_dir));
            load('CM_Data.mat');
            CM_data(~cellfun(@isempty,(strfind(CM_data,'Person_Name_For_Automation'))))={['Checked By : ' strtrim(Checker_Name)]};
            CM_data(~cellfun(@isempty,(strfind(CM_data,'Current_Date'))))={['Date : ' strtrim(Current_date)]};
            CMCheck_Fid=fopen('CMCheck.txt','w');
            for CM_Data_Indx=1:length(CM_data)
                fprintf(CMCheck_Fid,'%s\n',string(CM_data{CM_Data_Indx}));
            end
            fclose(CMCheck_Fid);
            load('Read_Me_Data.mat');
            Read_Me_Data(~cellfun(@isempty,(strfind(Read_Me_Data,'TR_NUMBER'))))=...
                {['       Results_' strtrim(Model_Name) '.doc       1.0           RNTBCISIL TR ' strtrim(TR_Number)],...
                ['       Scenarios_' strtrim(Model_Name) '.xlsx    1.0           RNTBCISIL TR ' strtrim(TR_Number)],...
                ['       ' strtrim(Model_Name) '.zip               1.0           RNTBCISIL TR ' strtrim(TR_Number)]};
            Read_Me_Data(~cellfun(@isempty,(strfind(Read_Me_Data,'Current_Date'))))=...
                {['5.Date of Release                                  : ' strtrim(Current_date)]};
            
            Readme_Fid=fopen('ReadMe.txt','w');
            for Readme_Data_Indx=1:length(Read_Me_Data)
                fprintf(Readme_Fid,'%s\n',string(Read_Me_Data{Readme_Data_Indx}));
            end
            fclose(Readme_Fid);
            cd('Template');
            copyfile('Release_Checklist_Template.xls',[Root_dir '\Release_Checklist.xls']);
            copyfile('Screen_Activity_Report_Template.xls',[Root_dir '\Screen_Activity_Report.xls']);
            cd(Root_dir);
            xlswrite('Release_Checklist.xls',{['Date of Release: ' strtrim(Current_date)]},1,'A6');
            xlswrite('Release_Checklist.xls',{' '},1,'A1');
            xlswrite('Screen_Activity_Report.xls',strtrim({Authour_Name}),1,'B3');
            xlswrite('Screen_Activity_Report.xls',...
                {['SIL TESTING UNIPHASE Readiness Screen SIL TESTING UNIPHASE Cycle ' strtrim(TR_Number) '_1']},2,'B8');
            xlswrite('Screen_Activity_Report.xls',{strtrim(Current_date)},2,'B9');
             xlswrite('Screen_Activity_Report.xls',{strtrim(Current_date)},1,'D10');
            xlswrite('Screen_Activity_Report.xls',{[strtrim(Authour_Name),'(',Authour_ID,')']},2,'B20');
            xlswrite('Screen_Activity_Report.xls',{strtrim(Model_Name)},2,'B13');
            xlswrite('Screen_Activity_Report.xls',{[strtrim(Screener_Name),'(',strtrim(Screener_ID),')']},2,'B26');
            xlswrite('Screen_Activity_Report.xls',{[strtrim(Screener_Name),'(',strtrim(Screener_ID),')']},2,'B27');
            xlswrite('Screen_Activity_Report.xls',{strtrim(Screener_Name)},1,'D9');
            xlswrite('Screen_Activity_Report.xls',{strtrim(Model_Name)},1,'B2');
            xlswrite('Screen_Activity_Report.xls',{' '},2,'A1');
            xlswrite('Screen_Activity_Report.xls',{' '},1,'A1');
            fclose all;
			%Root_Folder=uigetdir(pwd,'Select the Root folder of a product'); 
            movefile(which('CMCheck.txt'),Root_Folder);
            movefile(which('ReadMe.txt'),Root_Folder);
            movefile(which('Release_Checklist.xls'),Root_Folder);
            movefile(which('Screen_Activity_Report.xls'),Root_Folder);
            Root_Folder_dir=dir(Root_Folder);
            Root_Folder_Names = {Root_Folder_dir.name};
            Root_Folder_Names(ismember(Root_Folder_Names,{'..','.'}))=[]; 
            Req_Folder_Name=Root_Folder_Names(contains(Root_Folder_Names,'Validation_Reports'));
            try
            cd(fullfile(Root_Folder,Req_Folder_Name{1}));
            Validation_R_Doc=dir('*.doc');
            Validation_R_Doc_Name={Validation_R_Doc.name};
            Validation_Xls_Doc=dir('*.xlsx');
            Validation_Xls_Doc_Names={Validation_Xls_Doc.name};
            catch err;
                disp(err.message);
                disp('Check Your Folder Structure');
            end
            hdlActiveX = actxserver('Word.Application');
            hdlActiveX.Visible = false;
            Word = hdlActiveX.Documents.Open(fullfile(pwd,Validation_R_Doc_Name{1}));
            Client_Hndl = get(Word.BuiltInDocumentProperties, 'Item', 'Author');
            Title_Hndl = get(Word.BuiltInDocumentProperties, 'Item', 'Title');
            Comments_Hndl = get(Word.BuiltInDocumentProperties, 'Item', 'Comments');
            Company_Hndl = get(Word.BuiltInDocumentProperties, 'Item', 'Company');
            set(Client_Hndl,'Value','KPIT');
            set(Title_Hndl,'Value',['Results_' Model_Name '.doc']);
            set(Comments_Hndl,'Value',strtrim(strvcat({['Config ID: RNTBCISIL TR:' TR_Number], ...
                'Ver: 1.0',...
                ['Dated: ' strtrim(Current_date)]})));
            set(Client_Hndl,'Value','RENAULT S.A.');
            set(Company_Hndl,'Value','KPIT');
            Word.Close();
            hdlActiveX.Quit();
            hdlActiveX_Excel = actxserver('Excel.Application');
            hdlActiveX_Excel.Visible = false;
            Excel =hdlActiveX_Excel.Workbooks.Open(fullfile(pwd, Validation_Xls_Doc_Names{1}),0,false);
            Client_Hndl = get(Excel.BuiltInDocumentProperties, 'Item', 'Author');
            Title_Hndl = get(Excel.BuiltInDocumentProperties, 'Item', 'Title');
            Comments_Hndl = get(Excel.BuiltInDocumentProperties, 'Item', 'Comments');
            Company_Hndl = get(Excel.BuiltInDocumentProperties, 'Item', 'Company');
            set(Client_Hndl,'Value','KPIT');
            set(Title_Hndl,'Value',['Scenarios_' Model_Name '.doc']);
            set(Comments_Hndl,'Value',strtrim(strvcat({['Config ID: RNTBCISIL TR:' TR_Number], ...
                'Ver: 1.0',...
                ['Dated: ' strtrim(Current_date)]})));
            set(Client_Hndl,'Value','RENAULT S.A.');
            set(Company_Hndl,'Value','KPIT');
               
            hdlActiveX_Excel.delete;
           system('taskkill /F /IM EXCEL.EXE');
            % cd(Root_Folder);
			cd(Root_dir); %changed
             clear;
             clc;
             end
            msgbox('Done');