function Report_Validation(Report_Dir,Sc_Doc_path,filename)
if(nargin==0)
    Report_Dir=uigetdir('Select Report Folder','Reports');
    [FileName,PathName,~] =uigetfile('*.xlsm','Select Report_Validation.xlsm');
    filename=[PathName FileName];
    Sc_Doc_path=uigetdir('Select a folder','Scenario_Folder');
end
if exist(strcat(Sc_Doc_path,'\Scenario_Doc.xlsx'))
     delete(strcat(Sc_Doc_path,'\Scenario_Doc.xlsx'));
end
try
fid=fopen(filename,'a');
 fclose('all');
if fid~=-1
    xlRange = 'A1';
    xlRange_2='A2';
    sheet = 1;
    Report_Dir_Cell={Report_Dir};
    Sc_Doc_path_Cell={Sc_Doc_path};
    xlswrite(filename,Report_Dir_Cell,sheet,xlRange);
    xlswrite(filename,Sc_Doc_path_Cell,sheet,xlRange_2);
    ExcelApp = actxserver('Excel.Application');
    ExcelApp.Visible = 0;
    workbook=ExcelApp.Workbooks.Open(fullfile(filename),1);
    ExcelApp.Run('Report_Validation');
    ExcelApp.Quit;
    ExcelApp.release;
end
catch err
    disp(err.message);
    return;
end
end






