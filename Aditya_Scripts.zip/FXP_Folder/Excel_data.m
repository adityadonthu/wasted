%function Excel_data(total_Scenario,Module)
Scenarios_doc=strcat('Scenarios_',Module);
Scenarios_path=strcat('D:\aditya\Aditya_Scripts\FXP_Folder','\',Scenarios_doc);
if ~isdir(Scenarios_path)
mkdir (Scenarios_path)
end
Scenarios_path_xls=strcat(Scenarios_path,'\',Module,'.xlsx');
if exist(Scenarios_path_xls)
delete (Scenarios_path_xls)
end
xlswrite(Scenarios_path_xls,total_Scenario);
% Create object.
Excel = actxserver('Excel.Application');
% Get Workbook object
WB = Excel.Workbooks.Open((Scenarios_path_xls),0,false);
% Set the color of cell 'A1' of Sheet 1 to Light Green
%rgb = [196 215 155];%rgb code
%clr = rgb * [1 256 256^2]';
WB.Worksheets.Item(1).Name = Module;
WB.Worksheets.Item(1).Range('A1:H1').Columns.AutoFit
WB.Worksheets.Item(1).Range('A1:H1').Interior.Color = 10213316;
WB.Worksheets.Item(1).Range('A1:H1').Font.Bold='true';
WB.Worksheets.Item(1).Range('B:B').Font.Bold='true';
WB.Worksheets.Item(1).Range('A:H').Font.Name = 'Arial';
WB.Worksheets.Item(1).Range('A:H').Font.Size = 10;
WB.Worksheets.Item(1).Range('A:H').HorizontalAlignment = -4108;
WB.Worksheets.Item(1).Range('A:H').VerticalAlignment = -4108;
%WB.Worksheets.Item(1).Range('B:H').Borders.Item('xlEdgeLeft').LineStyle = 7;
%WB.Worksheets.Item(1).Range('A:H').Borders.Item(1).LineStyle = 1;
%WB.Worksheets.Item(1).Range('A:H').Borders.Item(1).LineStyle = 7;
WB.Save();
% Close Workbook
WB.Close();
% Quit Excel
Excel.Quit();



%end