e = actxserver('Excel.Application');
% Add a workbook.
eWorkbook = e.Workbooks.Add;
e.Visible = 1;
% Make the first sheet active.
eSheets = e.ActiveWorkbook.Sheets;
eSheet1 = eSheets.get('Item',1);
eSheet1.Activate
% Merge Cells
eSheet1 = eSheet1.get('Range', 'A1:E1');
eSheet1.MergeCells = 1;
eSheet1.Value = 'text here';
eSheet1.Font.ColorIndex = 3
eSheet1.Font.Bold = 1;