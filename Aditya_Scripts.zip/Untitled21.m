% Connect to Excel
Excel = actxserver('excel.application');
% Get Workbook object
WB = Excel.Workbooks.Open(('D:\aditya\Aditya_Scripts\CheckList.xlsx'),0,false);
% Set the color of cell "A1" of Sheet 1 to Yellow
WB.Worksheets.Item(1).Range('A1:F1').Interior.Color = hex2dec('00FF00');
% Save Workbook

% Close Workbook
WB.Close();
% Quit Excel
Excel.Quit();