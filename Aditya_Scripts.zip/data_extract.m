
clear all;
clc;
[path3,fname3]=uigetfile('*.xlsx','Open Scenario_Doc File');
file3=[fname3 path3];
[~,txt,~]=xlsread(file3);
Z=txt(:,1:2);
total_Scenario=data_extract1(Z);

function total_Scenario=data_extract1(Z)
[m,~]=size(Z);
for ii=2:m
if(~isempty(Z{ii,1}))
    a=Z{ii,1};
    b={Z{ii,2}};
else
    c={Z{ii,2}};
    b=[b;c];
end
assignin('base',a,b);
end
kk=1;
for ii=2:m
if(~isempty(Z{ii,1}))
    total_Scenario{kk,1}=Z{ii,1};
    kk=kk+1;
end
end
end